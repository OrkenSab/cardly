import{s as r}from"../chunks/DO2ZuVvs.mjs";import{y as t}from"../chunks/B6MASrl-.mjs";export{t as load_css,r as start};
