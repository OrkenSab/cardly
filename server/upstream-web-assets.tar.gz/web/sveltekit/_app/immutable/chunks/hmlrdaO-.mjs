import{k as a,x as f,X as i,S as p}from"./BWIvkHVA.mjs";function c(r,o){a&&f(i(r)),p(()=>{var t=o();for(var s in t){var e=t[s];e?r.style.setProperty(s,e):r.style.removeProperty(s)}})}export{c};
