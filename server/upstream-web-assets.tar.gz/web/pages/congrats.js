"use strict";
var anki = (() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __typeError = (msg) => {
    throw TypeError(msg);
  };
  var __defNormalProp = (obj, key2, value) => key2 in obj ? __defProp(obj, key2, { enumerable: true, configurable: true, writable: true, value }) : obj[key2] = value;
  var __esm = (fn, res, err) => function __init() {
    if (err) throw err[0];
    try {
      return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
    } catch (e) {
      throw err = [e], e;
    }
  };
  var __commonJS = (cb, mod) => function __require() {
    try {
      return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
    } catch (e) {
      throw mod = 0, e;
    }
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key2 of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key2) && key2 !== except)
          __defProp(to, key2, { get: () => from[key2], enumerable: !(desc = __getOwnPropDesc(from, key2)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
  var __publicField = (obj, key2, value) => __defNormalProp(obj, typeof key2 !== "symbol" ? key2 + "" : key2, value);
  var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
  var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
  var __privateAdd = (obj, member, value) => member.has(obj) ? __typeError("Cannot add the same private member more than once") : member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
  var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
  var __privateMethod = (obj, member, method) => (__accessCheck(obj, member, "access private method"), method);

  // node_modules/intl-pluralrules/factory.mjs
  var factory_exports = {};
  __export(factory_exports, {
    default: () => getPluralRules
  });
  function _typeof(obj) {
    "@babel/helpers - typeof";
    return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(obj2) {
      return typeof obj2;
    } : function(obj2) {
      return obj2 && "function" == typeof Symbol && obj2.constructor === Symbol && obj2 !== Symbol.prototype ? "symbol" : typeof obj2;
    }, _typeof(obj);
  }
  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }
  function _defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
      var descriptor = props[i];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor) descriptor.writable = true;
      Object.defineProperty(target, _toPropertyKey(descriptor.key), descriptor);
    }
  }
  function _createClass(Constructor, protoProps, staticProps) {
    if (protoProps) _defineProperties(Constructor.prototype, protoProps);
    if (staticProps) _defineProperties(Constructor, staticProps);
    Object.defineProperty(Constructor, "prototype", {
      writable: false
    });
    return Constructor;
  }
  function _toPrimitive(input, hint) {
    if (typeof input !== "object" || input === null) return input;
    var prim = input[Symbol.toPrimitive];
    if (prim !== void 0) {
      var res = prim.call(input, hint || "default");
      if (typeof res !== "object") return res;
      throw new TypeError("@@toPrimitive must return a primitive value.");
    }
    return (hint === "string" ? String : Number)(input);
  }
  function _toPropertyKey(arg) {
    var key2 = _toPrimitive(arg, "string");
    return typeof key2 === "symbol" ? key2 : String(key2);
  }
  function _classPrivateFieldGet(receiver, privateMap) {
    var descriptor = _classExtractFieldDescriptor(receiver, privateMap, "get");
    return _classApplyDescriptorGet(receiver, descriptor);
  }
  function _classPrivateFieldSet(receiver, privateMap, value) {
    var descriptor = _classExtractFieldDescriptor(receiver, privateMap, "set");
    _classApplyDescriptorSet(receiver, descriptor, value);
    return value;
  }
  function _classExtractFieldDescriptor(receiver, privateMap, action2) {
    if (!privateMap.has(receiver)) {
      throw new TypeError("attempted to " + action2 + " private field on non-instance");
    }
    return privateMap.get(receiver);
  }
  function _classApplyDescriptorGet(receiver, descriptor) {
    if (descriptor.get) {
      return descriptor.get.call(receiver);
    }
    return descriptor.value;
  }
  function _classApplyDescriptorSet(receiver, descriptor, value) {
    if (descriptor.set) {
      descriptor.set.call(receiver, value);
    } else {
      if (!descriptor.writable) {
        throw new TypeError("attempted to set read only private field");
      }
      descriptor.value = value;
    }
  }
  function _checkPrivateRedeclaration(obj, privateCollection) {
    if (privateCollection.has(obj)) {
      throw new TypeError("Cannot initialize the same private elements twice on an object");
    }
  }
  function _classPrivateFieldInitSpec(obj, privateMap, value) {
    _checkPrivateRedeclaration(obj, privateMap);
    privateMap.set(obj, value);
  }
  function getType(opt) {
    var type = Object.prototype.hasOwnProperty.call(opt, "type") && opt.type;
    if (!type) return "cardinal";
    if (type === "cardinal" || type === "ordinal") return type;
    throw new RangeError("Not a valid plural type: " + JSON.stringify(type));
  }
  function toNumber(value) {
    switch (_typeof(value)) {
      case "number":
        return value;
      case "bigint":
        throw new TypeError("Cannot convert a BigInt value to a number");
      default:
        return Number(value);
    }
  }
  function getPluralRules(NumberFormat, getSelector, getCategories, getRangeSelector) {
    var findLocale = function findLocale2(locale) {
      do {
        if (getSelector(locale)) return locale;
        locale = locale.replace(/-?[^-]*$/, "");
      } while (locale);
      return null;
    };
    var resolveLocale = function resolveLocale2(locales) {
      var canonicalLocales = canonicalizeLocaleList(locales);
      for (var i = 0; i < canonicalLocales.length; ++i) {
        var _lc = findLocale(canonicalLocales[i]);
        if (_lc) return _lc;
      }
      var lc = new NumberFormat().resolvedOptions().locale;
      return findLocale(lc);
    };
    var _locale = /* @__PURE__ */ new WeakMap();
    var _range = /* @__PURE__ */ new WeakMap();
    var _select = /* @__PURE__ */ new WeakMap();
    var _type = /* @__PURE__ */ new WeakMap();
    var _nf = /* @__PURE__ */ new WeakMap();
    var PluralRules = /* @__PURE__ */ (function() {
      function PluralRules2() {
        var locales = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : [];
        var opt = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
        _classCallCheck(this, PluralRules2);
        _classPrivateFieldInitSpec(this, _locale, {
          writable: true,
          value: void 0
        });
        _classPrivateFieldInitSpec(this, _range, {
          writable: true,
          value: void 0
        });
        _classPrivateFieldInitSpec(this, _select, {
          writable: true,
          value: void 0
        });
        _classPrivateFieldInitSpec(this, _type, {
          writable: true,
          value: void 0
        });
        _classPrivateFieldInitSpec(this, _nf, {
          writable: true,
          value: void 0
        });
        _classPrivateFieldSet(this, _locale, resolveLocale(locales));
        _classPrivateFieldSet(this, _select, getSelector(_classPrivateFieldGet(this, _locale)));
        _classPrivateFieldSet(this, _range, getRangeSelector(_classPrivateFieldGet(this, _locale)));
        _classPrivateFieldSet(this, _type, getType(opt));
        _classPrivateFieldSet(this, _nf, new NumberFormat("en", opt));
      }
      _createClass(PluralRules2, [{
        key: "resolvedOptions",
        value: function resolvedOptions() {
          var _classPrivateFieldGet2 = _classPrivateFieldGet(this, _nf).resolvedOptions(), minimumIntegerDigits = _classPrivateFieldGet2.minimumIntegerDigits, minimumFractionDigits = _classPrivateFieldGet2.minimumFractionDigits, maximumFractionDigits = _classPrivateFieldGet2.maximumFractionDigits, minimumSignificantDigits = _classPrivateFieldGet2.minimumSignificantDigits, maximumSignificantDigits = _classPrivateFieldGet2.maximumSignificantDigits, roundingPriority = _classPrivateFieldGet2.roundingPriority;
          var opt = {
            locale: _classPrivateFieldGet(this, _locale),
            type: _classPrivateFieldGet(this, _type),
            minimumIntegerDigits,
            minimumFractionDigits,
            maximumFractionDigits
          };
          if (typeof minimumSignificantDigits === "number") {
            opt.minimumSignificantDigits = minimumSignificantDigits;
            opt.maximumSignificantDigits = maximumSignificantDigits;
          }
          opt.pluralCategories = getCategories(_classPrivateFieldGet(this, _locale), _classPrivateFieldGet(this, _type) === "ordinal").slice(0);
          opt.roundingPriority = roundingPriority || "auto";
          return opt;
        }
      }, {
        key: "select",
        value: function select(number) {
          if (!(this instanceof PluralRules2)) throw new TypeError("select() called on incompatible ".concat(this));
          if (typeof number !== "number") number = Number(number);
          if (!isFinite(number)) return "other";
          var fmt = _classPrivateFieldGet(this, _nf).format(Math.abs(number));
          return _classPrivateFieldGet(this, _select).call(this, fmt, _classPrivateFieldGet(this, _type) === "ordinal");
        }
      }, {
        key: "selectRange",
        value: function selectRange(start, end) {
          if (!(this instanceof PluralRules2)) throw new TypeError("selectRange() called on incompatible ".concat(this));
          if (start === void 0) throw new TypeError("start is undefined");
          if (end === void 0) throw new TypeError("end is undefined");
          var start_ = toNumber(start);
          var end_ = toNumber(end);
          if (!isFinite(start_)) throw new RangeError("start must be finite");
          if (!isFinite(end_)) throw new RangeError("end must be finite");
          return _classPrivateFieldGet(this, _range).call(this, this.select(start_), this.select(end_));
        }
      }], [{
        key: "supportedLocalesOf",
        value: function supportedLocalesOf(locales) {
          return canonicalizeLocaleList(locales).filter(findLocale);
        }
      }]);
      return PluralRules2;
    })();
    if (typeof Symbol !== "undefined" && Symbol.toStringTag) {
      Object.defineProperty(PluralRules.prototype, Symbol.toStringTag, {
        value: "Intl.PluralRules",
        writable: false,
        configurable: true
      });
    }
    Object.defineProperty(PluralRules, "prototype", {
      writable: false
    });
    return PluralRules;
  }
  var canonicalizeLocaleList;
  var init_factory = __esm({
    "node_modules/intl-pluralrules/factory.mjs"() {
      canonicalizeLocaleList = function canonicalizeLocaleList2(locales) {
        if (!locales) return [];
        if (!Array.isArray(locales)) locales = [locales];
        var res = {};
        for (var i = 0; i < locales.length; ++i) {
          var _in$iw$ji$lc;
          var tag2 = locales[i];
          if (tag2 && _typeof(tag2) === "object") tag2 = String(tag2);
          if (typeof tag2 !== "string") {
            var msg = "Locales should be strings, ".concat(JSON.stringify(tag2), " isn't.");
            throw new TypeError(msg);
          }
          var parts = tag2.split("-");
          if (!parts.every(function(subtag) {
            return /[a-z0-9]+/i.test(subtag);
          })) {
            var strTag = JSON.stringify(tag2);
            var _msg = "The locale ".concat(strTag, " is not a structurally valid BCP 47 language tag.");
            throw new RangeError(_msg);
          }
          var lc = parts[0].toLowerCase();
          parts[0] = (_in$iw$ji$lc = {
            in: "id",
            iw: "he",
            ji: "yi"
          }[lc]) !== null && _in$iw$ji$lc !== void 0 ? _in$iw$ji$lc : lc;
          res[parts.join("-")] = true;
        }
        return Object.keys(res);
      };
    }
  });

  // node_modules/intl-pluralrules/plural-rules.js
  var require_plural_rules = __commonJS({
    "node_modules/intl-pluralrules/plural-rules.js"(exports, module) {
      "use strict";
      var getPluralRules2 = (init_factory(), __toCommonJS(factory_exports));
      function _interopDefaultLegacy(e) {
        return e && typeof e === "object" && "default" in e ? e : { "default": e };
      }
      function _mergeNamespaces(n, m) {
        m.forEach(function(e) {
          e && typeof e !== "string" && !Array.isArray(e) && Object.keys(e).forEach(function(k) {
            if (k !== "default" && !(k in n)) {
              var d = Object.getOwnPropertyDescriptor(e, k);
              Object.defineProperty(n, k, d.get ? d : {
                enumerable: true,
                get: function() {
                  return e[k];
                }
              });
            }
          });
        });
        return Object.freeze(n);
      }
      var getPluralRules__default = /* @__PURE__ */ _interopDefaultLegacy(getPluralRules2);
      var commonjsGlobal = typeof globalThis !== "undefined" ? globalThis : typeof window !== "undefined" ? window : typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : {};
      function getDefaultExportFromCjs(x) {
        return x && x.__esModule && Object.prototype.hasOwnProperty.call(x, "default") ? x["default"] : x;
      }
      var plurals$1 = { exports: {} };
      (function(module2, exports2) {
        var a = function a2(n, ord) {
          if (ord) return "other";
          return n == 1 ? "one" : "other";
        };
        var b = function b2(n, ord) {
          if (ord) return "other";
          return n == 0 || n == 1 ? "one" : "other";
        };
        var c = function c2(n, ord) {
          if (ord) return "other";
          return n >= 0 && n <= 1 ? "one" : "other";
        };
        var d = function d2(n, ord) {
          var s = String(n).split("."), v0 = !s[1];
          if (ord) return "other";
          return n == 1 && v0 ? "one" : "other";
        };
        var e = function e2(n, ord) {
          return "other";
        };
        var f = function f2(n, ord) {
          if (ord) return "other";
          return n == 1 ? "one" : n == 2 ? "two" : "other";
        };
        (function(root4, plurals2) {
          Object.defineProperty(plurals2, "__esModule", {
            value: true
          });
          module2.exports = plurals2;
        })(commonjsGlobal, {
          af: a,
          ak: b,
          am: c,
          an: a,
          ar: function ar(n, ord) {
            var s = String(n).split("."), t0 = Number(s[0]) == n, n100 = t0 && s[0].slice(-2);
            if (ord) return "other";
            return n == 0 ? "zero" : n == 1 ? "one" : n == 2 ? "two" : n100 >= 3 && n100 <= 10 ? "few" : n100 >= 11 && n100 <= 99 ? "many" : "other";
          },
          ars: function ars(n, ord) {
            var s = String(n).split("."), t0 = Number(s[0]) == n, n100 = t0 && s[0].slice(-2);
            if (ord) return "other";
            return n == 0 ? "zero" : n == 1 ? "one" : n == 2 ? "two" : n100 >= 3 && n100 <= 10 ? "few" : n100 >= 11 && n100 <= 99 ? "many" : "other";
          },
          as: function as(n, ord) {
            if (ord) return n == 1 || n == 5 || n == 7 || n == 8 || n == 9 || n == 10 ? "one" : n == 2 || n == 3 ? "two" : n == 4 ? "few" : n == 6 ? "many" : "other";
            return n >= 0 && n <= 1 ? "one" : "other";
          },
          asa: a,
          ast: d,
          az: function az(n, ord) {
            var s = String(n).split("."), i = s[0], i10 = i.slice(-1), i100 = i.slice(-2), i1000 = i.slice(-3);
            if (ord) return i10 == 1 || i10 == 2 || i10 == 5 || i10 == 7 || i10 == 8 || i100 == 20 || i100 == 50 || i100 == 70 || i100 == 80 ? "one" : i10 == 3 || i10 == 4 || i1000 == 100 || i1000 == 200 || i1000 == 300 || i1000 == 400 || i1000 == 500 || i1000 == 600 || i1000 == 700 || i1000 == 800 || i1000 == 900 ? "few" : i == 0 || i10 == 6 || i100 == 40 || i100 == 60 || i100 == 90 ? "many" : "other";
            return n == 1 ? "one" : "other";
          },
          bal: function bal(n, ord) {
            return n == 1 ? "one" : "other";
          },
          be: function be(n, ord) {
            var s = String(n).split("."), t0 = Number(s[0]) == n, n10 = t0 && s[0].slice(-1), n100 = t0 && s[0].slice(-2);
            if (ord) return (n10 == 2 || n10 == 3) && n100 != 12 && n100 != 13 ? "few" : "other";
            return n10 == 1 && n100 != 11 ? "one" : n10 >= 2 && n10 <= 4 && (n100 < 12 || n100 > 14) ? "few" : t0 && n10 == 0 || n10 >= 5 && n10 <= 9 || n100 >= 11 && n100 <= 14 ? "many" : "other";
          },
          bem: a,
          bez: a,
          bg: a,
          bho: b,
          bm: e,
          bn: function bn(n, ord) {
            if (ord) return n == 1 || n == 5 || n == 7 || n == 8 || n == 9 || n == 10 ? "one" : n == 2 || n == 3 ? "two" : n == 4 ? "few" : n == 6 ? "many" : "other";
            return n >= 0 && n <= 1 ? "one" : "other";
          },
          bo: e,
          br: function br(n, ord) {
            var s = String(n).split("."), t0 = Number(s[0]) == n, n10 = t0 && s[0].slice(-1), n100 = t0 && s[0].slice(-2), n1000000 = t0 && s[0].slice(-6);
            if (ord) return "other";
            return n10 == 1 && n100 != 11 && n100 != 71 && n100 != 91 ? "one" : n10 == 2 && n100 != 12 && n100 != 72 && n100 != 92 ? "two" : (n10 == 3 || n10 == 4 || n10 == 9) && (n100 < 10 || n100 > 19) && (n100 < 70 || n100 > 79) && (n100 < 90 || n100 > 99) ? "few" : n != 0 && t0 && n1000000 == 0 ? "many" : "other";
          },
          brx: a,
          bs: function bs(n, ord) {
            var s = String(n).split("."), i = s[0], f2 = s[1] || "", v0 = !s[1], i10 = i.slice(-1), i100 = i.slice(-2), f10 = f2.slice(-1), f100 = f2.slice(-2);
            if (ord) return "other";
            return v0 && i10 == 1 && i100 != 11 || f10 == 1 && f100 != 11 ? "one" : v0 && i10 >= 2 && i10 <= 4 && (i100 < 12 || i100 > 14) || f10 >= 2 && f10 <= 4 && (f100 < 12 || f100 > 14) ? "few" : "other";
          },
          ca: function ca(n, ord) {
            var s = String(n).split("."), i = s[0], v0 = !s[1], i1000000 = i.slice(-6);
            if (ord) return n == 1 || n == 3 ? "one" : n == 2 ? "two" : n == 4 ? "few" : "other";
            return n == 1 && v0 ? "one" : i != 0 && i1000000 == 0 && v0 ? "many" : "other";
          },
          ce: a,
          ceb: function ceb(n, ord) {
            var s = String(n).split("."), i = s[0], f2 = s[1] || "", v0 = !s[1], i10 = i.slice(-1), f10 = f2.slice(-1);
            if (ord) return "other";
            return v0 && (i == 1 || i == 2 || i == 3) || v0 && i10 != 4 && i10 != 6 && i10 != 9 || !v0 && f10 != 4 && f10 != 6 && f10 != 9 ? "one" : "other";
          },
          cgg: a,
          chr: a,
          ckb: a,
          cs: function cs(n, ord) {
            var s = String(n).split("."), i = s[0], v0 = !s[1];
            if (ord) return "other";
            return n == 1 && v0 ? "one" : i >= 2 && i <= 4 && v0 ? "few" : !v0 ? "many" : "other";
          },
          cy: function cy(n, ord) {
            if (ord) return n == 0 || n == 7 || n == 8 || n == 9 ? "zero" : n == 1 ? "one" : n == 2 ? "two" : n == 3 || n == 4 ? "few" : n == 5 || n == 6 ? "many" : "other";
            return n == 0 ? "zero" : n == 1 ? "one" : n == 2 ? "two" : n == 3 ? "few" : n == 6 ? "many" : "other";
          },
          da: function da(n, ord) {
            var s = String(n).split("."), i = s[0], t0 = Number(s[0]) == n;
            if (ord) return "other";
            return n == 1 || !t0 && (i == 0 || i == 1) ? "one" : "other";
          },
          de: d,
          doi: c,
          dsb: function dsb(n, ord) {
            var s = String(n).split("."), i = s[0], f2 = s[1] || "", v0 = !s[1], i100 = i.slice(-2), f100 = f2.slice(-2);
            if (ord) return "other";
            return v0 && i100 == 1 || f100 == 1 ? "one" : v0 && i100 == 2 || f100 == 2 ? "two" : v0 && (i100 == 3 || i100 == 4) || f100 == 3 || f100 == 4 ? "few" : "other";
          },
          dv: a,
          dz: e,
          ee: a,
          el: a,
          en: function en(n, ord) {
            var s = String(n).split("."), v0 = !s[1], t0 = Number(s[0]) == n, n10 = t0 && s[0].slice(-1), n100 = t0 && s[0].slice(-2);
            if (ord) return n10 == 1 && n100 != 11 ? "one" : n10 == 2 && n100 != 12 ? "two" : n10 == 3 && n100 != 13 ? "few" : "other";
            return n == 1 && v0 ? "one" : "other";
          },
          eo: a,
          es: function es(n, ord) {
            var s = String(n).split("."), i = s[0], v0 = !s[1], i1000000 = i.slice(-6);
            if (ord) return "other";
            return n == 1 ? "one" : i != 0 && i1000000 == 0 && v0 ? "many" : "other";
          },
          et: d,
          eu: a,
          fa: c,
          ff: function ff(n, ord) {
            if (ord) return "other";
            return n >= 0 && n < 2 ? "one" : "other";
          },
          fi: d,
          fil: function fil(n, ord) {
            var s = String(n).split("."), i = s[0], f2 = s[1] || "", v0 = !s[1], i10 = i.slice(-1), f10 = f2.slice(-1);
            if (ord) return n == 1 ? "one" : "other";
            return v0 && (i == 1 || i == 2 || i == 3) || v0 && i10 != 4 && i10 != 6 && i10 != 9 || !v0 && f10 != 4 && f10 != 6 && f10 != 9 ? "one" : "other";
          },
          fo: a,
          fr: function fr(n, ord) {
            var s = String(n).split("."), i = s[0], v0 = !s[1], i1000000 = i.slice(-6);
            if (ord) return n == 1 ? "one" : "other";
            return n >= 0 && n < 2 ? "one" : i != 0 && i1000000 == 0 && v0 ? "many" : "other";
          },
          fur: a,
          fy: d,
          ga: function ga(n, ord) {
            var s = String(n).split("."), t0 = Number(s[0]) == n;
            if (ord) return n == 1 ? "one" : "other";
            return n == 1 ? "one" : n == 2 ? "two" : t0 && n >= 3 && n <= 6 ? "few" : t0 && n >= 7 && n <= 10 ? "many" : "other";
          },
          gd: function gd(n, ord) {
            var s = String(n).split("."), t0 = Number(s[0]) == n;
            if (ord) return n == 1 || n == 11 ? "one" : n == 2 || n == 12 ? "two" : n == 3 || n == 13 ? "few" : "other";
            return n == 1 || n == 11 ? "one" : n == 2 || n == 12 ? "two" : t0 && n >= 3 && n <= 10 || t0 && n >= 13 && n <= 19 ? "few" : "other";
          },
          gl: d,
          gsw: a,
          gu: function gu(n, ord) {
            if (ord) return n == 1 ? "one" : n == 2 || n == 3 ? "two" : n == 4 ? "few" : n == 6 ? "many" : "other";
            return n >= 0 && n <= 1 ? "one" : "other";
          },
          guw: b,
          gv: function gv(n, ord) {
            var s = String(n).split("."), i = s[0], v0 = !s[1], i10 = i.slice(-1), i100 = i.slice(-2);
            if (ord) return "other";
            return v0 && i10 == 1 ? "one" : v0 && i10 == 2 ? "two" : v0 && (i100 == 0 || i100 == 20 || i100 == 40 || i100 == 60 || i100 == 80) ? "few" : !v0 ? "many" : "other";
          },
          ha: a,
          haw: a,
          he: function he(n, ord) {
            var s = String(n).split("."), i = s[0], v0 = !s[1];
            if (ord) return "other";
            return i == 1 && v0 || i == 0 && !v0 ? "one" : i == 2 && v0 ? "two" : "other";
          },
          hi: function hi(n, ord) {
            if (ord) return n == 1 ? "one" : n == 2 || n == 3 ? "two" : n == 4 ? "few" : n == 6 ? "many" : "other";
            return n >= 0 && n <= 1 ? "one" : "other";
          },
          hnj: e,
          hr: function hr(n, ord) {
            var s = String(n).split("."), i = s[0], f2 = s[1] || "", v0 = !s[1], i10 = i.slice(-1), i100 = i.slice(-2), f10 = f2.slice(-1), f100 = f2.slice(-2);
            if (ord) return "other";
            return v0 && i10 == 1 && i100 != 11 || f10 == 1 && f100 != 11 ? "one" : v0 && i10 >= 2 && i10 <= 4 && (i100 < 12 || i100 > 14) || f10 >= 2 && f10 <= 4 && (f100 < 12 || f100 > 14) ? "few" : "other";
          },
          hsb: function hsb(n, ord) {
            var s = String(n).split("."), i = s[0], f2 = s[1] || "", v0 = !s[1], i100 = i.slice(-2), f100 = f2.slice(-2);
            if (ord) return "other";
            return v0 && i100 == 1 || f100 == 1 ? "one" : v0 && i100 == 2 || f100 == 2 ? "two" : v0 && (i100 == 3 || i100 == 4) || f100 == 3 || f100 == 4 ? "few" : "other";
          },
          hu: function hu(n, ord) {
            if (ord) return n == 1 || n == 5 ? "one" : "other";
            return n == 1 ? "one" : "other";
          },
          hy: function hy(n, ord) {
            if (ord) return n == 1 ? "one" : "other";
            return n >= 0 && n < 2 ? "one" : "other";
          },
          ia: d,
          id: e,
          ig: e,
          ii: e,
          io: d,
          is: function is2(n, ord) {
            var s = String(n).split("."), i = s[0], t = (s[1] || "").replace(/0+$/, ""), t0 = Number(s[0]) == n, i10 = i.slice(-1), i100 = i.slice(-2);
            if (ord) return "other";
            return t0 && i10 == 1 && i100 != 11 || t % 10 == 1 && t % 100 != 11 ? "one" : "other";
          },
          it: function it(n, ord) {
            var s = String(n).split("."), i = s[0], v0 = !s[1], i1000000 = i.slice(-6);
            if (ord) return n == 11 || n == 8 || n == 80 || n == 800 ? "many" : "other";
            return n == 1 && v0 ? "one" : i != 0 && i1000000 == 0 && v0 ? "many" : "other";
          },
          iu: f,
          ja: e,
          jbo: e,
          jgo: a,
          jmc: a,
          jv: e,
          jw: e,
          ka: function ka(n, ord) {
            var s = String(n).split("."), i = s[0], i100 = i.slice(-2);
            if (ord) return i == 1 ? "one" : i == 0 || i100 >= 2 && i100 <= 20 || i100 == 40 || i100 == 60 || i100 == 80 ? "many" : "other";
            return n == 1 ? "one" : "other";
          },
          kab: function kab(n, ord) {
            if (ord) return "other";
            return n >= 0 && n < 2 ? "one" : "other";
          },
          kaj: a,
          kcg: a,
          kde: e,
          kea: e,
          kk: function kk(n, ord) {
            var s = String(n).split("."), t0 = Number(s[0]) == n, n10 = t0 && s[0].slice(-1);
            if (ord) return n10 == 6 || n10 == 9 || t0 && n10 == 0 && n != 0 ? "many" : "other";
            return n == 1 ? "one" : "other";
          },
          kkj: a,
          kl: a,
          km: e,
          kn: c,
          ko: e,
          ks: a,
          ksb: a,
          ksh: function ksh(n, ord) {
            if (ord) return "other";
            return n == 0 ? "zero" : n == 1 ? "one" : "other";
          },
          ku: a,
          kw: function kw(n, ord) {
            var s = String(n).split("."), t0 = Number(s[0]) == n, n100 = t0 && s[0].slice(-2), n1000 = t0 && s[0].slice(-3), n100000 = t0 && s[0].slice(-5), n1000000 = t0 && s[0].slice(-6);
            if (ord) return t0 && n >= 1 && n <= 4 || n100 >= 1 && n100 <= 4 || n100 >= 21 && n100 <= 24 || n100 >= 41 && n100 <= 44 || n100 >= 61 && n100 <= 64 || n100 >= 81 && n100 <= 84 ? "one" : n == 5 || n100 == 5 ? "many" : "other";
            return n == 0 ? "zero" : n == 1 ? "one" : n100 == 2 || n100 == 22 || n100 == 42 || n100 == 62 || n100 == 82 || t0 && n1000 == 0 && (n100000 >= 1e3 && n100000 <= 2e4 || n100000 == 4e4 || n100000 == 6e4 || n100000 == 8e4) || n != 0 && n1000000 == 1e5 ? "two" : n100 == 3 || n100 == 23 || n100 == 43 || n100 == 63 || n100 == 83 ? "few" : n != 1 && (n100 == 1 || n100 == 21 || n100 == 41 || n100 == 61 || n100 == 81) ? "many" : "other";
          },
          ky: a,
          lag: function lag(n, ord) {
            var s = String(n).split("."), i = s[0];
            if (ord) return "other";
            return n == 0 ? "zero" : (i == 0 || i == 1) && n != 0 ? "one" : "other";
          },
          lb: a,
          lg: a,
          lij: function lij(n, ord) {
            var s = String(n).split("."), v0 = !s[1], t0 = Number(s[0]) == n;
            if (ord) return n == 11 || n == 8 || t0 && n >= 80 && n <= 89 || t0 && n >= 800 && n <= 899 ? "many" : "other";
            return n == 1 && v0 ? "one" : "other";
          },
          lkt: e,
          ln: b,
          lo: function lo(n, ord) {
            if (ord) return n == 1 ? "one" : "other";
            return "other";
          },
          lt: function lt(n, ord) {
            var s = String(n).split("."), f2 = s[1] || "", t0 = Number(s[0]) == n, n10 = t0 && s[0].slice(-1), n100 = t0 && s[0].slice(-2);
            if (ord) return "other";
            return n10 == 1 && (n100 < 11 || n100 > 19) ? "one" : n10 >= 2 && n10 <= 9 && (n100 < 11 || n100 > 19) ? "few" : f2 != 0 ? "many" : "other";
          },
          lv: function lv(n, ord) {
            var s = String(n).split("."), f2 = s[1] || "", v = f2.length, t0 = Number(s[0]) == n, n10 = t0 && s[0].slice(-1), n100 = t0 && s[0].slice(-2), f100 = f2.slice(-2), f10 = f2.slice(-1);
            if (ord) return "other";
            return t0 && n10 == 0 || n100 >= 11 && n100 <= 19 || v == 2 && f100 >= 11 && f100 <= 19 ? "zero" : n10 == 1 && n100 != 11 || v == 2 && f10 == 1 && f100 != 11 || v != 2 && f10 == 1 ? "one" : "other";
          },
          mas: a,
          mg: b,
          mgo: a,
          mk: function mk(n, ord) {
            var s = String(n).split("."), i = s[0], f2 = s[1] || "", v0 = !s[1], i10 = i.slice(-1), i100 = i.slice(-2), f10 = f2.slice(-1), f100 = f2.slice(-2);
            if (ord) return i10 == 1 && i100 != 11 ? "one" : i10 == 2 && i100 != 12 ? "two" : (i10 == 7 || i10 == 8) && i100 != 17 && i100 != 18 ? "many" : "other";
            return v0 && i10 == 1 && i100 != 11 || f10 == 1 && f100 != 11 ? "one" : "other";
          },
          ml: a,
          mn: a,
          mo: function mo(n, ord) {
            var s = String(n).split("."), v0 = !s[1], t0 = Number(s[0]) == n, n100 = t0 && s[0].slice(-2);
            if (ord) return n == 1 ? "one" : "other";
            return n == 1 && v0 ? "one" : !v0 || n == 0 || n != 1 && n100 >= 1 && n100 <= 19 ? "few" : "other";
          },
          mr: function mr(n, ord) {
            if (ord) return n == 1 ? "one" : n == 2 || n == 3 ? "two" : n == 4 ? "few" : "other";
            return n == 1 ? "one" : "other";
          },
          ms: function ms(n, ord) {
            if (ord) return n == 1 ? "one" : "other";
            return "other";
          },
          mt: function mt(n, ord) {
            var s = String(n).split("."), t0 = Number(s[0]) == n, n100 = t0 && s[0].slice(-2);
            if (ord) return "other";
            return n == 1 ? "one" : n == 2 ? "two" : n == 0 || n100 >= 3 && n100 <= 10 ? "few" : n100 >= 11 && n100 <= 19 ? "many" : "other";
          },
          my: e,
          nah: a,
          naq: f,
          nb: a,
          nd: a,
          ne: function ne(n, ord) {
            var s = String(n).split("."), t0 = Number(s[0]) == n;
            if (ord) return t0 && n >= 1 && n <= 4 ? "one" : "other";
            return n == 1 ? "one" : "other";
          },
          nl: d,
          nn: a,
          nnh: a,
          no: a,
          nqo: e,
          nr: a,
          nso: b,
          ny: a,
          nyn: a,
          om: a,
          or: function or(n, ord) {
            var s = String(n).split("."), t0 = Number(s[0]) == n;
            if (ord) return n == 1 || n == 5 || t0 && n >= 7 && n <= 9 ? "one" : n == 2 || n == 3 ? "two" : n == 4 ? "few" : n == 6 ? "many" : "other";
            return n == 1 ? "one" : "other";
          },
          os: a,
          osa: e,
          pa: b,
          pap: a,
          pcm: c,
          pl: function pl(n, ord) {
            var s = String(n).split("."), i = s[0], v0 = !s[1], i10 = i.slice(-1), i100 = i.slice(-2);
            if (ord) return "other";
            return n == 1 && v0 ? "one" : v0 && i10 >= 2 && i10 <= 4 && (i100 < 12 || i100 > 14) ? "few" : v0 && i != 1 && (i10 == 0 || i10 == 1) || v0 && i10 >= 5 && i10 <= 9 || v0 && i100 >= 12 && i100 <= 14 ? "many" : "other";
          },
          prg: function prg(n, ord) {
            var s = String(n).split("."), f2 = s[1] || "", v = f2.length, t0 = Number(s[0]) == n, n10 = t0 && s[0].slice(-1), n100 = t0 && s[0].slice(-2), f100 = f2.slice(-2), f10 = f2.slice(-1);
            if (ord) return "other";
            return t0 && n10 == 0 || n100 >= 11 && n100 <= 19 || v == 2 && f100 >= 11 && f100 <= 19 ? "zero" : n10 == 1 && n100 != 11 || v == 2 && f10 == 1 && f100 != 11 || v != 2 && f10 == 1 ? "one" : "other";
          },
          ps: a,
          pt: function pt(n, ord) {
            var s = String(n).split("."), i = s[0], v0 = !s[1], i1000000 = i.slice(-6);
            if (ord) return "other";
            return i == 0 || i == 1 ? "one" : i != 0 && i1000000 == 0 && v0 ? "many" : "other";
          },
          pt_PT: function pt_PT(n, ord) {
            var s = String(n).split("."), i = s[0], v0 = !s[1], i1000000 = i.slice(-6);
            if (ord) return "other";
            return n == 1 && v0 ? "one" : i != 0 && i1000000 == 0 && v0 ? "many" : "other";
          },
          rm: a,
          ro: function ro(n, ord) {
            var s = String(n).split("."), v0 = !s[1], t0 = Number(s[0]) == n, n100 = t0 && s[0].slice(-2);
            if (ord) return n == 1 ? "one" : "other";
            return n == 1 && v0 ? "one" : !v0 || n == 0 || n != 1 && n100 >= 1 && n100 <= 19 ? "few" : "other";
          },
          rof: a,
          ru: function ru(n, ord) {
            var s = String(n).split("."), i = s[0], v0 = !s[1], i10 = i.slice(-1), i100 = i.slice(-2);
            if (ord) return "other";
            return v0 && i10 == 1 && i100 != 11 ? "one" : v0 && i10 >= 2 && i10 <= 4 && (i100 < 12 || i100 > 14) ? "few" : v0 && i10 == 0 || v0 && i10 >= 5 && i10 <= 9 || v0 && i100 >= 11 && i100 <= 14 ? "many" : "other";
          },
          rwk: a,
          sah: e,
          saq: a,
          sat: f,
          sc: function sc(n, ord) {
            var s = String(n).split("."), v0 = !s[1];
            if (ord) return n == 11 || n == 8 || n == 80 || n == 800 ? "many" : "other";
            return n == 1 && v0 ? "one" : "other";
          },
          scn: function scn(n, ord) {
            var s = String(n).split("."), v0 = !s[1];
            if (ord) return n == 11 || n == 8 || n == 80 || n == 800 ? "many" : "other";
            return n == 1 && v0 ? "one" : "other";
          },
          sd: a,
          sdh: a,
          se: f,
          seh: a,
          ses: e,
          sg: e,
          sh: function sh(n, ord) {
            var s = String(n).split("."), i = s[0], f2 = s[1] || "", v0 = !s[1], i10 = i.slice(-1), i100 = i.slice(-2), f10 = f2.slice(-1), f100 = f2.slice(-2);
            if (ord) return "other";
            return v0 && i10 == 1 && i100 != 11 || f10 == 1 && f100 != 11 ? "one" : v0 && i10 >= 2 && i10 <= 4 && (i100 < 12 || i100 > 14) || f10 >= 2 && f10 <= 4 && (f100 < 12 || f100 > 14) ? "few" : "other";
          },
          shi: function shi(n, ord) {
            var s = String(n).split("."), t0 = Number(s[0]) == n;
            if (ord) return "other";
            return n >= 0 && n <= 1 ? "one" : t0 && n >= 2 && n <= 10 ? "few" : "other";
          },
          si: function si(n, ord) {
            var s = String(n).split("."), i = s[0], f2 = s[1] || "";
            if (ord) return "other";
            return n == 0 || n == 1 || i == 0 && f2 == 1 ? "one" : "other";
          },
          sk: function sk(n, ord) {
            var s = String(n).split("."), i = s[0], v0 = !s[1];
            if (ord) return "other";
            return n == 1 && v0 ? "one" : i >= 2 && i <= 4 && v0 ? "few" : !v0 ? "many" : "other";
          },
          sl: function sl(n, ord) {
            var s = String(n).split("."), i = s[0], v0 = !s[1], i100 = i.slice(-2);
            if (ord) return "other";
            return v0 && i100 == 1 ? "one" : v0 && i100 == 2 ? "two" : v0 && (i100 == 3 || i100 == 4) || !v0 ? "few" : "other";
          },
          sma: f,
          smi: f,
          smj: f,
          smn: f,
          sms: f,
          sn: a,
          so: a,
          sq: function sq(n, ord) {
            var s = String(n).split("."), t0 = Number(s[0]) == n, n10 = t0 && s[0].slice(-1), n100 = t0 && s[0].slice(-2);
            if (ord) return n == 1 ? "one" : n10 == 4 && n100 != 14 ? "many" : "other";
            return n == 1 ? "one" : "other";
          },
          sr: function sr(n, ord) {
            var s = String(n).split("."), i = s[0], f2 = s[1] || "", v0 = !s[1], i10 = i.slice(-1), i100 = i.slice(-2), f10 = f2.slice(-1), f100 = f2.slice(-2);
            if (ord) return "other";
            return v0 && i10 == 1 && i100 != 11 || f10 == 1 && f100 != 11 ? "one" : v0 && i10 >= 2 && i10 <= 4 && (i100 < 12 || i100 > 14) || f10 >= 2 && f10 <= 4 && (f100 < 12 || f100 > 14) ? "few" : "other";
          },
          ss: a,
          ssy: a,
          st: a,
          su: e,
          sv: function sv(n, ord) {
            var s = String(n).split("."), v0 = !s[1], t0 = Number(s[0]) == n, n10 = t0 && s[0].slice(-1), n100 = t0 && s[0].slice(-2);
            if (ord) return (n10 == 1 || n10 == 2) && n100 != 11 && n100 != 12 ? "one" : "other";
            return n == 1 && v0 ? "one" : "other";
          },
          sw: d,
          syr: a,
          ta: a,
          te: a,
          teo: a,
          th: e,
          ti: b,
          tig: a,
          tk: function tk(n, ord) {
            var s = String(n).split("."), t0 = Number(s[0]) == n, n10 = t0 && s[0].slice(-1);
            if (ord) return n10 == 6 || n10 == 9 || n == 10 ? "few" : "other";
            return n == 1 ? "one" : "other";
          },
          tl: function tl(n, ord) {
            var s = String(n).split("."), i = s[0], f2 = s[1] || "", v0 = !s[1], i10 = i.slice(-1), f10 = f2.slice(-1);
            if (ord) return n == 1 ? "one" : "other";
            return v0 && (i == 1 || i == 2 || i == 3) || v0 && i10 != 4 && i10 != 6 && i10 != 9 || !v0 && f10 != 4 && f10 != 6 && f10 != 9 ? "one" : "other";
          },
          tn: a,
          to: e,
          tpi: e,
          tr: a,
          ts: a,
          tzm: function tzm(n, ord) {
            var s = String(n).split("."), t0 = Number(s[0]) == n;
            if (ord) return "other";
            return n == 0 || n == 1 || t0 && n >= 11 && n <= 99 ? "one" : "other";
          },
          ug: a,
          uk: function uk(n, ord) {
            var s = String(n).split("."), i = s[0], v0 = !s[1], t0 = Number(s[0]) == n, n10 = t0 && s[0].slice(-1), n100 = t0 && s[0].slice(-2), i10 = i.slice(-1), i100 = i.slice(-2);
            if (ord) return n10 == 3 && n100 != 13 ? "few" : "other";
            return v0 && i10 == 1 && i100 != 11 ? "one" : v0 && i10 >= 2 && i10 <= 4 && (i100 < 12 || i100 > 14) ? "few" : v0 && i10 == 0 || v0 && i10 >= 5 && i10 <= 9 || v0 && i100 >= 11 && i100 <= 14 ? "many" : "other";
          },
          und: e,
          ur: d,
          uz: a,
          ve: a,
          vec: function vec(n, ord) {
            var s = String(n).split("."), i = s[0], v0 = !s[1], i1000000 = i.slice(-6);
            if (ord) return n == 11 || n == 8 || n == 80 || n == 800 ? "many" : "other";
            return n == 1 && v0 ? "one" : i != 0 && i1000000 == 0 && v0 ? "many" : "other";
          },
          vi: function vi(n, ord) {
            if (ord) return n == 1 ? "one" : "other";
            return "other";
          },
          vo: a,
          vun: a,
          wa: b,
          wae: a,
          wo: e,
          xh: a,
          xog: a,
          yi: d,
          yo: e,
          yue: e,
          zh: e,
          zu: c
        });
      })(plurals$1);
      var plurals = /* @__PURE__ */ getDefaultExportFromCjs(plurals$1.exports);
      var P = /* @__PURE__ */ _mergeNamespaces({
        __proto__: null,
        "default": plurals
      }, [plurals$1.exports]);
      var pluralCategories$1 = { exports: {} };
      (function(module2, exports2) {
        var z = "zero", o = "one", t = "two", f = "few", m = "many", x = "other";
        var a = {
          cardinal: [o, x],
          ordinal: [x]
        };
        var b = {
          cardinal: [o, x],
          ordinal: [o, x]
        };
        var c = {
          cardinal: [x],
          ordinal: [x]
        };
        var d = {
          cardinal: [o, t, x],
          ordinal: [x]
        };
        (function(root4, pluralCategories2) {
          Object.defineProperty(pluralCategories2, "__esModule", {
            value: true
          });
          module2.exports = pluralCategories2;
        })(commonjsGlobal, {
          af: a,
          ak: a,
          am: a,
          an: a,
          ar: {
            cardinal: [z, o, t, f, m, x],
            ordinal: [x]
          },
          ars: {
            cardinal: [z, o, t, f, m, x],
            ordinal: [x]
          },
          as: {
            cardinal: [o, x],
            ordinal: [o, t, f, m, x]
          },
          asa: a,
          ast: a,
          az: {
            cardinal: [o, x],
            ordinal: [o, f, m, x]
          },
          bal: b,
          be: {
            cardinal: [o, f, m, x],
            ordinal: [f, x]
          },
          bem: a,
          bez: a,
          bg: a,
          bho: a,
          bm: c,
          bn: {
            cardinal: [o, x],
            ordinal: [o, t, f, m, x]
          },
          bo: c,
          br: {
            cardinal: [o, t, f, m, x],
            ordinal: [x]
          },
          brx: a,
          bs: {
            cardinal: [o, f, x],
            ordinal: [x]
          },
          ca: {
            cardinal: [o, m, x],
            ordinal: [o, t, f, x]
          },
          ce: a,
          ceb: a,
          cgg: a,
          chr: a,
          ckb: a,
          cs: {
            cardinal: [o, f, m, x],
            ordinal: [x]
          },
          cy: {
            cardinal: [z, o, t, f, m, x],
            ordinal: [z, o, t, f, m, x]
          },
          da: a,
          de: a,
          doi: a,
          dsb: {
            cardinal: [o, t, f, x],
            ordinal: [x]
          },
          dv: a,
          dz: c,
          ee: a,
          el: a,
          en: {
            cardinal: [o, x],
            ordinal: [o, t, f, x]
          },
          eo: a,
          es: {
            cardinal: [o, m, x],
            ordinal: [x]
          },
          et: a,
          eu: a,
          fa: a,
          ff: a,
          fi: a,
          fil: b,
          fo: a,
          fr: {
            cardinal: [o, m, x],
            ordinal: [o, x]
          },
          fur: a,
          fy: a,
          ga: {
            cardinal: [o, t, f, m, x],
            ordinal: [o, x]
          },
          gd: {
            cardinal: [o, t, f, x],
            ordinal: [o, t, f, x]
          },
          gl: a,
          gsw: a,
          gu: {
            cardinal: [o, x],
            ordinal: [o, t, f, m, x]
          },
          guw: a,
          gv: {
            cardinal: [o, t, f, m, x],
            ordinal: [x]
          },
          ha: a,
          haw: a,
          he: d,
          hi: {
            cardinal: [o, x],
            ordinal: [o, t, f, m, x]
          },
          hnj: c,
          hr: {
            cardinal: [o, f, x],
            ordinal: [x]
          },
          hsb: {
            cardinal: [o, t, f, x],
            ordinal: [x]
          },
          hu: b,
          hy: b,
          ia: a,
          id: c,
          ig: c,
          ii: c,
          io: a,
          is: a,
          it: {
            cardinal: [o, m, x],
            ordinal: [m, x]
          },
          iu: d,
          ja: c,
          jbo: c,
          jgo: a,
          jmc: a,
          jv: c,
          jw: c,
          ka: {
            cardinal: [o, x],
            ordinal: [o, m, x]
          },
          kab: a,
          kaj: a,
          kcg: a,
          kde: c,
          kea: c,
          kk: {
            cardinal: [o, x],
            ordinal: [m, x]
          },
          kkj: a,
          kl: a,
          km: c,
          kn: a,
          ko: c,
          ks: a,
          ksb: a,
          ksh: {
            cardinal: [z, o, x],
            ordinal: [x]
          },
          ku: a,
          kw: {
            cardinal: [z, o, t, f, m, x],
            ordinal: [o, m, x]
          },
          ky: a,
          lag: {
            cardinal: [z, o, x],
            ordinal: [x]
          },
          lb: a,
          lg: a,
          lij: {
            cardinal: [o, x],
            ordinal: [m, x]
          },
          lkt: c,
          ln: a,
          lo: {
            cardinal: [x],
            ordinal: [o, x]
          },
          lt: {
            cardinal: [o, f, m, x],
            ordinal: [x]
          },
          lv: {
            cardinal: [z, o, x],
            ordinal: [x]
          },
          mas: a,
          mg: a,
          mgo: a,
          mk: {
            cardinal: [o, x],
            ordinal: [o, t, m, x]
          },
          ml: a,
          mn: a,
          mo: {
            cardinal: [o, f, x],
            ordinal: [o, x]
          },
          mr: {
            cardinal: [o, x],
            ordinal: [o, t, f, x]
          },
          ms: {
            cardinal: [x],
            ordinal: [o, x]
          },
          mt: {
            cardinal: [o, t, f, m, x],
            ordinal: [x]
          },
          my: c,
          nah: a,
          naq: d,
          nb: a,
          nd: a,
          ne: b,
          nl: a,
          nn: a,
          nnh: a,
          no: a,
          nqo: c,
          nr: a,
          nso: a,
          ny: a,
          nyn: a,
          om: a,
          or: {
            cardinal: [o, x],
            ordinal: [o, t, f, m, x]
          },
          os: a,
          osa: c,
          pa: a,
          pap: a,
          pcm: a,
          pl: {
            cardinal: [o, f, m, x],
            ordinal: [x]
          },
          prg: {
            cardinal: [z, o, x],
            ordinal: [x]
          },
          ps: a,
          pt: {
            cardinal: [o, m, x],
            ordinal: [x]
          },
          pt_PT: {
            cardinal: [o, m, x],
            ordinal: [x]
          },
          rm: a,
          ro: {
            cardinal: [o, f, x],
            ordinal: [o, x]
          },
          rof: a,
          ru: {
            cardinal: [o, f, m, x],
            ordinal: [x]
          },
          rwk: a,
          sah: c,
          saq: a,
          sat: d,
          sc: {
            cardinal: [o, x],
            ordinal: [m, x]
          },
          scn: {
            cardinal: [o, x],
            ordinal: [m, x]
          },
          sd: a,
          sdh: a,
          se: d,
          seh: a,
          ses: c,
          sg: c,
          sh: {
            cardinal: [o, f, x],
            ordinal: [x]
          },
          shi: {
            cardinal: [o, f, x],
            ordinal: [x]
          },
          si: a,
          sk: {
            cardinal: [o, f, m, x],
            ordinal: [x]
          },
          sl: {
            cardinal: [o, t, f, x],
            ordinal: [x]
          },
          sma: d,
          smi: d,
          smj: d,
          smn: d,
          sms: d,
          sn: a,
          so: a,
          sq: {
            cardinal: [o, x],
            ordinal: [o, m, x]
          },
          sr: {
            cardinal: [o, f, x],
            ordinal: [x]
          },
          ss: a,
          ssy: a,
          st: a,
          su: c,
          sv: b,
          sw: a,
          syr: a,
          ta: a,
          te: a,
          teo: a,
          th: c,
          ti: a,
          tig: a,
          tk: {
            cardinal: [o, x],
            ordinal: [f, x]
          },
          tl: b,
          tn: a,
          to: c,
          tpi: c,
          tr: a,
          ts: a,
          tzm: a,
          ug: a,
          uk: {
            cardinal: [o, f, m, x],
            ordinal: [f, x]
          },
          und: c,
          ur: a,
          uz: a,
          ve: a,
          vec: {
            cardinal: [o, m, x],
            ordinal: [m, x]
          },
          vi: {
            cardinal: [x],
            ordinal: [o, x]
          },
          vo: a,
          vun: a,
          wa: a,
          wae: a,
          wo: c,
          xh: a,
          xog: a,
          yi: a,
          yo: c,
          yue: c,
          zh: c,
          zu: a
        });
      })(pluralCategories$1);
      var pluralCategories = /* @__PURE__ */ getDefaultExportFromCjs(pluralCategories$1.exports);
      var C = /* @__PURE__ */ _mergeNamespaces({
        __proto__: null,
        "default": pluralCategories
      }, [pluralCategories$1.exports]);
      var ranges$1 = { exports: {} };
      (function(module2, exports2) {
        var a = function a2(start, end) {
          return "other";
        };
        var b = function b2(start, end) {
          return start === "other" && end === "one" ? "one" : "other";
        };
        var c = function c2(start, end) {
          return end || "other";
        };
        (function(root4, pluralRanges) {
          Object.defineProperty(pluralRanges, "__esModule", {
            value: true
          });
          module2.exports = pluralRanges;
        })(commonjsGlobal, {
          af: a,
          ak: b,
          am: c,
          an: a,
          ar: function ar(start, end) {
            return end === "few" ? "few" : end === "many" ? "many" : start === "zero" && end === "one" ? "zero" : start === "zero" && end === "two" ? "zero" : "other";
          },
          as: c,
          az: c,
          be: c,
          bg: a,
          bn: c,
          bs: c,
          ca: a,
          cs: c,
          cy: c,
          da: c,
          de: c,
          el: c,
          en: a,
          es: a,
          et: a,
          eu: a,
          fa: b,
          fi: a,
          fil: c,
          fr: c,
          ga: c,
          gl: c,
          gsw: c,
          gu: c,
          he: a,
          hi: c,
          hr: c,
          hu: c,
          hy: c,
          ia: a,
          id: a,
          io: a,
          is: c,
          it: c,
          ja: a,
          ka: function ka(start, end) {
            return start || "other";
          },
          kk: c,
          km: a,
          kn: c,
          ko: a,
          ky: c,
          lij: c,
          lo: a,
          lt: c,
          lv: function lv(start, end) {
            return end === "one" ? "one" : "other";
          },
          mk: a,
          ml: c,
          mn: c,
          mr: c,
          ms: a,
          my: a,
          nb: a,
          ne: c,
          nl: c,
          no: a,
          or: b,
          pa: c,
          pcm: a,
          pl: c,
          ps: c,
          pt: c,
          ro: function ro(start, end) {
            return end === "few" ? "few" : end === "one" ? "few" : "other";
          },
          ru: c,
          sc: c,
          scn: c,
          sd: b,
          si: function si(start, end) {
            return start === "one" && end === "one" ? "one" : "other";
          },
          sk: c,
          sl: function sl(start, end) {
            return end === "few" ? "few" : end === "one" ? "few" : end === "two" ? "two" : "other";
          },
          sq: c,
          sr: c,
          sv: a,
          sw: c,
          ta: c,
          te: c,
          th: a,
          tk: c,
          tr: c,
          ug: c,
          uk: c,
          ur: a,
          uz: c,
          vi: a,
          yue: a,
          zh: a,
          zu: c
        });
      })(ranges$1);
      var ranges = /* @__PURE__ */ getDefaultExportFromCjs(ranges$1.exports);
      var R = /* @__PURE__ */ _mergeNamespaces({
        __proto__: null,
        "default": ranges
      }, [ranges$1.exports]);
      var Plurals = plurals || P;
      var Categories = pluralCategories || C;
      var RangePlurals = ranges || R;
      var id = function id2(lc) {
        return lc === "pt-PT" ? "pt_PT" : lc;
      };
      var getSelector = function getSelector2(lc) {
        return Plurals[id(lc)];
      };
      var getCategories = function getCategories2(lc, ord) {
        return Categories[id(lc)][ord ? "ordinal" : "cardinal"];
      };
      var getRangeSelector = function getRangeSelector2(lc) {
        return RangePlurals[id(lc)];
      };
      var PluralRules = getPluralRules__default["default"](Intl.NumberFormat, getSelector, getCategories, getRangeSelector);
      module.exports = PluralRules;
    }
  });

  // node_modules/intl-pluralrules/polyfill.js
  var require_polyfill = __commonJS({
    "node_modules/intl-pluralrules/polyfill.js"(exports) {
      "use strict";
      var PluralRules = require_plural_rules();
      function _interopDefaultLegacy(e) {
        return e && typeof e === "object" && "default" in e ? e : { "default": e };
      }
      var PluralRules__default = /* @__PURE__ */ _interopDefaultLegacy(PluralRules);
      if (typeof Intl === "undefined") {
        if (typeof global !== "undefined") {
          global.Intl = {
            PluralRules: PluralRules__default["default"]
          };
        } else if (typeof window !== "undefined") {
          window.Intl = {
            PluralRules: PluralRules__default["default"]
          };
        } else {
          exports.Intl = {
            PluralRules: PluralRules__default["default"]
          };
        }
        PluralRules__default["default"].polyfill = true;
      } else if (!Intl.PluralRules || !Intl.PluralRules.prototype.selectRange) {
        Intl.PluralRules = PluralRules__default["default"];
        PluralRules__default["default"].polyfill = true;
      } else {
        test = ["en", "es", "ru", "zh"];
        supported = Intl.PluralRules.supportedLocalesOf(test);
        if (supported.length < test.length) {
          Intl.PluralRules = PluralRules__default["default"];
          PluralRules__default["default"].polyfill = true;
        }
      }
      var test;
      var supported;
    }
  });

  // ts/routes/congrats/index.ts
  var index_exports = {};
  __export(index_exports, {
    setupCongrats: () => setupCongrats
  });

  // out/ts/lib/generated/post.ts
  async function postProto(method, input, outputType, options = {}, opChangesType = 0) {
    const { alertOnError = true, signal = void 0 } = options;
    try {
      const inputBytes = input.toBinary();
      const path = `/_anki/${method}`;
      const outputBytes = await postProtoInner(path, inputBytes, opChangesType, signal);
      return outputType.fromBinary(outputBytes);
    } catch (err) {
      if (alertOnError && !(err instanceof Error && (err.message === "500: Interrupted" || err.name === "AbortError"))) {
        alert(err);
      }
      throw err;
    }
  }
  async function postProtoInner(url, body, opChangesType, signal) {
    const result = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/binary", "Anki-Op-Changes": opChangesType.toString() },
      body,
      signal
    });
    if (!result.ok) {
      let msg = "something went wrong";
      try {
        msg = await result.text();
      } catch {
      }
      throw new Error(false ? `${msg}` : `${result.status}: ${msg}`);
    }
    const blob = await result.blob();
    const respBuf = await new Response(blob).arrayBuffer();
    return new Uint8Array(respBuf);
  }

  // out/node_modules/@bufbuild/protobuf/dist/esm/private/assert.js
  function assert(condition, msg) {
    if (!condition) {
      throw new Error(msg);
    }
  }
  var FLOAT32_MAX = 34028234663852886e22;
  var FLOAT32_MIN = -34028234663852886e22;
  var UINT32_MAX = 4294967295;
  var INT32_MAX = 2147483647;
  var INT32_MIN = -2147483648;
  function assertInt32(arg) {
    if (typeof arg !== "number")
      throw new Error("invalid int 32: " + typeof arg);
    if (!Number.isInteger(arg) || arg > INT32_MAX || arg < INT32_MIN)
      throw new Error("invalid int 32: " + arg);
  }
  function assertUInt32(arg) {
    if (typeof arg !== "number")
      throw new Error("invalid uint 32: " + typeof arg);
    if (!Number.isInteger(arg) || arg > UINT32_MAX || arg < 0)
      throw new Error("invalid uint 32: " + arg);
  }
  function assertFloat32(arg) {
    if (typeof arg !== "number")
      throw new Error("invalid float 32: " + typeof arg);
    if (!Number.isFinite(arg))
      return;
    if (arg > FLOAT32_MAX || arg < FLOAT32_MIN)
      throw new Error("invalid float 32: " + arg);
  }

  // out/node_modules/@bufbuild/protobuf/dist/esm/private/enum.js
  var enumTypeSymbol = /* @__PURE__ */ Symbol("@bufbuild/protobuf/enum-type");
  function getEnumType(enumObject) {
    const t = enumObject[enumTypeSymbol];
    assert(t, "missing enum type on enum object");
    return t;
  }
  function setEnumType(enumObject, typeName, values2, opt) {
    enumObject[enumTypeSymbol] = makeEnumType(typeName, values2.map((v) => ({
      no: v.no,
      name: v.name,
      localName: enumObject[v.no]
    })), opt);
  }
  function makeEnumType(typeName, values2, _opt) {
    const names = /* @__PURE__ */ Object.create(null);
    const numbers = /* @__PURE__ */ Object.create(null);
    const normalValues = [];
    for (const value of values2) {
      const n = normalizeEnumValue(value);
      normalValues.push(n);
      names[value.name] = n;
      numbers[value.no] = n;
    }
    return {
      typeName,
      values: normalValues,
      // We do not surface options at this time
      // options: opt?.options ?? Object.create(null),
      findName(name) {
        return names[name];
      },
      findNumber(no) {
        return numbers[no];
      }
    };
  }
  function makeEnum(typeName, values2, opt) {
    const enumObject = {};
    for (const value of values2) {
      const n = normalizeEnumValue(value);
      enumObject[n.localName] = n.no;
      enumObject[n.no] = n.localName;
    }
    setEnumType(enumObject, typeName, values2, opt);
    return enumObject;
  }
  function normalizeEnumValue(value) {
    if ("localName" in value) {
      return value;
    }
    return Object.assign(Object.assign({}, value), { localName: value.name });
  }

  // out/node_modules/@bufbuild/protobuf/dist/esm/message.js
  var Message = class {
    /**
     * Compare with a message of the same type.
     * Note that this function disregards extensions and unknown fields.
     */
    equals(other) {
      return this.getType().runtime.util.equals(this.getType(), this, other);
    }
    /**
     * Create a deep copy.
     */
    clone() {
      return this.getType().runtime.util.clone(this);
    }
    /**
     * Parse from binary data, merging fields.
     *
     * Repeated fields are appended. Map entries are added, overwriting
     * existing keys.
     *
     * If a message field is already present, it will be merged with the
     * new data.
     */
    fromBinary(bytes, options) {
      const type = this.getType(), format = type.runtime.bin, opt = format.makeReadOptions(options);
      format.readMessage(this, opt.readerFactory(bytes), bytes.byteLength, opt);
      return this;
    }
    /**
     * Parse a message from a JSON value.
     */
    fromJson(jsonValue, options) {
      const type = this.getType(), format = type.runtime.json, opt = format.makeReadOptions(options);
      format.readMessage(type, jsonValue, opt, this);
      return this;
    }
    /**
     * Parse a message from a JSON string.
     */
    fromJsonString(jsonString, options) {
      let json;
      try {
        json = JSON.parse(jsonString);
      } catch (e) {
        throw new Error(`cannot decode ${this.getType().typeName} from JSON: ${e instanceof Error ? e.message : String(e)}`);
      }
      return this.fromJson(json, options);
    }
    /**
     * Serialize the message to binary data.
     */
    toBinary(options) {
      const type = this.getType(), bin = type.runtime.bin, opt = bin.makeWriteOptions(options), writer = opt.writerFactory();
      bin.writeMessage(this, writer, opt);
      return writer.finish();
    }
    /**
     * Serialize the message to a JSON value, a JavaScript value that can be
     * passed to JSON.stringify().
     */
    toJson(options) {
      const type = this.getType(), json = type.runtime.json, opt = json.makeWriteOptions(options);
      return json.writeMessage(this, opt);
    }
    /**
     * Serialize the message to a JSON string.
     */
    toJsonString(options) {
      var _a5;
      const value = this.toJson(options);
      return JSON.stringify(value, null, (_a5 = options === null || options === void 0 ? void 0 : options.prettySpaces) !== null && _a5 !== void 0 ? _a5 : 0);
    }
    /**
     * Override for serialization behavior. This will be invoked when calling
     * JSON.stringify on this message (i.e. JSON.stringify(msg)).
     *
     * Note that this will not serialize google.protobuf.Any with a packed
     * message because the protobuf JSON format specifies that it needs to be
     * unpacked, and this is only possible with a type registry to look up the
     * message type.  As a result, attempting to serialize a message with this
     * type will throw an Error.
     *
     * This method is protected because you should not need to invoke it
     * directly -- instead use JSON.stringify or toJsonString for
     * stringified JSON.  Alternatively, if actual JSON is desired, you should
     * use toJson.
     */
    toJSON() {
      return this.toJson({
        emitDefaultValues: true
      });
    }
    /**
     * Retrieve the MessageType of this message - a singleton that represents
     * the protobuf message declaration and provides metadata for reflection-
     * based operations.
     */
    getType() {
      return Object.getPrototypeOf(this).constructor;
    }
  };

  // out/node_modules/@bufbuild/protobuf/dist/esm/private/message-type.js
  function makeMessageType(runtime, typeName, fields, opt) {
    var _a5;
    const localName = (_a5 = opt === null || opt === void 0 ? void 0 : opt.localName) !== null && _a5 !== void 0 ? _a5 : typeName.substring(typeName.lastIndexOf(".") + 1);
    const type = {
      [localName]: function(data) {
        runtime.util.initFields(this);
        runtime.util.initPartial(data, this);
      }
    }[localName];
    Object.setPrototypeOf(type.prototype, new Message());
    Object.assign(type, {
      runtime,
      typeName,
      fields: runtime.util.newFieldList(fields),
      fromBinary(bytes, options) {
        return new type().fromBinary(bytes, options);
      },
      fromJson(jsonValue, options) {
        return new type().fromJson(jsonValue, options);
      },
      fromJsonString(jsonString, options) {
        return new type().fromJsonString(jsonString, options);
      },
      equals(a, b) {
        return runtime.util.equals(type, a, b);
      }
    });
    return type;
  }

  // out/node_modules/@bufbuild/protobuf/dist/esm/google/varint.js
  function varint64read() {
    let lowBits = 0;
    let highBits = 0;
    for (let shift = 0; shift < 28; shift += 7) {
      let b = this.buf[this.pos++];
      lowBits |= (b & 127) << shift;
      if ((b & 128) == 0) {
        this.assertBounds();
        return [lowBits, highBits];
      }
    }
    let middleByte = this.buf[this.pos++];
    lowBits |= (middleByte & 15) << 28;
    highBits = (middleByte & 112) >> 4;
    if ((middleByte & 128) == 0) {
      this.assertBounds();
      return [lowBits, highBits];
    }
    for (let shift = 3; shift <= 31; shift += 7) {
      let b = this.buf[this.pos++];
      highBits |= (b & 127) << shift;
      if ((b & 128) == 0) {
        this.assertBounds();
        return [lowBits, highBits];
      }
    }
    throw new Error("invalid varint");
  }
  function varint64write(lo, hi, bytes) {
    for (let i = 0; i < 28; i = i + 7) {
      const shift = lo >>> i;
      const hasNext = !(shift >>> 7 == 0 && hi == 0);
      const byte = (hasNext ? shift | 128 : shift) & 255;
      bytes.push(byte);
      if (!hasNext) {
        return;
      }
    }
    const splitBits = lo >>> 28 & 15 | (hi & 7) << 4;
    const hasMoreBits = !(hi >> 3 == 0);
    bytes.push((hasMoreBits ? splitBits | 128 : splitBits) & 255);
    if (!hasMoreBits) {
      return;
    }
    for (let i = 3; i < 31; i = i + 7) {
      const shift = hi >>> i;
      const hasNext = !(shift >>> 7 == 0);
      const byte = (hasNext ? shift | 128 : shift) & 255;
      bytes.push(byte);
      if (!hasNext) {
        return;
      }
    }
    bytes.push(hi >>> 31 & 1);
  }
  var TWO_PWR_32_DBL = 4294967296;
  function int64FromString(dec) {
    const minus = dec[0] === "-";
    if (minus) {
      dec = dec.slice(1);
    }
    const base = 1e6;
    let lowBits = 0;
    let highBits = 0;
    function add1e6digit(begin, end) {
      const digit1e6 = Number(dec.slice(begin, end));
      highBits *= base;
      lowBits = lowBits * base + digit1e6;
      if (lowBits >= TWO_PWR_32_DBL) {
        highBits = highBits + (lowBits / TWO_PWR_32_DBL | 0);
        lowBits = lowBits % TWO_PWR_32_DBL;
      }
    }
    add1e6digit(-24, -18);
    add1e6digit(-18, -12);
    add1e6digit(-12, -6);
    add1e6digit(-6);
    return minus ? negate(lowBits, highBits) : newBits(lowBits, highBits);
  }
  function int64ToString(lo, hi) {
    let bits = newBits(lo, hi);
    const negative = bits.hi & 2147483648;
    if (negative) {
      bits = negate(bits.lo, bits.hi);
    }
    const result = uInt64ToString(bits.lo, bits.hi);
    return negative ? "-" + result : result;
  }
  function uInt64ToString(lo, hi) {
    ({ lo, hi } = toUnsigned(lo, hi));
    if (hi <= 2097151) {
      return String(TWO_PWR_32_DBL * hi + lo);
    }
    const low = lo & 16777215;
    const mid = (lo >>> 24 | hi << 8) & 16777215;
    const high = hi >> 16 & 65535;
    let digitA = low + mid * 6777216 + high * 6710656;
    let digitB = mid + high * 8147497;
    let digitC = high * 2;
    const base = 1e7;
    if (digitA >= base) {
      digitB += Math.floor(digitA / base);
      digitA %= base;
    }
    if (digitB >= base) {
      digitC += Math.floor(digitB / base);
      digitB %= base;
    }
    return digitC.toString() + decimalFrom1e7WithLeadingZeros(digitB) + decimalFrom1e7WithLeadingZeros(digitA);
  }
  function toUnsigned(lo, hi) {
    return { lo: lo >>> 0, hi: hi >>> 0 };
  }
  function newBits(lo, hi) {
    return { lo: lo | 0, hi: hi | 0 };
  }
  function negate(lowBits, highBits) {
    highBits = ~highBits;
    if (lowBits) {
      lowBits = ~lowBits + 1;
    } else {
      highBits += 1;
    }
    return newBits(lowBits, highBits);
  }
  var decimalFrom1e7WithLeadingZeros = (digit1e7) => {
    const partial = String(digit1e7);
    return "0000000".slice(partial.length) + partial;
  };
  function varint32write(value, bytes) {
    if (value >= 0) {
      while (value > 127) {
        bytes.push(value & 127 | 128);
        value = value >>> 7;
      }
      bytes.push(value);
    } else {
      for (let i = 0; i < 9; i++) {
        bytes.push(value & 127 | 128);
        value = value >> 7;
      }
      bytes.push(1);
    }
  }
  function varint32read() {
    let b = this.buf[this.pos++];
    let result = b & 127;
    if ((b & 128) == 0) {
      this.assertBounds();
      return result;
    }
    b = this.buf[this.pos++];
    result |= (b & 127) << 7;
    if ((b & 128) == 0) {
      this.assertBounds();
      return result;
    }
    b = this.buf[this.pos++];
    result |= (b & 127) << 14;
    if ((b & 128) == 0) {
      this.assertBounds();
      return result;
    }
    b = this.buf[this.pos++];
    result |= (b & 127) << 21;
    if ((b & 128) == 0) {
      this.assertBounds();
      return result;
    }
    b = this.buf[this.pos++];
    result |= (b & 15) << 28;
    for (let readBytes = 5; (b & 128) !== 0 && readBytes < 10; readBytes++)
      b = this.buf[this.pos++];
    if ((b & 128) != 0)
      throw new Error("invalid varint");
    this.assertBounds();
    return result >>> 0;
  }

  // out/node_modules/@bufbuild/protobuf/dist/esm/proto-int64.js
  function makeInt64Support() {
    const dv = new DataView(new ArrayBuffer(8));
    const ok = typeof BigInt === "function" && typeof dv.getBigInt64 === "function" && typeof dv.getBigUint64 === "function" && typeof dv.setBigInt64 === "function" && typeof dv.setBigUint64 === "function" && (typeof process != "object" || typeof process.env != "object" || process.env.BUF_BIGINT_DISABLE !== "1");
    if (ok) {
      const MIN = BigInt("-9223372036854775808"), MAX = BigInt("9223372036854775807"), UMIN = BigInt("0"), UMAX = BigInt("18446744073709551615");
      return {
        zero: BigInt(0),
        supported: true,
        parse(value) {
          const bi = typeof value == "bigint" ? value : BigInt(value);
          if (bi > MAX || bi < MIN) {
            throw new Error(`int64 invalid: ${value}`);
          }
          return bi;
        },
        uParse(value) {
          const bi = typeof value == "bigint" ? value : BigInt(value);
          if (bi > UMAX || bi < UMIN) {
            throw new Error(`uint64 invalid: ${value}`);
          }
          return bi;
        },
        enc(value) {
          dv.setBigInt64(0, this.parse(value), true);
          return {
            lo: dv.getInt32(0, true),
            hi: dv.getInt32(4, true)
          };
        },
        uEnc(value) {
          dv.setBigInt64(0, this.uParse(value), true);
          return {
            lo: dv.getInt32(0, true),
            hi: dv.getInt32(4, true)
          };
        },
        dec(lo, hi) {
          dv.setInt32(0, lo, true);
          dv.setInt32(4, hi, true);
          return dv.getBigInt64(0, true);
        },
        uDec(lo, hi) {
          dv.setInt32(0, lo, true);
          dv.setInt32(4, hi, true);
          return dv.getBigUint64(0, true);
        }
      };
    }
    const assertInt64String = (value) => assert(/^-?[0-9]+$/.test(value), `int64 invalid: ${value}`);
    const assertUInt64String = (value) => assert(/^[0-9]+$/.test(value), `uint64 invalid: ${value}`);
    return {
      zero: "0",
      supported: false,
      parse(value) {
        if (typeof value != "string") {
          value = value.toString();
        }
        assertInt64String(value);
        return value;
      },
      uParse(value) {
        if (typeof value != "string") {
          value = value.toString();
        }
        assertUInt64String(value);
        return value;
      },
      enc(value) {
        if (typeof value != "string") {
          value = value.toString();
        }
        assertInt64String(value);
        return int64FromString(value);
      },
      uEnc(value) {
        if (typeof value != "string") {
          value = value.toString();
        }
        assertUInt64String(value);
        return int64FromString(value);
      },
      dec(lo, hi) {
        return int64ToString(lo, hi);
      },
      uDec(lo, hi) {
        return uInt64ToString(lo, hi);
      }
    };
  }
  var protoInt64 = makeInt64Support();

  // out/node_modules/@bufbuild/protobuf/dist/esm/scalar.js
  var ScalarType;
  (function(ScalarType2) {
    ScalarType2[ScalarType2["DOUBLE"] = 1] = "DOUBLE";
    ScalarType2[ScalarType2["FLOAT"] = 2] = "FLOAT";
    ScalarType2[ScalarType2["INT64"] = 3] = "INT64";
    ScalarType2[ScalarType2["UINT64"] = 4] = "UINT64";
    ScalarType2[ScalarType2["INT32"] = 5] = "INT32";
    ScalarType2[ScalarType2["FIXED64"] = 6] = "FIXED64";
    ScalarType2[ScalarType2["FIXED32"] = 7] = "FIXED32";
    ScalarType2[ScalarType2["BOOL"] = 8] = "BOOL";
    ScalarType2[ScalarType2["STRING"] = 9] = "STRING";
    ScalarType2[ScalarType2["BYTES"] = 12] = "BYTES";
    ScalarType2[ScalarType2["UINT32"] = 13] = "UINT32";
    ScalarType2[ScalarType2["SFIXED32"] = 15] = "SFIXED32";
    ScalarType2[ScalarType2["SFIXED64"] = 16] = "SFIXED64";
    ScalarType2[ScalarType2["SINT32"] = 17] = "SINT32";
    ScalarType2[ScalarType2["SINT64"] = 18] = "SINT64";
  })(ScalarType || (ScalarType = {}));
  var LongType;
  (function(LongType2) {
    LongType2[LongType2["BIGINT"] = 0] = "BIGINT";
    LongType2[LongType2["STRING"] = 1] = "STRING";
  })(LongType || (LongType = {}));

  // out/node_modules/@bufbuild/protobuf/dist/esm/private/scalars.js
  function scalarEquals(type, a, b) {
    if (a === b) {
      return true;
    }
    if (type == ScalarType.BYTES) {
      if (!(a instanceof Uint8Array) || !(b instanceof Uint8Array)) {
        return false;
      }
      if (a.length !== b.length) {
        return false;
      }
      for (let i = 0; i < a.length; i++) {
        if (a[i] !== b[i]) {
          return false;
        }
      }
      return true;
    }
    switch (type) {
      case ScalarType.UINT64:
      case ScalarType.FIXED64:
      case ScalarType.INT64:
      case ScalarType.SFIXED64:
      case ScalarType.SINT64:
        return a == b;
    }
    return false;
  }
  function scalarZeroValue(type, longType) {
    switch (type) {
      case ScalarType.BOOL:
        return false;
      case ScalarType.UINT64:
      case ScalarType.FIXED64:
      case ScalarType.INT64:
      case ScalarType.SFIXED64:
      case ScalarType.SINT64:
        return longType == 0 ? protoInt64.zero : "0";
      case ScalarType.DOUBLE:
      case ScalarType.FLOAT:
        return 0;
      case ScalarType.BYTES:
        return new Uint8Array(0);
      case ScalarType.STRING:
        return "";
      default:
        return 0;
    }
  }
  function isScalarZeroValue(type, value) {
    switch (type) {
      case ScalarType.BOOL:
        return value === false;
      case ScalarType.STRING:
        return value === "";
      case ScalarType.BYTES:
        return value instanceof Uint8Array && !value.byteLength;
      default:
        return value == 0;
    }
  }

  // out/node_modules/@bufbuild/protobuf/dist/esm/binary-encoding.js
  var WireType;
  (function(WireType2) {
    WireType2[WireType2["Varint"] = 0] = "Varint";
    WireType2[WireType2["Bit64"] = 1] = "Bit64";
    WireType2[WireType2["LengthDelimited"] = 2] = "LengthDelimited";
    WireType2[WireType2["StartGroup"] = 3] = "StartGroup";
    WireType2[WireType2["EndGroup"] = 4] = "EndGroup";
    WireType2[WireType2["Bit32"] = 5] = "Bit32";
  })(WireType || (WireType = {}));
  var BinaryWriter = class {
    constructor(textEncoder) {
      this.stack = [];
      this.textEncoder = textEncoder !== null && textEncoder !== void 0 ? textEncoder : new TextEncoder();
      this.chunks = [];
      this.buf = [];
    }
    /**
     * Return all bytes written and reset this writer.
     */
    finish() {
      this.chunks.push(new Uint8Array(this.buf));
      let len = 0;
      for (let i = 0; i < this.chunks.length; i++)
        len += this.chunks[i].length;
      let bytes = new Uint8Array(len);
      let offset = 0;
      for (let i = 0; i < this.chunks.length; i++) {
        bytes.set(this.chunks[i], offset);
        offset += this.chunks[i].length;
      }
      this.chunks = [];
      return bytes;
    }
    /**
     * Start a new fork for length-delimited data like a message
     * or a packed repeated field.
     *
     * Must be joined later with `join()`.
     */
    fork() {
      this.stack.push({ chunks: this.chunks, buf: this.buf });
      this.chunks = [];
      this.buf = [];
      return this;
    }
    /**
     * Join the last fork. Write its length and bytes, then
     * return to the previous state.
     */
    join() {
      let chunk = this.finish();
      let prev = this.stack.pop();
      if (!prev)
        throw new Error("invalid state, fork stack empty");
      this.chunks = prev.chunks;
      this.buf = prev.buf;
      this.uint32(chunk.byteLength);
      return this.raw(chunk);
    }
    /**
     * Writes a tag (field number and wire type).
     *
     * Equivalent to `uint32( (fieldNo << 3 | type) >>> 0 )`.
     *
     * Generated code should compute the tag ahead of time and call `uint32()`.
     */
    tag(fieldNo, type) {
      return this.uint32((fieldNo << 3 | type) >>> 0);
    }
    /**
     * Write a chunk of raw bytes.
     */
    raw(chunk) {
      if (this.buf.length) {
        this.chunks.push(new Uint8Array(this.buf));
        this.buf = [];
      }
      this.chunks.push(chunk);
      return this;
    }
    /**
     * Write a `uint32` value, an unsigned 32 bit varint.
     */
    uint32(value) {
      assertUInt32(value);
      while (value > 127) {
        this.buf.push(value & 127 | 128);
        value = value >>> 7;
      }
      this.buf.push(value);
      return this;
    }
    /**
     * Write a `int32` value, a signed 32 bit varint.
     */
    int32(value) {
      assertInt32(value);
      varint32write(value, this.buf);
      return this;
    }
    /**
     * Write a `bool` value, a variant.
     */
    bool(value) {
      this.buf.push(value ? 1 : 0);
      return this;
    }
    /**
     * Write a `bytes` value, length-delimited arbitrary data.
     */
    bytes(value) {
      this.uint32(value.byteLength);
      return this.raw(value);
    }
    /**
     * Write a `string` value, length-delimited data converted to UTF-8 text.
     */
    string(value) {
      let chunk = this.textEncoder.encode(value);
      this.uint32(chunk.byteLength);
      return this.raw(chunk);
    }
    /**
     * Write a `float` value, 32-bit floating point number.
     */
    float(value) {
      assertFloat32(value);
      let chunk = new Uint8Array(4);
      new DataView(chunk.buffer).setFloat32(0, value, true);
      return this.raw(chunk);
    }
    /**
     * Write a `double` value, a 64-bit floating point number.
     */
    double(value) {
      let chunk = new Uint8Array(8);
      new DataView(chunk.buffer).setFloat64(0, value, true);
      return this.raw(chunk);
    }
    /**
     * Write a `fixed32` value, an unsigned, fixed-length 32-bit integer.
     */
    fixed32(value) {
      assertUInt32(value);
      let chunk = new Uint8Array(4);
      new DataView(chunk.buffer).setUint32(0, value, true);
      return this.raw(chunk);
    }
    /**
     * Write a `sfixed32` value, a signed, fixed-length 32-bit integer.
     */
    sfixed32(value) {
      assertInt32(value);
      let chunk = new Uint8Array(4);
      new DataView(chunk.buffer).setInt32(0, value, true);
      return this.raw(chunk);
    }
    /**
     * Write a `sint32` value, a signed, zigzag-encoded 32-bit varint.
     */
    sint32(value) {
      assertInt32(value);
      value = (value << 1 ^ value >> 31) >>> 0;
      varint32write(value, this.buf);
      return this;
    }
    /**
     * Write a `fixed64` value, a signed, fixed-length 64-bit integer.
     */
    sfixed64(value) {
      let chunk = new Uint8Array(8), view = new DataView(chunk.buffer), tc = protoInt64.enc(value);
      view.setInt32(0, tc.lo, true);
      view.setInt32(4, tc.hi, true);
      return this.raw(chunk);
    }
    /**
     * Write a `fixed64` value, an unsigned, fixed-length 64 bit integer.
     */
    fixed64(value) {
      let chunk = new Uint8Array(8), view = new DataView(chunk.buffer), tc = protoInt64.uEnc(value);
      view.setInt32(0, tc.lo, true);
      view.setInt32(4, tc.hi, true);
      return this.raw(chunk);
    }
    /**
     * Write a `int64` value, a signed 64-bit varint.
     */
    int64(value) {
      let tc = protoInt64.enc(value);
      varint64write(tc.lo, tc.hi, this.buf);
      return this;
    }
    /**
     * Write a `sint64` value, a signed, zig-zag-encoded 64-bit varint.
     */
    sint64(value) {
      let tc = protoInt64.enc(value), sign = tc.hi >> 31, lo = tc.lo << 1 ^ sign, hi = (tc.hi << 1 | tc.lo >>> 31) ^ sign;
      varint64write(lo, hi, this.buf);
      return this;
    }
    /**
     * Write a `uint64` value, an unsigned 64-bit varint.
     */
    uint64(value) {
      let tc = protoInt64.uEnc(value);
      varint64write(tc.lo, tc.hi, this.buf);
      return this;
    }
  };
  var BinaryReader = class {
    constructor(buf, textDecoder) {
      this.varint64 = varint64read;
      this.uint32 = varint32read;
      this.buf = buf;
      this.len = buf.length;
      this.pos = 0;
      this.view = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);
      this.textDecoder = textDecoder !== null && textDecoder !== void 0 ? textDecoder : new TextDecoder();
    }
    /**
     * Reads a tag - field number and wire type.
     */
    tag() {
      let tag2 = this.uint32(), fieldNo = tag2 >>> 3, wireType = tag2 & 7;
      if (fieldNo <= 0 || wireType < 0 || wireType > 5)
        throw new Error("illegal tag: field no " + fieldNo + " wire type " + wireType);
      return [fieldNo, wireType];
    }
    /**
     * Skip one element and return the skipped data.
     *
     * When skipping StartGroup, provide the tags field number to check for
     * matching field number in the EndGroup tag.
     */
    skip(wireType, fieldNo) {
      let start = this.pos;
      switch (wireType) {
        case WireType.Varint:
          while (this.buf[this.pos++] & 128) {
          }
          break;
        // eslint-disable-next-line
        // @ts-ignore TS7029: Fallthrough case in switch
        case WireType.Bit64:
          this.pos += 4;
        // eslint-disable-next-line
        // @ts-ignore TS7029: Fallthrough case in switch
        case WireType.Bit32:
          this.pos += 4;
          break;
        case WireType.LengthDelimited:
          let len = this.uint32();
          this.pos += len;
          break;
        case WireType.StartGroup:
          for (; ; ) {
            const [fn, wt] = this.tag();
            if (wt === WireType.EndGroup) {
              if (fieldNo !== void 0 && fn !== fieldNo) {
                throw new Error("invalid end group tag");
              }
              break;
            }
            this.skip(wt, fn);
          }
          break;
        default:
          throw new Error("cant skip wire type " + wireType);
      }
      this.assertBounds();
      return this.buf.subarray(start, this.pos);
    }
    /**
     * Throws error if position in byte array is out of range.
     */
    assertBounds() {
      if (this.pos > this.len)
        throw new RangeError("premature EOF");
    }
    /**
     * Read a `int32` field, a signed 32 bit varint.
     */
    int32() {
      return this.uint32() | 0;
    }
    /**
     * Read a `sint32` field, a signed, zigzag-encoded 32-bit varint.
     */
    sint32() {
      let zze = this.uint32();
      return zze >>> 1 ^ -(zze & 1);
    }
    /**
     * Read a `int64` field, a signed 64-bit varint.
     */
    int64() {
      return protoInt64.dec(...this.varint64());
    }
    /**
     * Read a `uint64` field, an unsigned 64-bit varint.
     */
    uint64() {
      return protoInt64.uDec(...this.varint64());
    }
    /**
     * Read a `sint64` field, a signed, zig-zag-encoded 64-bit varint.
     */
    sint64() {
      let [lo, hi] = this.varint64();
      let s = -(lo & 1);
      lo = (lo >>> 1 | (hi & 1) << 31) ^ s;
      hi = hi >>> 1 ^ s;
      return protoInt64.dec(lo, hi);
    }
    /**
     * Read a `bool` field, a variant.
     */
    bool() {
      let [lo, hi] = this.varint64();
      return lo !== 0 || hi !== 0;
    }
    /**
     * Read a `fixed32` field, an unsigned, fixed-length 32-bit integer.
     */
    fixed32() {
      return this.view.getUint32((this.pos += 4) - 4, true);
    }
    /**
     * Read a `sfixed32` field, a signed, fixed-length 32-bit integer.
     */
    sfixed32() {
      return this.view.getInt32((this.pos += 4) - 4, true);
    }
    /**
     * Read a `fixed64` field, an unsigned, fixed-length 64 bit integer.
     */
    fixed64() {
      return protoInt64.uDec(this.sfixed32(), this.sfixed32());
    }
    /**
     * Read a `fixed64` field, a signed, fixed-length 64-bit integer.
     */
    sfixed64() {
      return protoInt64.dec(this.sfixed32(), this.sfixed32());
    }
    /**
     * Read a `float` field, 32-bit floating point number.
     */
    float() {
      return this.view.getFloat32((this.pos += 4) - 4, true);
    }
    /**
     * Read a `double` field, a 64-bit floating point number.
     */
    double() {
      return this.view.getFloat64((this.pos += 8) - 8, true);
    }
    /**
     * Read a `bytes` field, length-delimited arbitrary data.
     */
    bytes() {
      let len = this.uint32(), start = this.pos;
      this.pos += len;
      this.assertBounds();
      return this.buf.subarray(start, start + len);
    }
    /**
     * Read a `string` field, length-delimited data converted to UTF-8 text.
     */
    string() {
      return this.textDecoder.decode(this.bytes());
    }
  };

  // out/node_modules/@bufbuild/protobuf/dist/esm/private/extensions.js
  function makeExtension(runtime, typeName, extendee, field) {
    let fi;
    return {
      typeName,
      extendee,
      get field() {
        if (!fi) {
          const i = typeof field == "function" ? field() : field;
          i.name = typeName.split(".").pop();
          i.jsonName = `[${typeName}]`;
          fi = runtime.util.newFieldList([i]).list()[0];
        }
        return fi;
      },
      runtime
    };
  }
  function createExtensionContainer(extension) {
    const localName = extension.field.localName;
    const container = /* @__PURE__ */ Object.create(null);
    container[localName] = initExtensionField(extension);
    return [container, () => container[localName]];
  }
  function initExtensionField(ext) {
    const field = ext.field;
    if (field.repeated) {
      return [];
    }
    if (field.default !== void 0) {
      return field.default;
    }
    switch (field.kind) {
      case "enum":
        return field.T.values[0].no;
      case "scalar":
        return scalarZeroValue(field.T, field.L);
      case "message":
        const T = field.T, value = new T();
        return T.fieldWrapper ? T.fieldWrapper.unwrapField(value) : value;
      case "map":
        throw "map fields are not allowed to be extensions";
    }
  }
  function filterUnknownFields(unknownFields, field) {
    if (!field.repeated && (field.kind == "enum" || field.kind == "scalar")) {
      for (let i = unknownFields.length - 1; i >= 0; --i) {
        if (unknownFields[i].no == field.no) {
          return [unknownFields[i]];
        }
      }
      return [];
    }
    return unknownFields.filter((uf) => uf.no === field.no);
  }

  // out/node_modules/@bufbuild/protobuf/dist/esm/proto-base64.js
  var encTable = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".split("");
  var decTable = [];
  for (let i = 0; i < encTable.length; i++)
    decTable[encTable[i].charCodeAt(0)] = i;
  decTable["-".charCodeAt(0)] = encTable.indexOf("+");
  decTable["_".charCodeAt(0)] = encTable.indexOf("/");
  var protoBase64 = {
    /**
     * Decodes a base64 string to a byte array.
     *
     * - ignores white-space, including line breaks and tabs
     * - allows inner padding (can decode concatenated base64 strings)
     * - does not require padding
     * - understands base64url encoding:
     *   "-" instead of "+",
     *   "_" instead of "/",
     *   no padding
     */
    dec(base64Str) {
      let es = base64Str.length * 3 / 4;
      if (base64Str[base64Str.length - 2] == "=")
        es -= 2;
      else if (base64Str[base64Str.length - 1] == "=")
        es -= 1;
      let bytes = new Uint8Array(es), bytePos = 0, groupPos = 0, b, p = 0;
      for (let i = 0; i < base64Str.length; i++) {
        b = decTable[base64Str.charCodeAt(i)];
        if (b === void 0) {
          switch (base64Str[i]) {
            // @ts-ignore TS7029: Fallthrough case in switch
            case "=":
              groupPos = 0;
            // reset state when padding found
            // @ts-ignore TS7029: Fallthrough case in switch
            case "\n":
            case "\r":
            case "	":
            case " ":
              continue;
            // skip white-space, and padding
            default:
              throw Error("invalid base64 string.");
          }
        }
        switch (groupPos) {
          case 0:
            p = b;
            groupPos = 1;
            break;
          case 1:
            bytes[bytePos++] = p << 2 | (b & 48) >> 4;
            p = b;
            groupPos = 2;
            break;
          case 2:
            bytes[bytePos++] = (p & 15) << 4 | (b & 60) >> 2;
            p = b;
            groupPos = 3;
            break;
          case 3:
            bytes[bytePos++] = (p & 3) << 6 | b;
            groupPos = 0;
            break;
        }
      }
      if (groupPos == 1)
        throw Error("invalid base64 string.");
      return bytes.subarray(0, bytePos);
    },
    /**
     * Encode a byte array to a base64 string.
     */
    enc(bytes) {
      let base64 = "", groupPos = 0, b, p = 0;
      for (let i = 0; i < bytes.length; i++) {
        b = bytes[i];
        switch (groupPos) {
          case 0:
            base64 += encTable[b >> 2];
            p = (b & 3) << 4;
            groupPos = 1;
            break;
          case 1:
            base64 += encTable[p | b >> 4];
            p = (b & 15) << 2;
            groupPos = 2;
            break;
          case 2:
            base64 += encTable[p | b >> 6];
            base64 += encTable[b & 63];
            groupPos = 0;
            break;
        }
      }
      if (groupPos) {
        base64 += encTable[p];
        base64 += "=";
        if (groupPos == 1)
          base64 += "=";
      }
      return base64;
    }
  };

  // out/node_modules/@bufbuild/protobuf/dist/esm/extension-accessor.js
  function getExtension(message, extension, options) {
    assertExtendee(extension, message);
    const opt = extension.runtime.bin.makeReadOptions(options);
    const ufs = filterUnknownFields(message.getType().runtime.bin.listUnknownFields(message), extension.field);
    const [container, get3] = createExtensionContainer(extension);
    for (const uf of ufs) {
      extension.runtime.bin.readField(container, opt.readerFactory(uf.data), extension.field, uf.wireType, opt);
    }
    return get3();
  }
  function setExtension(message, extension, value, options) {
    assertExtendee(extension, message);
    const readOpt = extension.runtime.bin.makeReadOptions(options);
    const writeOpt = extension.runtime.bin.makeWriteOptions(options);
    if (hasExtension(message, extension)) {
      const ufs = message.getType().runtime.bin.listUnknownFields(message).filter((uf) => uf.no != extension.field.no);
      message.getType().runtime.bin.discardUnknownFields(message);
      for (const uf of ufs) {
        message.getType().runtime.bin.onUnknownField(message, uf.no, uf.wireType, uf.data);
      }
    }
    const writer = writeOpt.writerFactory();
    let f = extension.field;
    if (!f.opt && !f.repeated && (f.kind == "enum" || f.kind == "scalar")) {
      f = Object.assign(Object.assign({}, extension.field), { opt: true });
    }
    extension.runtime.bin.writeField(f, value, writer, writeOpt);
    const reader = readOpt.readerFactory(writer.finish());
    while (reader.pos < reader.len) {
      const [no, wireType] = reader.tag();
      const data = reader.skip(wireType, no);
      message.getType().runtime.bin.onUnknownField(message, no, wireType, data);
    }
  }
  function hasExtension(message, extension) {
    const messageType = message.getType();
    return extension.extendee.typeName === messageType.typeName && !!messageType.runtime.bin.listUnknownFields(message).find((uf) => uf.no == extension.field.no);
  }
  function assertExtendee(extension, message) {
    assert(extension.extendee.typeName == message.getType().typeName, `extension ${extension.typeName} can only be applied to message ${extension.extendee.typeName}`);
  }

  // out/node_modules/@bufbuild/protobuf/dist/esm/private/reflect.js
  function isFieldSet(field, target) {
    const localName = field.localName;
    if (field.repeated) {
      return target[localName].length > 0;
    }
    if (field.oneof) {
      return target[field.oneof.localName].case === localName;
    }
    switch (field.kind) {
      case "enum":
      case "scalar":
        if (field.opt || field.req) {
          return target[localName] !== void 0;
        }
        if (field.kind == "enum") {
          return target[localName] !== field.T.values[0].no;
        }
        return !isScalarZeroValue(field.T, target[localName]);
      case "message":
        return target[localName] !== void 0;
      case "map":
        return Object.keys(target[localName]).length > 0;
    }
  }
  function clearField(field, target) {
    const localName = field.localName;
    const implicitPresence = !field.opt && !field.req;
    if (field.repeated) {
      target[localName] = [];
    } else if (field.oneof) {
      target[field.oneof.localName] = { case: void 0 };
    } else {
      switch (field.kind) {
        case "map":
          target[localName] = {};
          break;
        case "enum":
          target[localName] = implicitPresence ? field.T.values[0].no : void 0;
          break;
        case "scalar":
          target[localName] = implicitPresence ? scalarZeroValue(field.T, field.L) : void 0;
          break;
        case "message":
          target[localName] = void 0;
          break;
      }
    }
  }

  // out/node_modules/@bufbuild/protobuf/dist/esm/is-message.js
  function isMessage(arg, type) {
    if (arg === null || typeof arg != "object") {
      return false;
    }
    if (!Object.getOwnPropertyNames(Message.prototype).every((m) => m in arg && typeof arg[m] == "function")) {
      return false;
    }
    const actualType = arg.getType();
    if (actualType === null || typeof actualType != "function" || !("typeName" in actualType) || typeof actualType.typeName != "string") {
      return false;
    }
    return type === void 0 ? true : actualType.typeName == type.typeName;
  }

  // out/node_modules/@bufbuild/protobuf/dist/esm/private/field-wrapper.js
  function wrapField(type, value) {
    if (isMessage(value) || !type.fieldWrapper) {
      return value;
    }
    return type.fieldWrapper.wrapField(value);
  }
  var wktWrapperToScalarType = {
    "google.protobuf.DoubleValue": ScalarType.DOUBLE,
    "google.protobuf.FloatValue": ScalarType.FLOAT,
    "google.protobuf.Int64Value": ScalarType.INT64,
    "google.protobuf.UInt64Value": ScalarType.UINT64,
    "google.protobuf.Int32Value": ScalarType.INT32,
    "google.protobuf.UInt32Value": ScalarType.UINT32,
    "google.protobuf.BoolValue": ScalarType.BOOL,
    "google.protobuf.StringValue": ScalarType.STRING,
    "google.protobuf.BytesValue": ScalarType.BYTES
  };

  // out/node_modules/@bufbuild/protobuf/dist/esm/private/json-format.js
  var jsonReadDefaults = {
    ignoreUnknownFields: false
  };
  var jsonWriteDefaults = {
    emitDefaultValues: false,
    enumAsInteger: false,
    useProtoFieldName: false,
    prettySpaces: 0
  };
  function makeReadOptions(options) {
    return options ? Object.assign(Object.assign({}, jsonReadDefaults), options) : jsonReadDefaults;
  }
  function makeWriteOptions(options) {
    return options ? Object.assign(Object.assign({}, jsonWriteDefaults), options) : jsonWriteDefaults;
  }
  var tokenNull = /* @__PURE__ */ Symbol();
  var tokenIgnoredUnknownEnum = /* @__PURE__ */ Symbol();
  function makeJsonFormat() {
    return {
      makeReadOptions,
      makeWriteOptions,
      readMessage(type, json, options, message) {
        if (json == null || Array.isArray(json) || typeof json != "object") {
          throw new Error(`cannot decode message ${type.typeName} from JSON: ${debugJsonValue(json)}`);
        }
        message = message !== null && message !== void 0 ? message : new type();
        const oneofSeen = /* @__PURE__ */ new Map();
        const registry = options.typeRegistry;
        for (const [jsonKey, jsonValue] of Object.entries(json)) {
          const field = type.fields.findJsonName(jsonKey);
          if (field) {
            if (field.oneof) {
              if (jsonValue === null && field.kind == "scalar") {
                continue;
              }
              const seen = oneofSeen.get(field.oneof);
              if (seen !== void 0) {
                throw new Error(`cannot decode message ${type.typeName} from JSON: multiple keys for oneof "${field.oneof.name}" present: "${seen}", "${jsonKey}"`);
              }
              oneofSeen.set(field.oneof, jsonKey);
            }
            readField(message, jsonValue, field, options, type);
          } else {
            let found = false;
            if ((registry === null || registry === void 0 ? void 0 : registry.findExtension) && jsonKey.startsWith("[") && jsonKey.endsWith("]")) {
              const ext = registry.findExtension(jsonKey.substring(1, jsonKey.length - 1));
              if (ext && ext.extendee.typeName == type.typeName) {
                found = true;
                const [container, get3] = createExtensionContainer(ext);
                readField(container, jsonValue, ext.field, options, ext);
                setExtension(message, ext, get3(), options);
              }
            }
            if (!found && !options.ignoreUnknownFields) {
              throw new Error(`cannot decode message ${type.typeName} from JSON: key "${jsonKey}" is unknown`);
            }
          }
        }
        return message;
      },
      writeMessage(message, options) {
        const type = message.getType();
        const json = {};
        let field;
        try {
          for (field of type.fields.byNumber()) {
            if (!isFieldSet(field, message)) {
              if (field.req) {
                throw `required field not set`;
              }
              if (!options.emitDefaultValues) {
                continue;
              }
              if (!canEmitFieldDefaultValue(field)) {
                continue;
              }
            }
            const value = field.oneof ? message[field.oneof.localName].value : message[field.localName];
            const jsonValue = writeField(field, value, options);
            if (jsonValue !== void 0) {
              json[options.useProtoFieldName ? field.name : field.jsonName] = jsonValue;
            }
          }
          const registry = options.typeRegistry;
          if (registry === null || registry === void 0 ? void 0 : registry.findExtensionFor) {
            for (const uf of type.runtime.bin.listUnknownFields(message)) {
              const ext = registry.findExtensionFor(type.typeName, uf.no);
              if (ext && hasExtension(message, ext)) {
                const value = getExtension(message, ext, options);
                const jsonValue = writeField(ext.field, value, options);
                if (jsonValue !== void 0) {
                  json[ext.field.jsonName] = jsonValue;
                }
              }
            }
          }
        } catch (e) {
          const m = field ? `cannot encode field ${type.typeName}.${field.name} to JSON` : `cannot encode message ${type.typeName} to JSON`;
          const r = e instanceof Error ? e.message : String(e);
          throw new Error(m + (r.length > 0 ? `: ${r}` : ""));
        }
        return json;
      },
      readScalar(type, json, longType) {
        return readScalar(type, json, longType !== null && longType !== void 0 ? longType : LongType.BIGINT, true);
      },
      writeScalar(type, value, emitDefaultValues) {
        if (value === void 0) {
          return void 0;
        }
        if (emitDefaultValues || isScalarZeroValue(type, value)) {
          return writeScalar(type, value);
        }
        return void 0;
      },
      debug: debugJsonValue
    };
  }
  function debugJsonValue(json) {
    if (json === null) {
      return "null";
    }
    switch (typeof json) {
      case "object":
        return Array.isArray(json) ? "array" : "object";
      case "string":
        return json.length > 100 ? "string" : `"${json.split('"').join('\\"')}"`;
      default:
        return String(json);
    }
  }
  function readField(target, jsonValue, field, options, parentType) {
    let localName = field.localName;
    if (field.repeated) {
      assert(field.kind != "map");
      if (jsonValue === null) {
        return;
      }
      if (!Array.isArray(jsonValue)) {
        throw new Error(`cannot decode field ${parentType.typeName}.${field.name} from JSON: ${debugJsonValue(jsonValue)}`);
      }
      const targetArray = target[localName];
      for (const jsonItem of jsonValue) {
        if (jsonItem === null) {
          throw new Error(`cannot decode field ${parentType.typeName}.${field.name} from JSON: ${debugJsonValue(jsonItem)}`);
        }
        switch (field.kind) {
          case "message":
            targetArray.push(field.T.fromJson(jsonItem, options));
            break;
          case "enum":
            const enumValue = readEnum(field.T, jsonItem, options.ignoreUnknownFields, true);
            if (enumValue !== tokenIgnoredUnknownEnum) {
              targetArray.push(enumValue);
            }
            break;
          case "scalar":
            try {
              targetArray.push(readScalar(field.T, jsonItem, field.L, true));
            } catch (e) {
              let m = `cannot decode field ${parentType.typeName}.${field.name} from JSON: ${debugJsonValue(jsonItem)}`;
              if (e instanceof Error && e.message.length > 0) {
                m += `: ${e.message}`;
              }
              throw new Error(m);
            }
            break;
        }
      }
    } else if (field.kind == "map") {
      if (jsonValue === null) {
        return;
      }
      if (typeof jsonValue != "object" || Array.isArray(jsonValue)) {
        throw new Error(`cannot decode field ${parentType.typeName}.${field.name} from JSON: ${debugJsonValue(jsonValue)}`);
      }
      const targetMap = target[localName];
      for (const [jsonMapKey, jsonMapValue] of Object.entries(jsonValue)) {
        if (jsonMapValue === null) {
          throw new Error(`cannot decode field ${parentType.typeName}.${field.name} from JSON: map value null`);
        }
        let key2;
        try {
          key2 = readMapKey(field.K, jsonMapKey);
        } catch (e) {
          let m = `cannot decode map key for field ${parentType.typeName}.${field.name} from JSON: ${debugJsonValue(jsonValue)}`;
          if (e instanceof Error && e.message.length > 0) {
            m += `: ${e.message}`;
          }
          throw new Error(m);
        }
        switch (field.V.kind) {
          case "message":
            targetMap[key2] = field.V.T.fromJson(jsonMapValue, options);
            break;
          case "enum":
            const enumValue = readEnum(field.V.T, jsonMapValue, options.ignoreUnknownFields, true);
            if (enumValue !== tokenIgnoredUnknownEnum) {
              targetMap[key2] = enumValue;
            }
            break;
          case "scalar":
            try {
              targetMap[key2] = readScalar(field.V.T, jsonMapValue, LongType.BIGINT, true);
            } catch (e) {
              let m = `cannot decode map value for field ${parentType.typeName}.${field.name} from JSON: ${debugJsonValue(jsonValue)}`;
              if (e instanceof Error && e.message.length > 0) {
                m += `: ${e.message}`;
              }
              throw new Error(m);
            }
            break;
        }
      }
    } else {
      if (field.oneof) {
        target = target[field.oneof.localName] = { case: localName };
        localName = "value";
      }
      switch (field.kind) {
        case "message":
          const messageType = field.T;
          if (jsonValue === null && messageType.typeName != "google.protobuf.Value") {
            return;
          }
          let currentValue = target[localName];
          if (isMessage(currentValue)) {
            currentValue.fromJson(jsonValue, options);
          } else {
            target[localName] = currentValue = messageType.fromJson(jsonValue, options);
            if (messageType.fieldWrapper && !field.oneof) {
              target[localName] = messageType.fieldWrapper.unwrapField(currentValue);
            }
          }
          break;
        case "enum":
          const enumValue = readEnum(field.T, jsonValue, options.ignoreUnknownFields, false);
          switch (enumValue) {
            case tokenNull:
              clearField(field, target);
              break;
            case tokenIgnoredUnknownEnum:
              break;
            default:
              target[localName] = enumValue;
              break;
          }
          break;
        case "scalar":
          try {
            const scalarValue = readScalar(field.T, jsonValue, field.L, false);
            switch (scalarValue) {
              case tokenNull:
                clearField(field, target);
                break;
              default:
                target[localName] = scalarValue;
                break;
            }
          } catch (e) {
            let m = `cannot decode field ${parentType.typeName}.${field.name} from JSON: ${debugJsonValue(jsonValue)}`;
            if (e instanceof Error && e.message.length > 0) {
              m += `: ${e.message}`;
            }
            throw new Error(m);
          }
          break;
      }
    }
  }
  function readMapKey(type, json) {
    if (type === ScalarType.BOOL) {
      switch (json) {
        case "true":
          json = true;
          break;
        case "false":
          json = false;
          break;
      }
    }
    return readScalar(type, json, LongType.BIGINT, true).toString();
  }
  function readScalar(type, json, longType, nullAsZeroValue) {
    if (json === null) {
      if (nullAsZeroValue) {
        return scalarZeroValue(type, longType);
      }
      return tokenNull;
    }
    switch (type) {
      // float, double: JSON value will be a number or one of the special string values "NaN", "Infinity", and "-Infinity".
      // Either numbers or strings are accepted. Exponent notation is also accepted.
      case ScalarType.DOUBLE:
      case ScalarType.FLOAT:
        if (json === "NaN")
          return Number.NaN;
        if (json === "Infinity")
          return Number.POSITIVE_INFINITY;
        if (json === "-Infinity")
          return Number.NEGATIVE_INFINITY;
        if (json === "") {
          break;
        }
        if (typeof json == "string" && json.trim().length !== json.length) {
          break;
        }
        if (typeof json != "string" && typeof json != "number") {
          break;
        }
        const float = Number(json);
        if (Number.isNaN(float)) {
          break;
        }
        if (!Number.isFinite(float)) {
          break;
        }
        if (type == ScalarType.FLOAT)
          assertFloat32(float);
        return float;
      // int32, fixed32, uint32: JSON value will be a decimal number. Either numbers or strings are accepted.
      case ScalarType.INT32:
      case ScalarType.FIXED32:
      case ScalarType.SFIXED32:
      case ScalarType.SINT32:
      case ScalarType.UINT32:
        let int32;
        if (typeof json == "number")
          int32 = json;
        else if (typeof json == "string" && json.length > 0) {
          if (json.trim().length === json.length)
            int32 = Number(json);
        }
        if (int32 === void 0)
          break;
        if (type == ScalarType.UINT32 || type == ScalarType.FIXED32)
          assertUInt32(int32);
        else
          assertInt32(int32);
        return int32;
      // int64, fixed64, uint64: JSON value will be a decimal string. Either numbers or strings are accepted.
      case ScalarType.INT64:
      case ScalarType.SFIXED64:
      case ScalarType.SINT64:
        if (typeof json != "number" && typeof json != "string")
          break;
        const long = protoInt64.parse(json);
        return longType ? long.toString() : long;
      case ScalarType.FIXED64:
      case ScalarType.UINT64:
        if (typeof json != "number" && typeof json != "string")
          break;
        const uLong = protoInt64.uParse(json);
        return longType ? uLong.toString() : uLong;
      // bool:
      case ScalarType.BOOL:
        if (typeof json !== "boolean")
          break;
        return json;
      // string:
      case ScalarType.STRING:
        if (typeof json !== "string") {
          break;
        }
        try {
          encodeURIComponent(json);
        } catch (e) {
          throw new Error("invalid UTF8");
        }
        return json;
      // bytes: JSON value will be the data encoded as a string using standard base64 encoding with paddings.
      // Either standard or URL-safe base64 encoding with/without paddings are accepted.
      case ScalarType.BYTES:
        if (json === "")
          return new Uint8Array(0);
        if (typeof json !== "string")
          break;
        return protoBase64.dec(json);
    }
    throw new Error();
  }
  function readEnum(type, json, ignoreUnknownFields, nullAsZeroValue) {
    if (json === null) {
      if (type.typeName == "google.protobuf.NullValue") {
        return 0;
      }
      return nullAsZeroValue ? type.values[0].no : tokenNull;
    }
    switch (typeof json) {
      case "number":
        if (Number.isInteger(json)) {
          return json;
        }
        break;
      case "string":
        const value = type.findName(json);
        if (value !== void 0) {
          return value.no;
        }
        if (ignoreUnknownFields) {
          return tokenIgnoredUnknownEnum;
        }
        break;
    }
    throw new Error(`cannot decode enum ${type.typeName} from JSON: ${debugJsonValue(json)}`);
  }
  function canEmitFieldDefaultValue(field) {
    if (field.repeated || field.kind == "map") {
      return true;
    }
    if (field.oneof) {
      return false;
    }
    if (field.kind == "message") {
      return false;
    }
    if (field.opt || field.req) {
      return false;
    }
    return true;
  }
  function writeField(field, value, options) {
    if (field.kind == "map") {
      assert(typeof value == "object" && value != null);
      const jsonObj = {};
      const entries = Object.entries(value);
      switch (field.V.kind) {
        case "scalar":
          for (const [entryKey, entryValue] of entries) {
            jsonObj[entryKey.toString()] = writeScalar(field.V.T, entryValue);
          }
          break;
        case "message":
          for (const [entryKey, entryValue] of entries) {
            jsonObj[entryKey.toString()] = entryValue.toJson(options);
          }
          break;
        case "enum":
          const enumType = field.V.T;
          for (const [entryKey, entryValue] of entries) {
            jsonObj[entryKey.toString()] = writeEnum(enumType, entryValue, options.enumAsInteger);
          }
          break;
      }
      return options.emitDefaultValues || entries.length > 0 ? jsonObj : void 0;
    }
    if (field.repeated) {
      assert(Array.isArray(value));
      const jsonArr = [];
      switch (field.kind) {
        case "scalar":
          for (let i = 0; i < value.length; i++) {
            jsonArr.push(writeScalar(field.T, value[i]));
          }
          break;
        case "enum":
          for (let i = 0; i < value.length; i++) {
            jsonArr.push(writeEnum(field.T, value[i], options.enumAsInteger));
          }
          break;
        case "message":
          for (let i = 0; i < value.length; i++) {
            jsonArr.push(value[i].toJson(options));
          }
          break;
      }
      return options.emitDefaultValues || jsonArr.length > 0 ? jsonArr : void 0;
    }
    switch (field.kind) {
      case "scalar":
        return writeScalar(field.T, value);
      case "enum":
        return writeEnum(field.T, value, options.enumAsInteger);
      case "message":
        return wrapField(field.T, value).toJson(options);
    }
  }
  function writeEnum(type, value, enumAsInteger) {
    var _a5;
    assert(typeof value == "number");
    if (type.typeName == "google.protobuf.NullValue") {
      return null;
    }
    if (enumAsInteger) {
      return value;
    }
    const val = type.findNumber(value);
    return (_a5 = val === null || val === void 0 ? void 0 : val.name) !== null && _a5 !== void 0 ? _a5 : value;
  }
  function writeScalar(type, value) {
    switch (type) {
      // int32, fixed32, uint32: JSON value will be a decimal number. Either numbers or strings are accepted.
      case ScalarType.INT32:
      case ScalarType.SFIXED32:
      case ScalarType.SINT32:
      case ScalarType.FIXED32:
      case ScalarType.UINT32:
        assert(typeof value == "number");
        return value;
      // float, double: JSON value will be a number or one of the special string values "NaN", "Infinity", and "-Infinity".
      // Either numbers or strings are accepted. Exponent notation is also accepted.
      case ScalarType.FLOAT:
      // assertFloat32(value);
      case ScalarType.DOUBLE:
        assert(typeof value == "number");
        if (Number.isNaN(value))
          return "NaN";
        if (value === Number.POSITIVE_INFINITY)
          return "Infinity";
        if (value === Number.NEGATIVE_INFINITY)
          return "-Infinity";
        return value;
      // string:
      case ScalarType.STRING:
        assert(typeof value == "string");
        return value;
      // bool:
      case ScalarType.BOOL:
        assert(typeof value == "boolean");
        return value;
      // JSON value will be a decimal string. Either numbers or strings are accepted.
      case ScalarType.UINT64:
      case ScalarType.FIXED64:
      case ScalarType.INT64:
      case ScalarType.SFIXED64:
      case ScalarType.SINT64:
        assert(typeof value == "bigint" || typeof value == "string" || typeof value == "number");
        return value.toString();
      // bytes: JSON value will be the data encoded as a string using standard base64 encoding with paddings.
      // Either standard or URL-safe base64 encoding with/without paddings are accepted.
      case ScalarType.BYTES:
        assert(value instanceof Uint8Array);
        return protoBase64.enc(value);
    }
  }

  // out/node_modules/@bufbuild/protobuf/dist/esm/private/binary-format.js
  var unknownFieldsSymbol = /* @__PURE__ */ Symbol("@bufbuild/protobuf/unknown-fields");
  var readDefaults = {
    readUnknownFields: true,
    readerFactory: (bytes) => new BinaryReader(bytes)
  };
  var writeDefaults = {
    writeUnknownFields: true,
    writerFactory: () => new BinaryWriter()
  };
  function makeReadOptions2(options) {
    return options ? Object.assign(Object.assign({}, readDefaults), options) : readDefaults;
  }
  function makeWriteOptions2(options) {
    return options ? Object.assign(Object.assign({}, writeDefaults), options) : writeDefaults;
  }
  function makeBinaryFormat() {
    return {
      makeReadOptions: makeReadOptions2,
      makeWriteOptions: makeWriteOptions2,
      listUnknownFields(message) {
        var _a5;
        return (_a5 = message[unknownFieldsSymbol]) !== null && _a5 !== void 0 ? _a5 : [];
      },
      discardUnknownFields(message) {
        delete message[unknownFieldsSymbol];
      },
      writeUnknownFields(message, writer) {
        const m = message;
        const c = m[unknownFieldsSymbol];
        if (c) {
          for (const f of c) {
            writer.tag(f.no, f.wireType).raw(f.data);
          }
        }
      },
      onUnknownField(message, no, wireType, data) {
        const m = message;
        if (!Array.isArray(m[unknownFieldsSymbol])) {
          m[unknownFieldsSymbol] = [];
        }
        m[unknownFieldsSymbol].push({ no, wireType, data });
      },
      readMessage(message, reader, lengthOrEndTagFieldNo, options, delimitedMessageEncoding) {
        const type = message.getType();
        const end = delimitedMessageEncoding ? reader.len : reader.pos + lengthOrEndTagFieldNo;
        let fieldNo, wireType;
        while (reader.pos < end) {
          [fieldNo, wireType] = reader.tag();
          if (delimitedMessageEncoding === true && wireType == WireType.EndGroup) {
            break;
          }
          const field = type.fields.find(fieldNo);
          if (!field) {
            const data = reader.skip(wireType, fieldNo);
            if (options.readUnknownFields) {
              this.onUnknownField(message, fieldNo, wireType, data);
            }
            continue;
          }
          readField2(message, reader, field, wireType, options);
        }
        if (delimitedMessageEncoding && // eslint-disable-line @typescript-eslint/strict-boolean-expressions
        (wireType != WireType.EndGroup || fieldNo !== lengthOrEndTagFieldNo)) {
          throw new Error(`invalid end group tag`);
        }
      },
      readField: readField2,
      writeMessage(message, writer, options) {
        const type = message.getType();
        for (const field of type.fields.byNumber()) {
          if (!isFieldSet(field, message)) {
            if (field.req) {
              throw new Error(`cannot encode field ${type.typeName}.${field.name} to binary: required field not set`);
            }
            continue;
          }
          const value = field.oneof ? message[field.oneof.localName].value : message[field.localName];
          writeField2(field, value, writer, options);
        }
        if (options.writeUnknownFields) {
          this.writeUnknownFields(message, writer);
        }
        return writer;
      },
      writeField(field, value, writer, options) {
        if (value === void 0) {
          return void 0;
        }
        writeField2(field, value, writer, options);
      }
    };
  }
  function readField2(target, reader, field, wireType, options) {
    let { repeated, localName } = field;
    if (field.oneof) {
      target = target[field.oneof.localName];
      if (target.case != localName) {
        delete target.value;
      }
      target.case = localName;
      localName = "value";
    }
    switch (field.kind) {
      case "scalar":
      case "enum":
        const scalarType = field.kind == "enum" ? ScalarType.INT32 : field.T;
        let read = readScalar2;
        if (field.kind == "scalar" && field.L > 0) {
          read = readScalarLTString;
        }
        if (repeated) {
          let arr = target[localName];
          const isPacked = wireType == WireType.LengthDelimited && scalarType != ScalarType.STRING && scalarType != ScalarType.BYTES;
          if (isPacked) {
            let e = reader.uint32() + reader.pos;
            while (reader.pos < e) {
              arr.push(read(reader, scalarType));
            }
          } else {
            arr.push(read(reader, scalarType));
          }
        } else {
          target[localName] = read(reader, scalarType);
        }
        break;
      case "message":
        const messageType = field.T;
        if (repeated) {
          target[localName].push(readMessageField(reader, new messageType(), options, field));
        } else {
          if (isMessage(target[localName])) {
            readMessageField(reader, target[localName], options, field);
          } else {
            target[localName] = readMessageField(reader, new messageType(), options, field);
            if (messageType.fieldWrapper && !field.oneof && !field.repeated) {
              target[localName] = messageType.fieldWrapper.unwrapField(target[localName]);
            }
          }
        }
        break;
      case "map":
        let [mapKey, mapVal] = readMapEntry(field, reader, options);
        target[localName][mapKey] = mapVal;
        break;
    }
  }
  function readMessageField(reader, message, options, field) {
    const format = message.getType().runtime.bin;
    const delimited = field === null || field === void 0 ? void 0 : field.delimited;
    format.readMessage(
      message,
      reader,
      delimited ? field.no : reader.uint32(),
      // eslint-disable-line @typescript-eslint/strict-boolean-expressions
      options,
      delimited
    );
    return message;
  }
  function readMapEntry(field, reader, options) {
    const length = reader.uint32(), end = reader.pos + length;
    let key2, val;
    while (reader.pos < end) {
      const [fieldNo] = reader.tag();
      switch (fieldNo) {
        case 1:
          key2 = readScalar2(reader, field.K);
          break;
        case 2:
          switch (field.V.kind) {
            case "scalar":
              val = readScalar2(reader, field.V.T);
              break;
            case "enum":
              val = reader.int32();
              break;
            case "message":
              val = readMessageField(reader, new field.V.T(), options, void 0);
              break;
          }
          break;
      }
    }
    if (key2 === void 0) {
      key2 = scalarZeroValue(field.K, LongType.BIGINT);
    }
    if (typeof key2 != "string" && typeof key2 != "number") {
      key2 = key2.toString();
    }
    if (val === void 0) {
      switch (field.V.kind) {
        case "scalar":
          val = scalarZeroValue(field.V.T, LongType.BIGINT);
          break;
        case "enum":
          val = field.V.T.values[0].no;
          break;
        case "message":
          val = new field.V.T();
          break;
      }
    }
    return [key2, val];
  }
  function readScalarLTString(reader, type) {
    const v = readScalar2(reader, type);
    return typeof v == "bigint" ? v.toString() : v;
  }
  function readScalar2(reader, type) {
    switch (type) {
      case ScalarType.STRING:
        return reader.string();
      case ScalarType.BOOL:
        return reader.bool();
      case ScalarType.DOUBLE:
        return reader.double();
      case ScalarType.FLOAT:
        return reader.float();
      case ScalarType.INT32:
        return reader.int32();
      case ScalarType.INT64:
        return reader.int64();
      case ScalarType.UINT64:
        return reader.uint64();
      case ScalarType.FIXED64:
        return reader.fixed64();
      case ScalarType.BYTES:
        return reader.bytes();
      case ScalarType.FIXED32:
        return reader.fixed32();
      case ScalarType.SFIXED32:
        return reader.sfixed32();
      case ScalarType.SFIXED64:
        return reader.sfixed64();
      case ScalarType.SINT64:
        return reader.sint64();
      case ScalarType.UINT32:
        return reader.uint32();
      case ScalarType.SINT32:
        return reader.sint32();
    }
  }
  function writeField2(field, value, writer, options) {
    assert(value !== void 0);
    const repeated = field.repeated;
    switch (field.kind) {
      case "scalar":
      case "enum":
        let scalarType = field.kind == "enum" ? ScalarType.INT32 : field.T;
        if (repeated) {
          assert(Array.isArray(value));
          if (field.packed) {
            writePacked(writer, scalarType, field.no, value);
          } else {
            for (const item of value) {
              writeScalar2(writer, scalarType, field.no, item);
            }
          }
        } else {
          writeScalar2(writer, scalarType, field.no, value);
        }
        break;
      case "message":
        if (repeated) {
          assert(Array.isArray(value));
          for (const item of value) {
            writeMessageField(writer, options, field, item);
          }
        } else {
          writeMessageField(writer, options, field, value);
        }
        break;
      case "map":
        assert(typeof value == "object" && value != null);
        for (const [key2, val] of Object.entries(value)) {
          writeMapEntry(writer, options, field, key2, val);
        }
        break;
    }
  }
  function writeMapEntry(writer, options, field, key2, value) {
    writer.tag(field.no, WireType.LengthDelimited);
    writer.fork();
    let keyValue = key2;
    switch (field.K) {
      case ScalarType.INT32:
      case ScalarType.FIXED32:
      case ScalarType.UINT32:
      case ScalarType.SFIXED32:
      case ScalarType.SINT32:
        keyValue = Number.parseInt(key2);
        break;
      case ScalarType.BOOL:
        assert(key2 == "true" || key2 == "false");
        keyValue = key2 == "true";
        break;
    }
    writeScalar2(writer, field.K, 1, keyValue);
    switch (field.V.kind) {
      case "scalar":
        writeScalar2(writer, field.V.T, 2, value);
        break;
      case "enum":
        writeScalar2(writer, ScalarType.INT32, 2, value);
        break;
      case "message":
        assert(value !== void 0);
        writer.tag(2, WireType.LengthDelimited).bytes(value.toBinary(options));
        break;
    }
    writer.join();
  }
  function writeMessageField(writer, options, field, value) {
    const message = wrapField(field.T, value);
    if (field.delimited)
      writer.tag(field.no, WireType.StartGroup).raw(message.toBinary(options)).tag(field.no, WireType.EndGroup);
    else
      writer.tag(field.no, WireType.LengthDelimited).bytes(message.toBinary(options));
  }
  function writeScalar2(writer, type, fieldNo, value) {
    assert(value !== void 0);
    let [wireType, method] = scalarTypeInfo(type);
    writer.tag(fieldNo, wireType)[method](value);
  }
  function writePacked(writer, type, fieldNo, value) {
    if (!value.length) {
      return;
    }
    writer.tag(fieldNo, WireType.LengthDelimited).fork();
    let [, method] = scalarTypeInfo(type);
    for (let i = 0; i < value.length; i++) {
      writer[method](value[i]);
    }
    writer.join();
  }
  function scalarTypeInfo(type) {
    let wireType = WireType.Varint;
    switch (type) {
      case ScalarType.BYTES:
      case ScalarType.STRING:
        wireType = WireType.LengthDelimited;
        break;
      case ScalarType.DOUBLE:
      case ScalarType.FIXED64:
      case ScalarType.SFIXED64:
        wireType = WireType.Bit64;
        break;
      case ScalarType.FIXED32:
      case ScalarType.SFIXED32:
      case ScalarType.FLOAT:
        wireType = WireType.Bit32;
        break;
    }
    const method = ScalarType[type].toLowerCase();
    return [wireType, method];
  }

  // out/node_modules/@bufbuild/protobuf/dist/esm/private/util-common.js
  function makeUtilCommon() {
    return {
      setEnumType,
      initPartial(source2, target) {
        if (source2 === void 0) {
          return;
        }
        const type = target.getType();
        for (const member of type.fields.byMember()) {
          const localName = member.localName, t = target, s = source2;
          if (s[localName] == null) {
            continue;
          }
          switch (member.kind) {
            case "oneof":
              const sk = s[localName].case;
              if (sk === void 0) {
                continue;
              }
              const sourceField = member.findField(sk);
              let val = s[localName].value;
              if (sourceField && sourceField.kind == "message" && !isMessage(val, sourceField.T)) {
                val = new sourceField.T(val);
              } else if (sourceField && sourceField.kind === "scalar" && sourceField.T === ScalarType.BYTES) {
                val = toU8Arr(val);
              }
              t[localName] = { case: sk, value: val };
              break;
            case "scalar":
            case "enum":
              let copy = s[localName];
              if (member.T === ScalarType.BYTES) {
                copy = member.repeated ? copy.map(toU8Arr) : toU8Arr(copy);
              }
              t[localName] = copy;
              break;
            case "map":
              switch (member.V.kind) {
                case "scalar":
                case "enum":
                  if (member.V.T === ScalarType.BYTES) {
                    for (const [k, v] of Object.entries(s[localName])) {
                      t[localName][k] = toU8Arr(v);
                    }
                  } else {
                    Object.assign(t[localName], s[localName]);
                  }
                  break;
                case "message":
                  const messageType = member.V.T;
                  for (const k of Object.keys(s[localName])) {
                    let val2 = s[localName][k];
                    if (!messageType.fieldWrapper) {
                      val2 = new messageType(val2);
                    }
                    t[localName][k] = val2;
                  }
                  break;
              }
              break;
            case "message":
              const mt = member.T;
              if (member.repeated) {
                t[localName] = s[localName].map((val2) => isMessage(val2, mt) ? val2 : new mt(val2));
              } else {
                const val2 = s[localName];
                if (mt.fieldWrapper) {
                  if (
                    // We can't use BytesValue.typeName as that will create a circular import
                    mt.typeName === "google.protobuf.BytesValue"
                  ) {
                    t[localName] = toU8Arr(val2);
                  } else {
                    t[localName] = val2;
                  }
                } else {
                  t[localName] = isMessage(val2, mt) ? val2 : new mt(val2);
                }
              }
              break;
          }
        }
      },
      // TODO use isFieldSet() here to support future field presence
      equals(type, a, b) {
        if (a === b) {
          return true;
        }
        if (!a || !b) {
          return false;
        }
        return type.fields.byMember().every((m) => {
          const va = a[m.localName];
          const vb = b[m.localName];
          if (m.repeated) {
            if (va.length !== vb.length) {
              return false;
            }
            switch (m.kind) {
              case "message":
                return va.every((a2, i) => m.T.equals(a2, vb[i]));
              case "scalar":
                return va.every((a2, i) => scalarEquals(m.T, a2, vb[i]));
              case "enum":
                return va.every((a2, i) => scalarEquals(ScalarType.INT32, a2, vb[i]));
            }
            throw new Error(`repeated cannot contain ${m.kind}`);
          }
          switch (m.kind) {
            case "message":
              return m.T.equals(va, vb);
            case "enum":
              return scalarEquals(ScalarType.INT32, va, vb);
            case "scalar":
              return scalarEquals(m.T, va, vb);
            case "oneof":
              if (va.case !== vb.case) {
                return false;
              }
              const s = m.findField(va.case);
              if (s === void 0) {
                return true;
              }
              switch (s.kind) {
                case "message":
                  return s.T.equals(va.value, vb.value);
                case "enum":
                  return scalarEquals(ScalarType.INT32, va.value, vb.value);
                case "scalar":
                  return scalarEquals(s.T, va.value, vb.value);
              }
              throw new Error(`oneof cannot contain ${s.kind}`);
            case "map":
              const keys = Object.keys(va).concat(Object.keys(vb));
              switch (m.V.kind) {
                case "message":
                  const messageType = m.V.T;
                  return keys.every((k) => messageType.equals(va[k], vb[k]));
                case "enum":
                  return keys.every((k) => scalarEquals(ScalarType.INT32, va[k], vb[k]));
                case "scalar":
                  const scalarType = m.V.T;
                  return keys.every((k) => scalarEquals(scalarType, va[k], vb[k]));
              }
              break;
          }
        });
      },
      // TODO use isFieldSet() here to support future field presence
      clone(message) {
        const type = message.getType(), target = new type(), any = target;
        for (const member of type.fields.byMember()) {
          const source2 = message[member.localName];
          let copy;
          if (member.repeated) {
            copy = source2.map(cloneSingularField);
          } else if (member.kind == "map") {
            copy = any[member.localName];
            for (const [key2, v] of Object.entries(source2)) {
              copy[key2] = cloneSingularField(v);
            }
          } else if (member.kind == "oneof") {
            const f = member.findField(source2.case);
            copy = f ? { case: source2.case, value: cloneSingularField(source2.value) } : { case: void 0 };
          } else {
            copy = cloneSingularField(source2);
          }
          any[member.localName] = copy;
        }
        for (const uf of type.runtime.bin.listUnknownFields(message)) {
          type.runtime.bin.onUnknownField(any, uf.no, uf.wireType, uf.data);
        }
        return target;
      }
    };
  }
  function cloneSingularField(value) {
    if (value === void 0) {
      return value;
    }
    if (isMessage(value)) {
      return value.clone();
    }
    if (value instanceof Uint8Array) {
      const c = new Uint8Array(value.byteLength);
      c.set(value);
      return c;
    }
    return value;
  }
  function toU8Arr(input) {
    return input instanceof Uint8Array ? input : new Uint8Array(input);
  }

  // out/node_modules/@bufbuild/protobuf/dist/esm/private/proto-runtime.js
  function makeProtoRuntime(syntax, newFieldList, initFields) {
    return {
      syntax,
      json: makeJsonFormat(),
      bin: makeBinaryFormat(),
      util: Object.assign(Object.assign({}, makeUtilCommon()), {
        newFieldList,
        initFields
      }),
      makeMessageType(typeName, fields, opt) {
        return makeMessageType(this, typeName, fields, opt);
      },
      makeEnum,
      makeEnumType,
      getEnumType,
      makeExtension(typeName, extendee, field) {
        return makeExtension(this, typeName, extendee, field);
      }
    };
  }

  // out/node_modules/@bufbuild/protobuf/dist/esm/private/field-list.js
  var InternalFieldList = class {
    constructor(fields, normalizer) {
      this._fields = fields;
      this._normalizer = normalizer;
    }
    findJsonName(jsonName) {
      if (!this.jsonNames) {
        const t = {};
        for (const f of this.list()) {
          t[f.jsonName] = t[f.name] = f;
        }
        this.jsonNames = t;
      }
      return this.jsonNames[jsonName];
    }
    find(fieldNo) {
      if (!this.numbers) {
        const t = {};
        for (const f of this.list()) {
          t[f.no] = f;
        }
        this.numbers = t;
      }
      return this.numbers[fieldNo];
    }
    list() {
      if (!this.all) {
        this.all = this._normalizer(this._fields);
      }
      return this.all;
    }
    byNumber() {
      if (!this.numbersAsc) {
        this.numbersAsc = this.list().concat().sort((a, b) => a.no - b.no);
      }
      return this.numbersAsc;
    }
    byMember() {
      if (!this.members) {
        this.members = [];
        const a = this.members;
        let o;
        for (const f of this.list()) {
          if (f.oneof) {
            if (f.oneof !== o) {
              o = f.oneof;
              a.push(o);
            }
          } else {
            a.push(f);
          }
        }
      }
      return this.members;
    }
  };

  // out/node_modules/@bufbuild/protobuf/dist/esm/private/names.js
  function localFieldName(protoName, inOneof) {
    const name = protoCamelCase(protoName);
    if (inOneof) {
      return name;
    }
    return safeObjectProperty(safeMessageProperty(name));
  }
  function localOneofName(protoName) {
    return localFieldName(protoName, false);
  }
  var fieldJsonName = protoCamelCase;
  function protoCamelCase(snakeCase) {
    let capNext = false;
    const b = [];
    for (let i = 0; i < snakeCase.length; i++) {
      let c = snakeCase.charAt(i);
      switch (c) {
        case "_":
          capNext = true;
          break;
        case "0":
        case "1":
        case "2":
        case "3":
        case "4":
        case "5":
        case "6":
        case "7":
        case "8":
        case "9":
          b.push(c);
          capNext = false;
          break;
        default:
          if (capNext) {
            capNext = false;
            c = c.toUpperCase();
          }
          b.push(c);
          break;
      }
    }
    return b.join("");
  }
  var reservedObjectProperties = /* @__PURE__ */ new Set([
    // names reserved by JavaScript
    "constructor",
    "toString",
    "toJSON",
    "valueOf"
  ]);
  var reservedMessageProperties = /* @__PURE__ */ new Set([
    // names reserved by the runtime
    "getType",
    "clone",
    "equals",
    "fromBinary",
    "fromJson",
    "fromJsonString",
    "toBinary",
    "toJson",
    "toJsonString",
    // names reserved by the runtime for the future
    "toObject"
  ]);
  var fallback = (name) => `${name}$`;
  var safeMessageProperty = (name) => {
    if (reservedMessageProperties.has(name)) {
      return fallback(name);
    }
    return name;
  };
  var safeObjectProperty = (name) => {
    if (reservedObjectProperties.has(name)) {
      return fallback(name);
    }
    return name;
  };

  // out/node_modules/@bufbuild/protobuf/dist/esm/private/field.js
  var InternalOneofInfo = class {
    constructor(name) {
      this.kind = "oneof";
      this.repeated = false;
      this.packed = false;
      this.opt = false;
      this.req = false;
      this.default = void 0;
      this.fields = [];
      this.name = name;
      this.localName = localOneofName(name);
    }
    addField(field) {
      assert(field.oneof === this, `field ${field.name} not one of ${this.name}`);
      this.fields.push(field);
    }
    findField(localName) {
      if (!this._lookup) {
        this._lookup = /* @__PURE__ */ Object.create(null);
        for (let i = 0; i < this.fields.length; i++) {
          this._lookup[this.fields[i].localName] = this.fields[i];
        }
      }
      return this._lookup[localName];
    }
  };

  // out/node_modules/@bufbuild/protobuf/dist/esm/private/field-normalize.js
  function normalizeFieldInfos(fieldInfos, packedByDefault) {
    var _a5, _b3, _c2, _d, _e, _f;
    const r = [];
    let o;
    for (const field of typeof fieldInfos == "function" ? fieldInfos() : fieldInfos) {
      const f = field;
      f.localName = localFieldName(field.name, field.oneof !== void 0);
      f.jsonName = (_a5 = field.jsonName) !== null && _a5 !== void 0 ? _a5 : fieldJsonName(field.name);
      f.repeated = (_b3 = field.repeated) !== null && _b3 !== void 0 ? _b3 : false;
      if (field.kind == "scalar") {
        f.L = (_c2 = field.L) !== null && _c2 !== void 0 ? _c2 : LongType.BIGINT;
      }
      f.delimited = (_d = field.delimited) !== null && _d !== void 0 ? _d : false;
      f.req = (_e = field.req) !== null && _e !== void 0 ? _e : false;
      f.opt = (_f = field.opt) !== null && _f !== void 0 ? _f : false;
      if (field.packed === void 0) {
        if (packedByDefault) {
          f.packed = field.kind == "enum" || field.kind == "scalar" && field.T != ScalarType.BYTES && field.T != ScalarType.STRING;
        } else {
          f.packed = false;
        }
      }
      if (field.oneof !== void 0) {
        const ooname = typeof field.oneof == "string" ? field.oneof : field.oneof.name;
        if (!o || o.name != ooname) {
          o = new InternalOneofInfo(ooname);
        }
        f.oneof = o;
        o.addField(f);
      }
      r.push(f);
    }
    return r;
  }

  // out/node_modules/@bufbuild/protobuf/dist/esm/proto3.js
  var proto3 = makeProtoRuntime(
    "proto3",
    (fields) => {
      return new InternalFieldList(fields, (source2) => normalizeFieldInfos(source2, true));
    },
    // TODO merge with proto2 and initExtensionField, also see initPartial, equals, clone
    (target) => {
      for (const member of target.getType().fields.byMember()) {
        if (member.opt) {
          continue;
        }
        const name = member.localName, t = target;
        if (member.repeated) {
          t[name] = [];
          continue;
        }
        switch (member.kind) {
          case "oneof":
            t[name] = { case: void 0 };
            break;
          case "enum":
            t[name] = 0;
            break;
          case "map":
            t[name] = {};
            break;
          case "scalar":
            t[name] = scalarZeroValue(member.T, member.L);
            break;
          case "message":
            break;
        }
      }
    }
  );

  // out/ts/lib/generated/anki/generic_pb.js
  var Empty = /* @__PURE__ */ proto3.makeMessageType(
    "",
    []
  );
  var Json = /* @__PURE__ */ proto3.makeMessageType(
    "",
    () => [
      {
        no: 1,
        name: "json",
        kind: "scalar",
        T: 12
        /* ScalarType.BYTES */
      }
    ]
  );

  // out/ts/lib/generated/anki/scheduler_pb.js
  var CongratsInfoResponse = /* @__PURE__ */ proto3.makeMessageType(
    "",
    () => [
      {
        no: 1,
        name: "learn_remaining",
        kind: "scalar",
        T: 13
        /* ScalarType.UINT32 */
      },
      {
        no: 2,
        name: "secs_until_next_learn",
        kind: "scalar",
        T: 13
        /* ScalarType.UINT32 */
      },
      {
        no: 3,
        name: "review_remaining",
        kind: "scalar",
        T: 8
        /* ScalarType.BOOL */
      },
      {
        no: 4,
        name: "new_remaining",
        kind: "scalar",
        T: 8
        /* ScalarType.BOOL */
      },
      {
        no: 5,
        name: "have_sched_buried",
        kind: "scalar",
        T: 8
        /* ScalarType.BOOL */
      },
      {
        no: 6,
        name: "have_user_buried",
        kind: "scalar",
        T: 8
        /* ScalarType.BOOL */
      },
      {
        no: 7,
        name: "is_filtered_deck",
        kind: "scalar",
        T: 8
        /* ScalarType.BOOL */
      },
      {
        no: 8,
        name: "bridge_commands_supported",
        kind: "scalar",
        T: 8
        /* ScalarType.BOOL */
      },
      {
        no: 9,
        name: "deck_description",
        kind: "scalar",
        T: 9
        /* ScalarType.STRING */
      }
    ]
  );

  // out/ts/lib/generated/anki/i18n_pb.js
  var I18nResourcesRequest = /* @__PURE__ */ proto3.makeMessageType(
    "",
    () => [
      { no: 1, name: "modules", kind: "scalar", T: 9, repeated: true }
    ]
  );

  // out/ts/lib/generated/backend.ts
  async function congratsInfo(input, options) {
    return await postProto("congratsInfo", new Empty(input), CongratsInfoResponse, options, 0);
  }
  async function i18nResources(input, options) {
    return await postProto("i18nResources", new I18nResourcesRequest(input), Json, options, 0);
  }

  // out/node_modules/@fluent/bundle/esm/types.js
  var FluentType = class {
    /**
     * Create a `FluentType` instance.
     *
     * @param value The JavaScript value to wrap.
     */
    constructor(value) {
      this.value = value;
    }
    /**
     * Unwrap the raw value stored by this `FluentType`.
     */
    valueOf() {
      return this.value;
    }
  };
  var FluentNone = class extends FluentType {
    /**
     * Create an instance of `FluentNone` with an optional fallback value.
     * @param value The fallback value of this `FluentNone`.
     */
    constructor(value = "???") {
      super(value);
    }
    /**
     * Format this `FluentNone` to the fallback string.
     */
    toString(scope) {
      return `{${this.value}}`;
    }
  };
  var FluentNumber = class extends FluentType {
    /**
     * Create an instance of `FluentNumber` with options to the
     * `Intl.NumberFormat` constructor.
     *
     * @param value The number value of this `FluentNumber`.
     * @param opts Options which will be passed to `Intl.NumberFormat`.
     */
    constructor(value, opts = {}) {
      super(value);
      this.opts = opts;
    }
    /**
     * Format this `FluentNumber` to a string.
     */
    toString(scope) {
      if (scope) {
        try {
          const nf = scope.memoizeIntlObject(Intl.NumberFormat, this.opts);
          return nf.format(this.value);
        } catch (err) {
          scope.reportError(err);
        }
      }
      return this.value.toString(10);
    }
  };
  var FluentDateTime = class _FluentDateTime extends FluentType {
    static supportsValue(value) {
      if (typeof value === "number")
        return true;
      if (value instanceof Date)
        return true;
      if (value instanceof FluentType)
        return _FluentDateTime.supportsValue(value.valueOf());
      if ("Temporal" in globalThis) {
        const _Temporal = globalThis.Temporal;
        if (value instanceof _Temporal.Instant || value instanceof _Temporal.PlainDateTime || value instanceof _Temporal.PlainDate || value instanceof _Temporal.PlainMonthDay || value instanceof _Temporal.PlainTime || value instanceof _Temporal.PlainYearMonth) {
          return true;
        }
      }
      return false;
    }
    /**
     * Create an instance of `FluentDateTime` with options to the
     * `Intl.DateTimeFormat` constructor.
     *
     * @param value The number value of this `FluentDateTime`, in milliseconds.
     * @param opts Options which will be passed to `Intl.DateTimeFormat`.
     */
    constructor(value, opts = {}) {
      if (value instanceof _FluentDateTime) {
        opts = { ...value.opts, ...opts };
        value = value.value;
      } else if (value instanceof FluentType) {
        value = value.valueOf();
      }
      if (typeof value === "object" && "calendarId" in value && opts.calendar === void 0) {
        opts = { ...opts, calendar: value.calendarId };
      }
      super(value);
      this.opts = opts;
    }
    [Symbol.toPrimitive](hint) {
      return hint === "string" ? this.toString() : this.toNumber();
    }
    /**
     * Convert this `FluentDateTime` to a number.
     * Note that this isn't always possible due to the nature of Temporal objects.
     * In such cases, a TypeError will be thrown.
     */
    toNumber() {
      const value = this.value;
      if (typeof value === "number")
        return value;
      if (value instanceof Date)
        return value.getTime();
      if ("epochMilliseconds" in value) {
        return value.epochMilliseconds;
      }
      if ("toZonedDateTime" in value) {
        return value.toZonedDateTime("UTC").epochMilliseconds;
      }
      throw new TypeError("Unwrapping a non-number value as a number");
    }
    /**
     * Format this `FluentDateTime` to a string.
     */
    toString(scope) {
      if (scope) {
        try {
          const dtf = scope.memoizeIntlObject(Intl.DateTimeFormat, this.opts);
          return dtf.format(this.value);
        } catch (err) {
          scope.reportError(err);
        }
      }
      if (typeof this.value === "number" || this.value instanceof Date) {
        return new Date(this.value).toISOString();
      }
      return this.value.toString();
    }
  };

  // out/node_modules/@fluent/bundle/esm/resolver.js
  var MAX_PLACEABLES = 100;
  var FSI = "\u2068";
  var PDI = "\u2069";
  function match(scope, selector, key2) {
    if (key2 === selector) {
      return true;
    }
    if (key2 instanceof FluentNumber && selector instanceof FluentNumber && key2.value === selector.value) {
      return true;
    }
    if (selector instanceof FluentNumber && typeof key2 === "string") {
      let category = scope.memoizeIntlObject(Intl.PluralRules, selector.opts).select(selector.value);
      if (key2 === category) {
        return true;
      }
    }
    return false;
  }
  function getDefault(scope, variants, star) {
    if (variants[star]) {
      return resolvePattern(scope, variants[star].value);
    }
    scope.reportError(new RangeError("No default"));
    return new FluentNone();
  }
  function getArguments(scope, args) {
    const positional = [];
    const named = /* @__PURE__ */ Object.create(null);
    for (const arg of args) {
      if (arg.type === "narg") {
        named[arg.name] = resolveExpression(scope, arg.value);
      } else {
        positional.push(resolveExpression(scope, arg));
      }
    }
    return { positional, named };
  }
  function resolveExpression(scope, expr) {
    switch (expr.type) {
      case "str":
        return expr.value;
      case "num":
        return new FluentNumber(expr.value, {
          minimumFractionDigits: expr.precision
        });
      case "var":
        return resolveVariableReference(scope, expr);
      case "mesg":
        return resolveMessageReference(scope, expr);
      case "term":
        return resolveTermReference(scope, expr);
      case "func":
        return resolveFunctionReference(scope, expr);
      case "select":
        return resolveSelectExpression(scope, expr);
      default:
        return new FluentNone();
    }
  }
  function resolveVariableReference(scope, { name }) {
    let arg;
    if (scope.params) {
      if (Object.prototype.hasOwnProperty.call(scope.params, name)) {
        arg = scope.params[name];
      } else {
        return new FluentNone(`$${name}`);
      }
    } else if (scope.args && Object.prototype.hasOwnProperty.call(scope.args, name)) {
      arg = scope.args[name];
    } else {
      scope.reportError(new ReferenceError(`Unknown variable: $${name}`));
      return new FluentNone(`$${name}`);
    }
    if (arg instanceof FluentType) {
      return arg;
    }
    switch (typeof arg) {
      case "string":
        return arg;
      case "number":
        return new FluentNumber(arg);
      case "object":
        if (FluentDateTime.supportsValue(arg)) {
          return new FluentDateTime(arg);
        }
      // eslint-disable-next-line no-fallthrough
      default:
        scope.reportError(new TypeError(`Variable type not supported: $${name}, ${typeof arg}`));
        return new FluentNone(`$${name}`);
    }
  }
  function resolveMessageReference(scope, { name, attr: attr2 }) {
    const message = scope.bundle._messages.get(name);
    if (!message) {
      scope.reportError(new ReferenceError(`Unknown message: ${name}`));
      return new FluentNone(name);
    }
    if (attr2) {
      const attribute = message.attributes[attr2];
      if (attribute) {
        return resolvePattern(scope, attribute);
      }
      scope.reportError(new ReferenceError(`Unknown attribute: ${attr2}`));
      return new FluentNone(`${name}.${attr2}`);
    }
    if (message.value) {
      return resolvePattern(scope, message.value);
    }
    scope.reportError(new ReferenceError(`No value: ${name}`));
    return new FluentNone(name);
  }
  function resolveTermReference(scope, { name, attr: attr2, args }) {
    const id = `-${name}`;
    const term = scope.bundle._terms.get(id);
    if (!term) {
      scope.reportError(new ReferenceError(`Unknown term: ${id}`));
      return new FluentNone(id);
    }
    if (attr2) {
      const attribute = term.attributes[attr2];
      if (attribute) {
        scope.params = getArguments(scope, args).named;
        const resolved2 = resolvePattern(scope, attribute);
        scope.params = null;
        return resolved2;
      }
      scope.reportError(new ReferenceError(`Unknown attribute: ${attr2}`));
      return new FluentNone(`${id}.${attr2}`);
    }
    scope.params = getArguments(scope, args).named;
    const resolved = resolvePattern(scope, term.value);
    scope.params = null;
    return resolved;
  }
  function resolveFunctionReference(scope, { name, args }) {
    let func = scope.bundle._functions[name];
    if (!func) {
      scope.reportError(new ReferenceError(`Unknown function: ${name}()`));
      return new FluentNone(`${name}()`);
    }
    if (typeof func !== "function") {
      scope.reportError(new TypeError(`Function ${name}() is not callable`));
      return new FluentNone(`${name}()`);
    }
    try {
      let resolved = getArguments(scope, args);
      return func(resolved.positional, resolved.named);
    } catch (err) {
      scope.reportError(err);
      return new FluentNone(`${name}()`);
    }
  }
  function resolveSelectExpression(scope, { selector, variants, star }) {
    let sel = resolveExpression(scope, selector);
    if (sel instanceof FluentNone) {
      return getDefault(scope, variants, star);
    }
    for (const variant of variants) {
      const key2 = resolveExpression(scope, variant.key);
      if (match(scope, sel, key2)) {
        return resolvePattern(scope, variant.value);
      }
    }
    return getDefault(scope, variants, star);
  }
  function resolveComplexPattern(scope, ptn) {
    if (scope.dirty.has(ptn)) {
      scope.reportError(new RangeError("Cyclic reference"));
      return new FluentNone();
    }
    scope.dirty.add(ptn);
    const result = [];
    const useIsolating = scope.bundle._useIsolating && ptn.length > 1;
    for (const elem of ptn) {
      if (typeof elem === "string") {
        result.push(scope.bundle._transform(elem));
        continue;
      }
      scope.placeables++;
      if (scope.placeables > MAX_PLACEABLES) {
        scope.dirty.delete(ptn);
        throw new RangeError(`Too many placeables expanded: ${scope.placeables}, max allowed is ${MAX_PLACEABLES}`);
      }
      if (useIsolating) {
        result.push(FSI);
      }
      result.push(resolveExpression(scope, elem).toString(scope));
      if (useIsolating) {
        result.push(PDI);
      }
    }
    scope.dirty.delete(ptn);
    return result.join("");
  }
  function resolvePattern(scope, value) {
    if (typeof value === "string") {
      return scope.bundle._transform(value);
    }
    return resolveComplexPattern(scope, value);
  }

  // out/node_modules/@fluent/bundle/esm/scope.js
  var Scope = class {
    constructor(bundle, errors, args) {
      this.dirty = /* @__PURE__ */ new WeakSet();
      this.params = null;
      this.placeables = 0;
      this.bundle = bundle;
      this.errors = errors;
      this.args = args;
    }
    reportError(error) {
      if (!this.errors || !(error instanceof Error)) {
        throw error;
      }
      this.errors.push(error);
    }
    memoizeIntlObject(ctor, opts) {
      let cache2 = this.bundle._intls.get(ctor);
      if (!cache2) {
        cache2 = {};
        this.bundle._intls.set(ctor, cache2);
      }
      let id = JSON.stringify(opts);
      if (!cache2[id]) {
        cache2[id] = new ctor(this.bundle.locales, opts);
      }
      return cache2[id];
    }
  };

  // out/node_modules/@fluent/bundle/esm/builtins.js
  function values(opts, allowed) {
    const unwrapped = /* @__PURE__ */ Object.create(null);
    for (const [name, opt] of Object.entries(opts)) {
      if (allowed.includes(name)) {
        unwrapped[name] = opt.valueOf();
      }
    }
    return unwrapped;
  }
  var NUMBER_ALLOWED = [
    "unitDisplay",
    "currencyDisplay",
    "useGrouping",
    "minimumIntegerDigits",
    "minimumFractionDigits",
    "maximumFractionDigits",
    "minimumSignificantDigits",
    "maximumSignificantDigits"
  ];
  function NUMBER(args, opts) {
    let arg = args[0];
    if (arg instanceof FluentNone) {
      return new FluentNone(`NUMBER(${arg.valueOf()})`);
    }
    if (arg instanceof FluentNumber) {
      return new FluentNumber(arg.valueOf(), {
        ...arg.opts,
        ...values(opts, NUMBER_ALLOWED)
      });
    }
    if (arg instanceof FluentDateTime) {
      return new FluentNumber(arg.toNumber(), {
        ...values(opts, NUMBER_ALLOWED)
      });
    }
    throw new TypeError("Invalid argument to NUMBER");
  }
  var DATETIME_ALLOWED = [
    "dateStyle",
    "timeStyle",
    "fractionalSecondDigits",
    "dayPeriod",
    "hour12",
    "weekday",
    "era",
    "year",
    "month",
    "day",
    "hour",
    "minute",
    "second",
    "timeZoneName"
  ];
  function DATETIME(args, opts) {
    let arg = args[0];
    if (arg instanceof FluentNone) {
      return new FluentNone(`DATETIME(${arg.valueOf()})`);
    }
    if (arg instanceof FluentDateTime || arg instanceof FluentNumber) {
      return new FluentDateTime(arg, values(opts, DATETIME_ALLOWED));
    }
    throw new TypeError("Invalid argument to DATETIME");
  }

  // out/node_modules/@fluent/bundle/esm/memoizer.js
  var cache = /* @__PURE__ */ new Map();
  function getMemoizerForLocale(locales) {
    const stringLocale = Array.isArray(locales) ? locales.join(" ") : locales;
    let memoizer = cache.get(stringLocale);
    if (memoizer === void 0) {
      memoizer = /* @__PURE__ */ new Map();
      cache.set(stringLocale, memoizer);
    }
    return memoizer;
  }

  // out/node_modules/@fluent/bundle/esm/bundle.js
  var FluentBundle = class {
    /**
     * Create an instance of `FluentBundle`.
     *
     * @example
     * ```js
     * let bundle = new FluentBundle(["en-US", "en"]);
     *
     * let bundle = new FluentBundle(locales, {useIsolating: false});
     *
     * let bundle = new FluentBundle(locales, {
     *   useIsolating: true,
     *   functions: {
     *     NODE_ENV: () => process.env.NODE_ENV
     *   }
     * });
     * ```
     *
     * @param locales - Used to instantiate `Intl` formatters used by translations.
     * @param options - Optional configuration for the bundle.
     */
    constructor(locales, { functions, useIsolating = true, transform = (v) => v } = {}) {
      this._terms = /* @__PURE__ */ new Map();
      this._messages = /* @__PURE__ */ new Map();
      this.locales = Array.isArray(locales) ? locales : [locales];
      this._functions = {
        NUMBER,
        DATETIME,
        ...functions
      };
      this._useIsolating = useIsolating;
      this._transform = transform;
      this._intls = getMemoizerForLocale(locales);
    }
    /**
     * Check if a message is present in the bundle.
     *
     * @param id - The identifier of the message to check.
     */
    hasMessage(id) {
      return this._messages.has(id);
    }
    /**
     * Return a raw unformatted message object from the bundle.
     *
     * Raw messages are `{value, attributes}` shapes containing translation units
     * called `Patterns`. `Patterns` are implementation-specific; they should be
     * treated as black boxes and formatted with `FluentBundle.formatPattern`.
     *
     * @param id - The identifier of the message to check.
     */
    getMessage(id) {
      return this._messages.get(id);
    }
    /**
     * Add a translation resource to the bundle.
     *
     * @example
     * ```js
     * let res = new FluentResource("foo = Foo");
     * bundle.addResource(res);
     * bundle.getMessage("foo");
     * // → {value: .., attributes: {..}}
     * ```
     *
     * @param res
     * @param options
     */
    addResource(res, { allowOverrides = false } = {}) {
      const errors = [];
      for (let i = 0; i < res.body.length; i++) {
        let entry = res.body[i];
        if (entry.id.startsWith("-")) {
          if (allowOverrides === false && this._terms.has(entry.id)) {
            errors.push(new Error(`Attempt to override an existing term: "${entry.id}"`));
            continue;
          }
          this._terms.set(entry.id, entry);
        } else {
          if (allowOverrides === false && this._messages.has(entry.id)) {
            errors.push(new Error(`Attempt to override an existing message: "${entry.id}"`));
            continue;
          }
          this._messages.set(entry.id, entry);
        }
      }
      return errors;
    }
    /**
     * Format a `Pattern` to a string.
     *
     * Format a raw `Pattern` into a string. `args` will be used to resolve
     * references to variables passed as arguments to the translation.
     *
     * In case of errors `formatPattern` will try to salvage as much of the
     * translation as possible and will still return a string. For performance
     * reasons, the encountered errors are not returned but instead are appended
     * to the `errors` array passed as the third argument.
     *
     * If `errors` is omitted, the first encountered error will be thrown.
     *
     * @example
     * ```js
     * let errors = [];
     * bundle.addResource(
     *     new FluentResource("hello = Hello, {$name}!"));
     *
     * let hello = bundle.getMessage("hello");
     * if (hello.value) {
     *     bundle.formatPattern(hello.value, {name: "Jane"}, errors);
     *     // Returns "Hello, Jane!" and `errors` is empty.
     *
     *     bundle.formatPattern(hello.value, undefined, errors);
     *     // Returns "Hello, {$name}!" and `errors` is now:
     *     // [<ReferenceError: Unknown variable: name>]
     * }
     * ```
     */
    formatPattern(pattern, args = null, errors = null) {
      if (typeof pattern === "string") {
        return this._transform(pattern);
      }
      let scope = new Scope(this, errors, args);
      try {
        let value = resolveComplexPattern(scope, pattern);
        return value.toString(scope);
      } catch (err) {
        if (scope.errors && err instanceof Error) {
          scope.errors.push(err);
          return new FluentNone().toString(scope);
        }
        throw err;
      }
    }
  };

  // out/node_modules/@fluent/bundle/esm/resource.js
  var RE_MESSAGE_START = /^(-?[a-zA-Z][\w-]*) *= */gm;
  var RE_ATTRIBUTE_START = /\.([a-zA-Z][\w-]*) *= */y;
  var RE_VARIANT_START = /\*?\[/y;
  var RE_NUMBER_LITERAL = /(-?[0-9]+(?:\.([0-9]+))?)/y;
  var RE_IDENTIFIER = /([a-zA-Z][\w-]*)/y;
  var RE_REFERENCE = /([$-])?([a-zA-Z][\w-]*)(?:\.([a-zA-Z][\w-]*))?/y;
  var RE_FUNCTION_NAME = /^[A-Z][A-Z0-9_-]*$/;
  var RE_TEXT_RUN = /([^{}\n\r]+)/y;
  var RE_STRING_RUN = /([^\\"\n\r]*)/y;
  var RE_STRING_ESCAPE = /\\([\\"])/y;
  var RE_UNICODE_ESCAPE = /\\u([a-fA-F0-9]{4})|\\U([a-fA-F0-9]{6})/y;
  var RE_LEADING_NEWLINES = /^\n+/;
  var RE_TRAILING_SPACES = / +$/;
  var RE_BLANK_LINES = / *\r?\n/g;
  var RE_INDENT = /( *)$/;
  var TOKEN_BRACE_OPEN = /{\s*/y;
  var TOKEN_BRACE_CLOSE = /\s*}/y;
  var TOKEN_BRACKET_OPEN = /\[\s*/y;
  var TOKEN_BRACKET_CLOSE = /\s*] */y;
  var TOKEN_PAREN_OPEN = /\s*\(\s*/y;
  var TOKEN_ARROW = /\s*->\s*/y;
  var TOKEN_COLON = /\s*:\s*/y;
  var TOKEN_COMMA = /\s*,?\s*/y;
  var TOKEN_BLANK = /\s+/y;
  var FluentResource = class {
    constructor(source2) {
      this.body = [];
      RE_MESSAGE_START.lastIndex = 0;
      let cursor = 0;
      while (true) {
        let next2 = RE_MESSAGE_START.exec(source2);
        if (next2 === null) {
          break;
        }
        cursor = RE_MESSAGE_START.lastIndex;
        try {
          this.body.push(parseMessage(next2[1]));
        } catch (err) {
          if (err instanceof SyntaxError) {
            continue;
          }
          throw err;
        }
      }
      function test(re) {
        re.lastIndex = cursor;
        return re.test(source2);
      }
      function consumeChar(char, errorClass) {
        if (source2[cursor] === char) {
          cursor++;
          return true;
        }
        if (errorClass) {
          throw new errorClass(`Expected ${char}`);
        }
        return false;
      }
      function consumeToken(re, errorClass) {
        if (test(re)) {
          cursor = re.lastIndex;
          return true;
        }
        if (errorClass) {
          throw new errorClass(`Expected ${re.toString()}`);
        }
        return false;
      }
      function match2(re) {
        re.lastIndex = cursor;
        let result = re.exec(source2);
        if (result === null) {
          throw new SyntaxError(`Expected ${re.toString()}`);
        }
        cursor = re.lastIndex;
        return result;
      }
      function match1(re) {
        return match2(re)[1];
      }
      function parseMessage(id) {
        let value = parsePattern();
        let attributes = parseAttributes();
        if (value === null && Object.keys(attributes).length === 0) {
          throw new SyntaxError("Expected message value or attributes");
        }
        return { id, value, attributes };
      }
      function parseAttributes() {
        let attrs = /* @__PURE__ */ Object.create(null);
        while (test(RE_ATTRIBUTE_START)) {
          let name = match1(RE_ATTRIBUTE_START);
          let value = parsePattern();
          if (value === null) {
            throw new SyntaxError("Expected attribute value");
          }
          attrs[name] = value;
        }
        return attrs;
      }
      function parsePattern() {
        let first;
        if (test(RE_TEXT_RUN)) {
          first = match1(RE_TEXT_RUN);
        }
        if (source2[cursor] === "{" || source2[cursor] === "}") {
          return parsePatternElements(first ? [first] : [], Infinity);
        }
        let indent = parseIndent();
        if (indent) {
          if (first) {
            return parsePatternElements([first, indent], indent.length);
          }
          indent.value = trim(indent.value, RE_LEADING_NEWLINES);
          return parsePatternElements([indent], indent.length);
        }
        if (first) {
          return trim(first, RE_TRAILING_SPACES);
        }
        return null;
      }
      function parsePatternElements(elements = [], commonIndent) {
        while (true) {
          if (test(RE_TEXT_RUN)) {
            elements.push(match1(RE_TEXT_RUN));
            continue;
          }
          if (source2[cursor] === "{") {
            elements.push(parsePlaceable());
            continue;
          }
          if (source2[cursor] === "}") {
            throw new SyntaxError("Unbalanced closing brace");
          }
          let indent = parseIndent();
          if (indent) {
            elements.push(indent);
            commonIndent = Math.min(commonIndent, indent.length);
            continue;
          }
          break;
        }
        let lastIndex = elements.length - 1;
        let lastElement = elements[lastIndex];
        if (typeof lastElement === "string") {
          elements[lastIndex] = trim(lastElement, RE_TRAILING_SPACES);
        }
        let baked = [];
        for (let element2 of elements) {
          if (element2 instanceof Indent) {
            element2 = element2.value.slice(0, element2.value.length - commonIndent);
          }
          if (element2) {
            baked.push(element2);
          }
        }
        return baked;
      }
      function parsePlaceable() {
        consumeToken(TOKEN_BRACE_OPEN, SyntaxError);
        let selector = parseInlineExpression();
        if (consumeToken(TOKEN_BRACE_CLOSE)) {
          return selector;
        }
        if (consumeToken(TOKEN_ARROW)) {
          let variants = parseVariants();
          consumeToken(TOKEN_BRACE_CLOSE, SyntaxError);
          return {
            type: "select",
            selector,
            ...variants
          };
        }
        throw new SyntaxError("Unclosed placeable");
      }
      function parseInlineExpression() {
        if (source2[cursor] === "{") {
          return parsePlaceable();
        }
        if (test(RE_REFERENCE)) {
          let [, sigil, name, attr2 = null] = match2(RE_REFERENCE);
          if (sigil === "$") {
            return { type: "var", name };
          }
          if (consumeToken(TOKEN_PAREN_OPEN)) {
            let args = parseArguments();
            if (sigil === "-") {
              return { type: "term", name, attr: attr2, args };
            }
            if (RE_FUNCTION_NAME.test(name)) {
              return { type: "func", name, args };
            }
            throw new SyntaxError("Function names must be all upper-case");
          }
          if (sigil === "-") {
            return {
              type: "term",
              name,
              attr: attr2,
              args: []
            };
          }
          return { type: "mesg", name, attr: attr2 };
        }
        return parseLiteral();
      }
      function parseArguments() {
        let args = [];
        while (true) {
          switch (source2[cursor]) {
            case ")":
              cursor++;
              return args;
            case void 0:
              throw new SyntaxError("Unclosed argument list");
          }
          args.push(parseArgument());
          consumeToken(TOKEN_COMMA);
        }
      }
      function parseArgument() {
        let expr = parseInlineExpression();
        if (expr.type !== "mesg") {
          return expr;
        }
        if (consumeToken(TOKEN_COLON)) {
          return {
            type: "narg",
            name: expr.name,
            value: parseLiteral()
          };
        }
        return expr;
      }
      function parseVariants() {
        let variants = [];
        let count = 0;
        let star;
        while (test(RE_VARIANT_START)) {
          if (consumeChar("*")) {
            star = count;
          }
          let key2 = parseVariantKey();
          let value = parsePattern();
          if (value === null) {
            throw new SyntaxError("Expected variant value");
          }
          variants[count++] = { key: key2, value };
        }
        if (count === 0) {
          return null;
        }
        if (star === void 0) {
          throw new SyntaxError("Expected default variant");
        }
        return { variants, star };
      }
      function parseVariantKey() {
        consumeToken(TOKEN_BRACKET_OPEN, SyntaxError);
        let key2;
        if (test(RE_NUMBER_LITERAL)) {
          key2 = parseNumberLiteral();
        } else {
          key2 = {
            type: "str",
            value: match1(RE_IDENTIFIER)
          };
        }
        consumeToken(TOKEN_BRACKET_CLOSE, SyntaxError);
        return key2;
      }
      function parseLiteral() {
        if (test(RE_NUMBER_LITERAL)) {
          return parseNumberLiteral();
        }
        if (source2[cursor] === '"') {
          return parseStringLiteral();
        }
        throw new SyntaxError("Invalid expression");
      }
      function parseNumberLiteral() {
        let [, value, fraction = ""] = match2(RE_NUMBER_LITERAL);
        let precision = fraction.length;
        return {
          type: "num",
          value: parseFloat(value),
          precision
        };
      }
      function parseStringLiteral() {
        consumeChar('"', SyntaxError);
        let value = "";
        while (true) {
          value += match1(RE_STRING_RUN);
          if (source2[cursor] === "\\") {
            value += parseEscapeSequence();
            continue;
          }
          if (consumeChar('"')) {
            return { type: "str", value };
          }
          throw new SyntaxError("Unclosed string literal");
        }
      }
      function parseEscapeSequence() {
        if (test(RE_STRING_ESCAPE)) {
          return match1(RE_STRING_ESCAPE);
        }
        if (test(RE_UNICODE_ESCAPE)) {
          let [, codepoint4, codepoint6] = match2(RE_UNICODE_ESCAPE);
          let codepoint = parseInt(codepoint4 || codepoint6, 16);
          return codepoint <= 55295 || 57344 <= codepoint ? (
            // It's a Unicode scalar value.
            String.fromCodePoint(codepoint)
          ) : (
            // Lonely surrogates can cause trouble when the parsing result is
            // saved using UTF-8. Use U+FFFD REPLACEMENT CHARACTER instead.
            "\uFFFD"
          );
        }
        throw new SyntaxError("Unknown escape sequence");
      }
      function parseIndent() {
        let start = cursor;
        consumeToken(TOKEN_BLANK);
        switch (source2[cursor]) {
          case ".":
          case "[":
          case "*":
          case "}":
          case void 0:
            return false;
          case "{":
            return makeIndent(source2.slice(start, cursor));
        }
        if (source2[cursor - 1] === " ") {
          return makeIndent(source2.slice(start, cursor));
        }
        return false;
      }
      function trim(text2, re) {
        return text2.replace(re, "");
      }
      function makeIndent(blank) {
        let value = blank.replace(RE_BLANK_LINES, "\n");
        let length = RE_INDENT.exec(blank)[1].length;
        return new Indent(value, length);
      }
    }
  };
  var Indent = class {
    constructor(value, length) {
      this.value = value;
      this.length = length;
    }
  };

  // out/ts/lib/generated/ftl-helpers.ts
  var bundles = [];
  function setBundles(newBundles) {
    bundles = newBundles;
  }
  function firstLanguage() {
    return bundles[0].locales[0];
  }
  function translate(key2, args = {}) {
    var _a5;
    return (_a5 = getMessage(key2, args)) != null ? _a5 : `missing key: ${key2}`;
  }
  function toFluentNumber(num) {
    return new FluentNumber(num, {
      maximumFractionDigits: 2
    });
  }
  function formatArgs(args) {
    const entries = Object.entries(args).map(
      ([key2, value]) => {
        return [
          key2,
          typeof value === "number" ? toFluentNumber(value) : value
        ];
      }
    );
    const out = {};
    for (const [key2, value] of entries) {
      out[key2] = value;
    }
    return out;
  }
  function getMessage(key2, args = {}) {
    for (const bundle of bundles) {
      const msg = bundle.getMessage(key2);
      if (msg && msg.value) {
        const errors = [];
        const formatted = bundle.formatPattern(msg.value, formatArgs(args), errors);
        if (errors.length) {
          console.warn(
            `Found issues in translation string ${key2} with locales ${bundle.locales}:`
          );
          for (const error of errors) {
            console.error(error);
          }
        }
        return formatted;
      }
    }
    return null;
  }

  // out/ts/lib/generated/ftl.ts
  function schedulingBuriedCardsFound(args) {
    return translate("scheduling-buried-cards-found", args);
  }
  function schedulingCongratulationsFinished() {
    return translate("scheduling-congratulations-finished");
  }
  function schedulingCustomStudy() {
    return translate("scheduling-custom-study");
  }
  function schedulingHowToCustomStudy(args) {
    return translate("scheduling-how-to-custom-study", args);
  }
  function schedulingLearnRemaining(args) {
    return translate("scheduling-learn-remaining", args);
  }
  function schedulingNextLearnDue(args) {
    return translate("scheduling-next-learn-due", args);
  }
  function schedulingTodayNewLimitReached() {
    return translate("scheduling-today-new-limit-reached");
  }
  function schedulingTodayReviewLimitReached() {
    return translate("scheduling-today-review-limit-reached");
  }
  function schedulingUnburyThem() {
    return translate("scheduling-unbury-them");
  }

  // ts/lib/tslib/i18n/utils.ts
  var import_intl_pluralrules = __toESM(require_polyfill(), 1);
  function direction() {
    const firstLang = firstLanguage();
    if (["he", "ar", "fa", "ug", "yi"].some((lang) => firstLang.startsWith(lang))) {
      return "rtl";
    } else {
      return "ltr";
    }
  }
  var langs = [];
  async function setupI18n(args) {
    const resources = await i18nResources(args);
    const json = JSON.parse(new TextDecoder().decode(resources.json));
    const newBundles = [];
    for (const res in json.resources) {
      const text2 = json.resources[res];
      const lang = json.langs[res];
      const bundle = new FluentBundle([lang, "en-US"]);
      const resource = new FluentResource(text2);
      bundle.addResource(resource);
      newBundles.push(bundle);
    }
    setBundles(newBundles);
    langs = json.langs;
    document.dir = direction();
  }

  // ts/lib/tslib/nightmode.ts
  function checkNightMode() {
    const nightMode = window.location.hash == "#night";
    if (nightMode) {
      document.documentElement.className = "night-mode";
      document.documentElement.dataset.bsTheme = "dark";
    }
    return nightMode;
  }

  // node_modules/esm-env/dev-fallback.js
  var _a, _b;
  var node_env = (_b = (_a = globalThis.process) == null ? void 0 : _a.env) == null ? void 0 : _b.NODE_ENV;
  var dev_fallback_default = node_env && !node_env.toLowerCase().startsWith("prod");

  // node_modules/svelte/src/internal/shared/utils.js
  var is_array = Array.isArray;
  var index_of = Array.prototype.indexOf;
  var includes = Array.prototype.includes;
  var array_from = Array.from;
  var object_keys = Object.keys;
  var define_property = Object.defineProperty;
  var get_descriptor = Object.getOwnPropertyDescriptor;
  var get_descriptors = Object.getOwnPropertyDescriptors;
  var object_prototype = Object.prototype;
  var array_prototype = Array.prototype;
  var get_prototype_of = Object.getPrototypeOf;
  var is_extensible = Object.isExtensible;
  var noop = () => {
  };
  function run(fn) {
    return fn();
  }
  function run_all(arr) {
    for (var i = 0; i < arr.length; i++) {
      arr[i]();
    }
  }
  function deferred() {
    var resolve;
    var reject;
    var promise = new Promise((res, rej) => {
      resolve = res;
      reject = rej;
    });
    return { promise, resolve, reject };
  }

  // node_modules/svelte/src/internal/client/constants.js
  var DERIVED = 1 << 1;
  var EFFECT = 1 << 2;
  var RENDER_EFFECT = 1 << 3;
  var MANAGED_EFFECT = 1 << 24;
  var BLOCK_EFFECT = 1 << 4;
  var BRANCH_EFFECT = 1 << 5;
  var ROOT_EFFECT = 1 << 6;
  var BOUNDARY_EFFECT = 1 << 7;
  var CONNECTED = 1 << 9;
  var CLEAN = 1 << 10;
  var DIRTY = 1 << 11;
  var MAYBE_DIRTY = 1 << 12;
  var INERT = 1 << 13;
  var DESTROYED = 1 << 14;
  var REACTION_RAN = 1 << 15;
  var DESTROYING = 1 << 25;
  var EFFECT_TRANSPARENT = 1 << 16;
  var EAGER_EFFECT = 1 << 17;
  var HEAD_EFFECT = 1 << 18;
  var EFFECT_PRESERVED = 1 << 19;
  var USER_EFFECT = 1 << 20;
  var EFFECT_OFFSCREEN = 1 << 25;
  var WAS_MARKED = 1 << 16;
  var REACTION_IS_UPDATING = 1 << 21;
  var ASYNC = 1 << 22;
  var ERROR_VALUE = 1 << 23;
  var STATE_SYMBOL = /* @__PURE__ */ Symbol("$state");
  var LEGACY_PROPS = /* @__PURE__ */ Symbol("legacy props");
  var LOADING_ATTR_SYMBOL = /* @__PURE__ */ Symbol("");
  var PROXY_PATH_SYMBOL = /* @__PURE__ */ Symbol("proxy path");
  var ATTRIBUTES_CACHE = /* @__PURE__ */ Symbol("attributes");
  var CLASS_CACHE = /* @__PURE__ */ Symbol("class");
  var STYLE_CACHE = /* @__PURE__ */ Symbol("style");
  var TEXT_CACHE = /* @__PURE__ */ Symbol("text");
  var HMR_ANCHOR = /* @__PURE__ */ Symbol("hmr anchor");
  var STALE_REACTION = new class StaleReactionError extends Error {
    constructor() {
      super(...arguments);
      __publicField(this, "name", "StaleReactionError");
      __publicField(this, "message", "The reaction that called `getAbortSignal()` was re-run or destroyed");
    }
  }();
  var _a2;
  var IS_XHTML = (
    // We gotta write it like this because after downleveling the pure comment may end up in the wrong location
    !!((_a2 = globalThis.document) == null ? void 0 : _a2.contentType) && /* @__PURE__ */ globalThis.document.contentType.includes("xml")
  );
  var TEXT_NODE = 3;
  var COMMENT_NODE = 8;

  // node_modules/svelte/src/internal/shared/errors.js
  function invariant_violation(message) {
    if (dev_fallback_default) {
      const error = new Error(`invariant_violation
An invariant violation occurred, meaning Svelte's internal assumptions were flawed. This is a bug in Svelte, not your app \u2014 please open an issue at https://github.com/sveltejs/svelte, citing the following message: "${message}"
https://svelte.dev/e/invariant_violation`);
      error.name = "Svelte error";
      throw error;
    } else {
      throw new Error(`https://svelte.dev/e/invariant_violation`);
    }
  }
  function lifecycle_outside_component(name) {
    if (dev_fallback_default) {
      const error = new Error(`lifecycle_outside_component
\`${name}(...)\` can only be used during component initialisation
https://svelte.dev/e/lifecycle_outside_component`);
      error.name = "Svelte error";
      throw error;
    } else {
      throw new Error(`https://svelte.dev/e/lifecycle_outside_component`);
    }
  }

  // node_modules/svelte/src/internal/client/errors.js
  function async_derived_orphan() {
    if (dev_fallback_default) {
      const error = new Error(`async_derived_orphan
Cannot create a \`$derived(...)\` with an \`await\` expression outside of an effect tree
https://svelte.dev/e/async_derived_orphan`);
      error.name = "Svelte error";
      throw error;
    } else {
      throw new Error(`https://svelte.dev/e/async_derived_orphan`);
    }
  }
  function derived_references_self() {
    if (dev_fallback_default) {
      const error = new Error(`derived_references_self
A derived value cannot reference itself recursively
https://svelte.dev/e/derived_references_self`);
      error.name = "Svelte error";
      throw error;
    } else {
      throw new Error(`https://svelte.dev/e/derived_references_self`);
    }
  }
  function effect_in_teardown(rune) {
    if (dev_fallback_default) {
      const error = new Error(`effect_in_teardown
\`${rune}\` cannot be used inside an effect cleanup function
https://svelte.dev/e/effect_in_teardown`);
      error.name = "Svelte error";
      throw error;
    } else {
      throw new Error(`https://svelte.dev/e/effect_in_teardown`);
    }
  }
  function effect_in_unowned_derived() {
    if (dev_fallback_default) {
      const error = new Error(`effect_in_unowned_derived
Effect cannot be created inside a \`$derived\` value that was not itself created inside an effect
https://svelte.dev/e/effect_in_unowned_derived`);
      error.name = "Svelte error";
      throw error;
    } else {
      throw new Error(`https://svelte.dev/e/effect_in_unowned_derived`);
    }
  }
  function effect_orphan(rune) {
    if (dev_fallback_default) {
      const error = new Error(`effect_orphan
\`${rune}\` can only be used inside an effect (e.g. during component initialisation)
https://svelte.dev/e/effect_orphan`);
      error.name = "Svelte error";
      throw error;
    } else {
      throw new Error(`https://svelte.dev/e/effect_orphan`);
    }
  }
  function effect_update_depth_exceeded() {
    if (dev_fallback_default) {
      const error = new Error(`effect_update_depth_exceeded
Maximum update depth exceeded. This typically indicates that an effect reads and writes the same piece of state
https://svelte.dev/e/effect_update_depth_exceeded`);
      error.name = "Svelte error";
      throw error;
    } else {
      throw new Error(`https://svelte.dev/e/effect_update_depth_exceeded`);
    }
  }
  function hydration_failed() {
    if (dev_fallback_default) {
      const error = new Error(`hydration_failed
Failed to hydrate the application
https://svelte.dev/e/hydration_failed`);
      error.name = "Svelte error";
      throw error;
    } else {
      throw new Error(`https://svelte.dev/e/hydration_failed`);
    }
  }
  function props_invalid_value(key2) {
    if (dev_fallback_default) {
      const error = new Error(`props_invalid_value
Cannot do \`bind:${key2}={undefined}\` when \`${key2}\` has a fallback value
https://svelte.dev/e/props_invalid_value`);
      error.name = "Svelte error";
      throw error;
    } else {
      throw new Error(`https://svelte.dev/e/props_invalid_value`);
    }
  }
  function rune_outside_svelte(rune) {
    if (dev_fallback_default) {
      const error = new Error(`rune_outside_svelte
The \`${rune}\` rune is only available inside \`.svelte\` and \`.svelte.js/ts\` files
https://svelte.dev/e/rune_outside_svelte`);
      error.name = "Svelte error";
      throw error;
    } else {
      throw new Error(`https://svelte.dev/e/rune_outside_svelte`);
    }
  }
  function state_descriptors_fixed() {
    if (dev_fallback_default) {
      const error = new Error(`state_descriptors_fixed
Property descriptors defined on \`$state\` objects must contain \`value\` and always be \`enumerable\`, \`configurable\` and \`writable\`.
https://svelte.dev/e/state_descriptors_fixed`);
      error.name = "Svelte error";
      throw error;
    } else {
      throw new Error(`https://svelte.dev/e/state_descriptors_fixed`);
    }
  }
  function state_prototype_fixed() {
    if (dev_fallback_default) {
      const error = new Error(`state_prototype_fixed
Cannot set prototype of \`$state\` object
https://svelte.dev/e/state_prototype_fixed`);
      error.name = "Svelte error";
      throw error;
    } else {
      throw new Error(`https://svelte.dev/e/state_prototype_fixed`);
    }
  }
  function state_unsafe_mutation() {
    if (dev_fallback_default) {
      const error = new Error(`state_unsafe_mutation
Updating state inside \`$derived(...)\`, \`$inspect(...)\` or a template expression is forbidden. If the value should not be reactive, declare it without \`$state\`
https://svelte.dev/e/state_unsafe_mutation`);
      error.name = "Svelte error";
      throw error;
    } else {
      throw new Error(`https://svelte.dev/e/state_unsafe_mutation`);
    }
  }
  function svelte_boundary_reset_onerror() {
    if (dev_fallback_default) {
      const error = new Error(`svelte_boundary_reset_onerror
A \`<svelte:boundary>\` \`reset\` function cannot be called while an error is still being handled
https://svelte.dev/e/svelte_boundary_reset_onerror`);
      error.name = "Svelte error";
      throw error;
    } else {
      throw new Error(`https://svelte.dev/e/svelte_boundary_reset_onerror`);
    }
  }

  // node_modules/svelte/src/constants.js
  var EACH_INDEX_REACTIVE = 1 << 1;
  var EACH_IS_CONTROLLED = 1 << 2;
  var EACH_IS_ANIMATED = 1 << 3;
  var EACH_ITEM_IMMUTABLE = 1 << 4;
  var PROPS_IS_IMMUTABLE = 1;
  var PROPS_IS_RUNES = 1 << 1;
  var PROPS_IS_UPDATED = 1 << 2;
  var PROPS_IS_BINDABLE = 1 << 3;
  var PROPS_IS_LAZY_INITIAL = 1 << 4;
  var TRANSITION_OUT = 1 << 1;
  var TRANSITION_GLOBAL = 1 << 2;
  var TEMPLATE_FRAGMENT = 1;
  var TEMPLATE_USE_IMPORT_NODE = 1 << 1;
  var TEMPLATE_USE_SVG = 1 << 2;
  var TEMPLATE_USE_MATHML = 1 << 3;
  var HYDRATION_START = "[";
  var HYDRATION_START_ELSE = "[!";
  var HYDRATION_START_FAILED = "[?";
  var HYDRATION_END = "]";
  var HYDRATION_ERROR = {};
  var ELEMENT_PRESERVE_ATTRIBUTE_CASE = 1 << 1;
  var ELEMENT_IS_INPUT = 1 << 2;
  var UNINITIALIZED = /* @__PURE__ */ Symbol("uninitialized");
  var FILENAME = /* @__PURE__ */ Symbol("filename");
  var NAMESPACE_HTML = "http://www.w3.org/1999/xhtml";
  var NAMESPACE_SVG = "http://www.w3.org/2000/svg";
  var NAMESPACE_MATHML = "http://www.w3.org/1998/Math/MathML";

  // node_modules/svelte/src/internal/client/warnings.js
  var bold = "font-weight: bold";
  var normal = "font-weight: normal";
  function await_reactivity_loss(name) {
    if (dev_fallback_default) {
      console.warn(`%c[svelte] await_reactivity_loss
%cDetected reactivity loss when reading \`${name}\`. This happens when state is read in an async function after an earlier \`await\`
https://svelte.dev/e/await_reactivity_loss`, bold, normal);
    } else {
      console.warn(`https://svelte.dev/e/await_reactivity_loss`);
    }
  }
  function await_waterfall(name, location) {
    if (dev_fallback_default) {
      console.warn(`%c[svelte] await_waterfall
%cAn async derived, \`${name}\` (${location}) was not read immediately after it resolved. This often indicates an unnecessary waterfall, which can slow down your app
https://svelte.dev/e/await_waterfall`, bold, normal);
    } else {
      console.warn(`https://svelte.dev/e/await_waterfall`);
    }
  }
  function derived_inert() {
    if (dev_fallback_default) {
      console.warn(`%c[svelte] derived_inert
%cReading a derived belonging to a now-destroyed effect may result in stale values
https://svelte.dev/e/derived_inert`, bold, normal);
    } else {
      console.warn(`https://svelte.dev/e/derived_inert`);
    }
  }
  function hydration_attribute_changed(attribute, html2, value) {
    if (dev_fallback_default) {
      console.warn(`%c[svelte] hydration_attribute_changed
%cThe \`${attribute}\` attribute on \`${html2}\` changed its value between server and client renders. The client value, \`${value}\`, will be ignored in favour of the server value
https://svelte.dev/e/hydration_attribute_changed`, bold, normal);
    } else {
      console.warn(`https://svelte.dev/e/hydration_attribute_changed`);
    }
  }
  function hydration_html_changed(location) {
    if (dev_fallback_default) {
      console.warn(
        `%c[svelte] hydration_html_changed
%c${location ? `The value of an \`{@html ...}\` block ${location} changed between server and client renders. The client value will be ignored in favour of the server value` : "The value of an `{@html ...}` block changed between server and client renders. The client value will be ignored in favour of the server value"}
https://svelte.dev/e/hydration_html_changed`,
        bold,
        normal
      );
    } else {
      console.warn(`https://svelte.dev/e/hydration_html_changed`);
    }
  }
  function hydration_mismatch(location) {
    if (dev_fallback_default) {
      console.warn(
        `%c[svelte] hydration_mismatch
%c${location ? `Hydration failed because the initial UI does not match what was rendered on the server. The error occurred near ${location}` : "Hydration failed because the initial UI does not match what was rendered on the server"}
https://svelte.dev/e/hydration_mismatch`,
        bold,
        normal
      );
    } else {
      console.warn(`https://svelte.dev/e/hydration_mismatch`);
    }
  }
  function lifecycle_double_unmount() {
    if (dev_fallback_default) {
      console.warn(`%c[svelte] lifecycle_double_unmount
%cTried to unmount a component that was not mounted
https://svelte.dev/e/lifecycle_double_unmount`, bold, normal);
    } else {
      console.warn(`https://svelte.dev/e/lifecycle_double_unmount`);
    }
  }
  function state_proxy_equality_mismatch(operator) {
    if (dev_fallback_default) {
      console.warn(`%c[svelte] state_proxy_equality_mismatch
%cReactive \`$state(...)\` proxies and the values they proxy have different identities. Because of this, comparisons with \`${operator}\` will produce unexpected results
https://svelte.dev/e/state_proxy_equality_mismatch`, bold, normal);
    } else {
      console.warn(`https://svelte.dev/e/state_proxy_equality_mismatch`);
    }
  }
  function state_proxy_unmount() {
    if (dev_fallback_default) {
      console.warn(`%c[svelte] state_proxy_unmount
%cTried to unmount a state proxy, rather than a component
https://svelte.dev/e/state_proxy_unmount`, bold, normal);
    } else {
      console.warn(`https://svelte.dev/e/state_proxy_unmount`);
    }
  }
  function svelte_boundary_reset_noop() {
    if (dev_fallback_default) {
      console.warn(`%c[svelte] svelte_boundary_reset_noop
%cA \`<svelte:boundary>\` \`reset\` function only resets the boundary the first time it is called
https://svelte.dev/e/svelte_boundary_reset_noop`, bold, normal);
    } else {
      console.warn(`https://svelte.dev/e/svelte_boundary_reset_noop`);
    }
  }

  // node_modules/svelte/src/internal/client/dom/hydration.js
  var hydrating = false;
  function set_hydrating(value) {
    hydrating = value;
  }
  var hydrate_node;
  function set_hydrate_node(node) {
    if (node === null) {
      hydration_mismatch();
      throw HYDRATION_ERROR;
    }
    return hydrate_node = node;
  }
  function hydrate_next() {
    return set_hydrate_node(get_next_sibling(hydrate_node));
  }
  function reset(node) {
    if (!hydrating) return;
    if (get_next_sibling(hydrate_node) !== null) {
      hydration_mismatch();
      throw HYDRATION_ERROR;
    }
    hydrate_node = node;
  }
  function next(count = 1) {
    if (hydrating) {
      var i = count;
      var node = hydrate_node;
      while (i--) {
        node = /** @type {TemplateNode} */
        get_next_sibling(node);
      }
      hydrate_node = node;
    }
  }
  function skip_nodes(remove = true) {
    var depth = 0;
    var node = hydrate_node;
    while (true) {
      if (node.nodeType === COMMENT_NODE) {
        var data = (
          /** @type {Comment} */
          node.data
        );
        if (data === HYDRATION_END) {
          if (depth === 0) return node;
          depth -= 1;
        } else if (data === HYDRATION_START || data === HYDRATION_START_ELSE || // "[1", "[2", etc. for if blocks
        data[0] === "[" && !isNaN(Number(data.slice(1)))) {
          depth += 1;
        }
      }
      var next2 = (
        /** @type {TemplateNode} */
        get_next_sibling(node)
      );
      if (remove) node.remove();
      node = next2;
    }
  }
  function read_hydration_instruction(node) {
    if (!node || node.nodeType !== COMMENT_NODE) {
      hydration_mismatch();
      throw HYDRATION_ERROR;
    }
    return (
      /** @type {Comment} */
      node.data
    );
  }

  // node_modules/svelte/src/internal/client/reactivity/equality.js
  function equals(value) {
    return value === this.v;
  }
  function safe_not_equal(a, b) {
    return a != a ? b == b : a !== b || a !== null && typeof a === "object" || typeof a === "function";
  }
  function safe_equals(value) {
    return !safe_not_equal(value, this.v);
  }

  // node_modules/svelte/src/internal/flags/index.js
  var async_mode_flag = false;
  var legacy_mode_flag = false;
  var tracing_mode_flag = false;
  function enable_legacy_mode_flag() {
    legacy_mode_flag = true;
  }

  // node_modules/svelte/src/internal/client/dev/tracing.js
  var tracing_expressions = null;
  function tag(source2, label) {
    source2.label = label;
    tag_proxy(source2.v, label);
    return source2;
  }
  function tag_proxy(value, label) {
    var _a5;
    (_a5 = value == null ? void 0 : value[PROXY_PATH_SYMBOL]) == null ? void 0 : _a5.call(value, label);
    return value;
  }

  // node_modules/svelte/src/internal/shared/dev.js
  function get_error(label) {
    const error = new Error();
    const stack2 = get_stack();
    if (stack2.length === 0) {
      return null;
    }
    stack2.unshift("\n");
    define_property(error, "stack", {
      value: stack2.join("\n")
    });
    define_property(error, "name", {
      value: label
    });
    return (
      /** @type {Error & { stack: string }} */
      error
    );
  }
  function get_stack() {
    const limit = Error.stackTraceLimit;
    Error.stackTraceLimit = Infinity;
    const stack2 = new Error().stack;
    Error.stackTraceLimit = limit;
    if (!stack2) return [];
    const lines = stack2.split("\n");
    const new_lines = [];
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      const posixified = line.replaceAll("\\", "/");
      if (line.trim() === "Error") {
        continue;
      }
      if (line.includes("validate_each_keys")) {
        return [];
      }
      if (posixified.includes("svelte/src/internal") || posixified.includes("node_modules/.vite")) {
        continue;
      }
      new_lines.push(line);
    }
    return new_lines;
  }
  function invariant(condition, message) {
    if (!dev_fallback_default) {
      throw new Error("invariant(...) was not guarded by if (DEV)");
    }
    if (!condition) invariant_violation(message);
  }

  // node_modules/svelte/src/internal/client/context.js
  var component_context = null;
  function set_component_context(context) {
    component_context = context;
  }
  var dev_stack = null;
  function set_dev_stack(stack2) {
    dev_stack = stack2;
  }
  var dev_current_component_function = null;
  function set_dev_current_component_function(fn) {
    dev_current_component_function = fn;
  }
  function push(props, runes = false, fn) {
    component_context = {
      p: component_context,
      i: false,
      c: null,
      e: null,
      s: props,
      x: null,
      r: (
        /** @type {Effect} */
        active_effect
      ),
      l: legacy_mode_flag && !runes ? { s: null, u: null, $: [] } : null
    };
    if (dev_fallback_default) {
      component_context.function = fn;
      dev_current_component_function = fn;
    }
  }
  function pop(component2) {
    var _a5;
    var context = (
      /** @type {ComponentContext} */
      component_context
    );
    var effects = context.e;
    if (effects !== null) {
      context.e = null;
      for (var fn of effects) {
        create_user_effect(fn);
      }
    }
    if (component2 !== void 0) {
      context.x = component2;
    }
    context.i = true;
    component_context = context.p;
    if (dev_fallback_default) {
      dev_current_component_function = (_a5 = component_context == null ? void 0 : component_context.function) != null ? _a5 : null;
    }
    return component2 != null ? component2 : (
      /** @type {T} */
      {}
    );
  }
  function is_runes() {
    return !legacy_mode_flag || component_context !== null && component_context.l === null;
  }

  // node_modules/svelte/src/internal/client/dom/task.js
  var micro_tasks = [];
  function run_micro_tasks() {
    var tasks = micro_tasks;
    micro_tasks = [];
    run_all(tasks);
  }
  function queue_micro_task(fn) {
    if (micro_tasks.length === 0 && !is_flushing_sync) {
      var tasks = micro_tasks;
      queueMicrotask(() => {
        if (tasks === micro_tasks) run_micro_tasks();
      });
    }
    micro_tasks.push(fn);
  }
  function flush_tasks() {
    while (micro_tasks.length > 0) {
      run_micro_tasks();
    }
  }

  // node_modules/svelte/src/internal/client/error-handling.js
  var adjustments = /* @__PURE__ */ new WeakMap();
  function handle_error(error) {
    var effect2 = active_effect;
    if (effect2 === null) {
      active_reaction.f |= ERROR_VALUE;
      return error;
    }
    if (dev_fallback_default && error instanceof Error && !adjustments.has(error)) {
      adjustments.set(error, get_adjustments(error, effect2));
    }
    if ((effect2.f & REACTION_RAN) === 0 && (effect2.f & EFFECT) === 0) {
      if (dev_fallback_default && !effect2.parent && error instanceof Error) {
        apply_adjustments(error);
      }
      throw error;
    }
    invoke_error_boundary(error, effect2);
  }
  function invoke_error_boundary(error, effect2) {
    if (effect2 !== null && (effect2.f & DESTROYED) !== 0) {
      return;
    }
    while (effect2 !== null) {
      if ((effect2.f & BOUNDARY_EFFECT) !== 0) {
        if ((effect2.f & REACTION_RAN) === 0) {
          throw error;
        }
        try {
          effect2.b.error(error);
          return;
        } catch (e) {
          error = e;
        }
      }
      effect2 = effect2.parent;
    }
    if (dev_fallback_default && error instanceof Error) {
      apply_adjustments(error);
    }
    throw error;
  }
  function get_adjustments(error, effect2) {
    var _a5, _b3, _c2;
    const message_descriptor = get_descriptor(error, "message");
    if (message_descriptor && !message_descriptor.configurable) return;
    var indent = is_firefox ? "  " : "	";
    var component_stack = `
${indent}in ${((_a5 = effect2.fn) == null ? void 0 : _a5.name) || "<unknown>"}`;
    var context = effect2.ctx;
    while (context !== null) {
      component_stack += `
${indent}in ${(_b3 = context.function) == null ? void 0 : _b3[FILENAME].split("/").pop()}`;
      context = context.p;
    }
    return {
      message: error.message + `
${component_stack}
`,
      stack: (_c2 = error.stack) == null ? void 0 : _c2.split("\n").filter((line) => !line.includes("svelte/src/internal")).join("\n")
    };
  }
  function apply_adjustments(error) {
    const adjusted = adjustments.get(error);
    if (adjusted) {
      define_property(error, "message", {
        value: adjusted.message
      });
      define_property(error, "stack", {
        value: adjusted.stack
      });
    }
  }

  // node_modules/svelte/src/internal/client/reactivity/status.js
  var STATUS_MASK = ~(DIRTY | MAYBE_DIRTY | CLEAN);
  function set_signal_status(signal, status) {
    signal.f = signal.f & STATUS_MASK | status;
  }
  function update_derived_status(derived2) {
    if ((derived2.f & CONNECTED) !== 0 || derived2.deps === null) {
      set_signal_status(derived2, CLEAN);
    } else {
      set_signal_status(derived2, MAYBE_DIRTY);
    }
  }

  // node_modules/svelte/src/internal/client/reactivity/utils.js
  function clear_marked(deps) {
    if (deps === null) return;
    for (const dep of deps) {
      if ((dep.f & DERIVED) === 0 || (dep.f & WAS_MARKED) === 0) {
        continue;
      }
      dep.f ^= WAS_MARKED;
      clear_marked(
        /** @type {Derived} */
        dep.deps
      );
    }
  }
  function defer_effect(effect2, dirty_effects, maybe_dirty_effects) {
    if ((effect2.f & DIRTY) !== 0) {
      dirty_effects.add(effect2);
    } else if ((effect2.f & MAYBE_DIRTY) !== 0) {
      maybe_dirty_effects.add(effect2);
    }
    clear_marked(effect2.deps);
    set_signal_status(effect2, CLEAN);
  }

  // node_modules/svelte/src/internal/client/reactivity/store.js
  var legacy_is_updating_store = false;
  var is_store_binding = false;
  function capture_store_binding(fn) {
    var previous_is_store_binding = is_store_binding;
    try {
      is_store_binding = false;
      return [fn(), is_store_binding];
    } finally {
      is_store_binding = previous_is_store_binding;
    }
  }

  // node_modules/svelte/src/internal/client/dom/elements/bindings/shared.js
  function without_reactive_context(fn) {
    var previous_reaction = active_reaction;
    var previous_effect = active_effect;
    set_active_reaction(null);
    set_active_effect(null);
    try {
      return fn();
    } finally {
      set_active_reaction(previous_reaction);
      set_active_effect(previous_effect);
    }
  }

  // node_modules/svelte/src/reactivity/create-subscriber.js
  function createSubscriber(start) {
    let subscribers = 0;
    let version = source(0);
    let stop;
    if (dev_fallback_default) {
      tag(version, "createSubscriber version");
    }
    return () => {
      if (effect_tracking()) {
        get2(version);
        render_effect(() => {
          if (subscribers === 0) {
            stop = untrack(() => start(() => increment(version)));
          }
          subscribers += 1;
          return () => {
            queue_micro_task(() => {
              subscribers -= 1;
              if (subscribers === 0) {
                stop == null ? void 0 : stop();
                stop = void 0;
                increment(version);
              }
            });
          };
        });
      }
    };
  }

  // node_modules/svelte/src/internal/client/dom/blocks/boundary.js
  var flags = EFFECT_TRANSPARENT | EFFECT_PRESERVED;
  function boundary(node, props, children, transform_error) {
    new Boundary(node, props, children, transform_error);
  }
  var _anchor, _hydrate_open, _props, _children, _effect, _main_effect, _pending_effect, _failed_effect, _offscreen_fragment, _local_pending_count, _pending_count, _pending_count_update_queued, _dirty_effects, _maybe_dirty_effects, _effect_pending, _effect_pending_subscriber, _Boundary_instances, hydrate_resolved_content_fn, hydrate_failed_content_fn, create_reset_fn, hydrate_pending_content_fn, render_fn, resolve_fn, run_fn, update_pending_count_fn, handle_error_fn;
  var Boundary = class {
    /**
     * @param {TemplateNode} node
     * @param {BoundaryProps} props
     * @param {((anchor: Node) => void)} children
     * @param {((error: unknown) => unknown) | undefined} [transform_error]
     */
    constructor(node, props, children, transform_error) {
      __privateAdd(this, _Boundary_instances);
      /** @type {Boundary | null} */
      __publicField(this, "parent");
      __publicField(this, "is_pending", false);
      /**
       * API-level transformError transform function. Transforms errors before they reach the `failed` snippet.
       * Inherited from parent boundary, or defaults to identity.
       * @type {(error: unknown) => unknown}
       */
      __publicField(this, "transform_error");
      /** @type {TemplateNode} */
      __privateAdd(this, _anchor);
      /** @type {TemplateNode | null} */
      __privateAdd(this, _hydrate_open, hydrating ? hydrate_node : null);
      /** @type {BoundaryProps} */
      __privateAdd(this, _props);
      /** @type {((anchor: Node) => void)} */
      __privateAdd(this, _children);
      /** @type {Effect} */
      __privateAdd(this, _effect);
      /** @type {Effect | null} */
      __privateAdd(this, _main_effect, null);
      /** @type {Effect | null} */
      __privateAdd(this, _pending_effect, null);
      /** @type {Effect | null} */
      __privateAdd(this, _failed_effect, null);
      /** @type {DocumentFragment | null} */
      __privateAdd(this, _offscreen_fragment, null);
      __privateAdd(this, _local_pending_count, 0);
      __privateAdd(this, _pending_count, 0);
      __privateAdd(this, _pending_count_update_queued, false);
      /** @type {Set<Effect>} */
      __privateAdd(this, _dirty_effects, /* @__PURE__ */ new Set());
      /** @type {Set<Effect>} */
      __privateAdd(this, _maybe_dirty_effects, /* @__PURE__ */ new Set());
      /**
       * A source containing the number of pending async deriveds/expressions.
       * Only created if `$effect.pending()` is used inside the boundary,
       * otherwise updating the source results in needless `Batch.ensure()`
       * calls followed by no-op flushes
       * @type {Source<number> | null}
       */
      __privateAdd(this, _effect_pending, null);
      __privateAdd(this, _effect_pending_subscriber, createSubscriber(() => {
        __privateSet(this, _effect_pending, source(__privateGet(this, _local_pending_count)));
        if (dev_fallback_default) {
          tag(__privateGet(this, _effect_pending), "$effect.pending()");
        }
        return () => {
          __privateSet(this, _effect_pending, null);
        };
      }));
      var _a5, _b3;
      __privateSet(this, _anchor, node);
      __privateSet(this, _props, props);
      __privateSet(this, _children, (anchor) => {
        var effect2 = (
          /** @type {Effect} */
          active_effect
        );
        effect2.b = this;
        effect2.f |= BOUNDARY_EFFECT;
        children(anchor);
      });
      this.parent = /** @type {Effect} */
      active_effect.b;
      this.transform_error = (_b3 = transform_error != null ? transform_error : (_a5 = this.parent) == null ? void 0 : _a5.transform_error) != null ? _b3 : ((e) => e);
      __privateSet(this, _effect, block(() => {
        if (hydrating) {
          const comment2 = (
            /** @type {Comment} */
            __privateGet(this, _hydrate_open)
          );
          hydrate_next();
          const server_rendered_pending = comment2.data === HYDRATION_START_ELSE;
          const server_rendered_failed = comment2.data.startsWith(HYDRATION_START_FAILED);
          if (server_rendered_failed) {
            const serialized_error = JSON.parse(comment2.data.slice(HYDRATION_START_FAILED.length));
            __privateMethod(this, _Boundary_instances, hydrate_failed_content_fn).call(this, serialized_error);
          } else if (server_rendered_pending) {
            __privateMethod(this, _Boundary_instances, hydrate_pending_content_fn).call(this);
          } else {
            __privateMethod(this, _Boundary_instances, hydrate_resolved_content_fn).call(this);
          }
        } else {
          __privateMethod(this, _Boundary_instances, render_fn).call(this);
        }
      }, flags));
      if (hydrating) {
        __privateSet(this, _anchor, hydrate_node);
      }
    }
    /**
     * Defer an effect inside a pending boundary until the boundary resolves
     * @param {Effect} effect
     */
    defer_effect(effect2) {
      defer_effect(effect2, __privateGet(this, _dirty_effects), __privateGet(this, _maybe_dirty_effects));
    }
    /**
     * Returns `false` if the effect exists inside a boundary whose pending snippet is shown
     * @returns {boolean}
     */
    is_rendered() {
      return !this.is_pending && (!this.parent || this.parent.is_rendered());
    }
    has_pending_snippet() {
      return !!__privateGet(this, _props).pending;
    }
    /**
     * Update the source that powers `$effect.pending()` inside this boundary,
     * and controls when the current `pending` snippet (if any) is removed.
     * Do not call from inside the class
     * @param {1 | -1} d
     * @param {Batch} batch
     */
    update_pending_count(d, batch) {
      __privateMethod(this, _Boundary_instances, update_pending_count_fn).call(this, d, batch);
      __privateSet(this, _local_pending_count, __privateGet(this, _local_pending_count) + d);
      if (!__privateGet(this, _effect_pending) || __privateGet(this, _pending_count_update_queued)) return;
      __privateSet(this, _pending_count_update_queued, true);
      queue_micro_task(() => {
        __privateSet(this, _pending_count_update_queued, false);
        if (__privateGet(this, _effect_pending)) {
          internal_set(__privateGet(this, _effect_pending), __privateGet(this, _local_pending_count));
        }
      });
    }
    get_effect_pending() {
      __privateGet(this, _effect_pending_subscriber).call(this);
      return get2(
        /** @type {Source<number>} */
        __privateGet(this, _effect_pending)
      );
    }
    /** @param {unknown} error */
    error(error) {
      var _a5;
      if (!__privateGet(this, _props).onerror && !__privateGet(this, _props).failed) {
        throw error;
      }
      if ((_a5 = current_batch) == null ? void 0 : _a5.is_fork) {
        if (__privateGet(this, _main_effect)) current_batch.skip_effect(__privateGet(this, _main_effect));
        if (__privateGet(this, _pending_effect)) current_batch.skip_effect(__privateGet(this, _pending_effect));
        if (__privateGet(this, _failed_effect)) current_batch.skip_effect(__privateGet(this, _failed_effect));
        current_batch.oncommit(() => {
          __privateMethod(this, _Boundary_instances, handle_error_fn).call(this, error);
        });
      } else {
        __privateMethod(this, _Boundary_instances, handle_error_fn).call(this, error);
      }
    }
  };
  _anchor = new WeakMap();
  _hydrate_open = new WeakMap();
  _props = new WeakMap();
  _children = new WeakMap();
  _effect = new WeakMap();
  _main_effect = new WeakMap();
  _pending_effect = new WeakMap();
  _failed_effect = new WeakMap();
  _offscreen_fragment = new WeakMap();
  _local_pending_count = new WeakMap();
  _pending_count = new WeakMap();
  _pending_count_update_queued = new WeakMap();
  _dirty_effects = new WeakMap();
  _maybe_dirty_effects = new WeakMap();
  _effect_pending = new WeakMap();
  _effect_pending_subscriber = new WeakMap();
  _Boundary_instances = new WeakSet();
  hydrate_resolved_content_fn = function() {
    try {
      __privateSet(this, _main_effect, branch(() => __privateGet(this, _children).call(this, __privateGet(this, _anchor))));
    } catch (error) {
      this.error(error);
    }
  };
  /**
   * @param {unknown} error The deserialized error from the server's hydration comment
   */
  hydrate_failed_content_fn = function(error) {
    const failed = __privateGet(this, _props).failed;
    const { reset: reset2, invoke_onerror } = __privateMethod(this, _Boundary_instances, create_reset_fn).call(this, error);
    queue_micro_task(invoke_onerror);
    if (!failed) return;
    __privateSet(this, _failed_effect, branch(() => {
      failed(
        __privateGet(this, _anchor),
        () => error,
        () => reset2
      );
    }));
  };
  /**
   * Creates the `reset` function for a failed boundary, along with a function
   * that invokes `onerror` with it (if provided)
   * @param {unknown} error
   * @returns {{ reset: () => void, invoke_onerror: () => void }}
   */
  create_reset_fn = function(error) {
    var did_reset = false;
    var calling_on_error = false;
    const reset2 = () => {
      if (did_reset) {
        svelte_boundary_reset_noop();
        return;
      }
      did_reset = true;
      if (calling_on_error) {
        svelte_boundary_reset_onerror();
      }
      if (__privateGet(this, _failed_effect) !== null) {
        pause_effect(__privateGet(this, _failed_effect), () => {
          __privateSet(this, _failed_effect, null);
        });
      }
      __privateMethod(this, _Boundary_instances, run_fn).call(this, () => {
        __privateMethod(this, _Boundary_instances, render_fn).call(this);
      });
    };
    const invoke_onerror = () => {
      var _a5, _b3;
      try {
        calling_on_error = true;
        (_b3 = (_a5 = __privateGet(this, _props)).onerror) == null ? void 0 : _b3.call(_a5, error, reset2);
        calling_on_error = false;
      } catch (err) {
        invoke_error_boundary(err, __privateGet(this, _effect) && __privateGet(this, _effect).parent);
      }
    };
    return { reset: reset2, invoke_onerror };
  };
  hydrate_pending_content_fn = function() {
    const pending2 = __privateGet(this, _props).pending;
    if (!pending2) return;
    this.is_pending = true;
    __privateSet(this, _pending_effect, branch(() => pending2(__privateGet(this, _anchor))));
    queue_micro_task(() => {
      var fragment = __privateSet(this, _offscreen_fragment, document.createDocumentFragment());
      var anchor = create_text();
      fragment.append(anchor);
      __privateSet(this, _main_effect, __privateMethod(this, _Boundary_instances, run_fn).call(this, () => {
        return branch(() => __privateGet(this, _children).call(this, anchor));
      }));
      if (__privateGet(this, _pending_count) === 0) {
        __privateGet(this, _anchor).before(fragment);
        __privateSet(this, _offscreen_fragment, null);
        pause_effect(
          /** @type {Effect} */
          __privateGet(this, _pending_effect),
          () => {
            __privateSet(this, _pending_effect, null);
          }
        );
        __privateMethod(this, _Boundary_instances, resolve_fn).call(
          this,
          /** @type {Batch} */
          current_batch
        );
      }
    });
  };
  render_fn = function() {
    try {
      this.is_pending = this.has_pending_snippet();
      __privateSet(this, _pending_count, 0);
      __privateSet(this, _local_pending_count, 0);
      __privateSet(this, _main_effect, branch(() => {
        __privateGet(this, _children).call(this, __privateGet(this, _anchor));
      }));
      if (__privateGet(this, _pending_count) > 0) {
        var fragment = __privateSet(this, _offscreen_fragment, document.createDocumentFragment());
        move_effect(__privateGet(this, _main_effect), fragment);
        const pending2 = (
          /** @type {(anchor: Node) => void} */
          __privateGet(this, _props).pending
        );
        __privateSet(this, _pending_effect, branch(() => pending2(__privateGet(this, _anchor))));
      } else {
        __privateMethod(this, _Boundary_instances, resolve_fn).call(
          this,
          /** @type {Batch} */
          current_batch
        );
      }
    } catch (error) {
      this.error(error);
    }
  };
  /**
   * @param {Batch} batch
   */
  resolve_fn = function(batch) {
    this.is_pending = false;
    batch.transfer_effects(__privateGet(this, _dirty_effects), __privateGet(this, _maybe_dirty_effects));
  };
  /**
   * @template T
   * @param {() => T} fn
   */
  run_fn = function(fn) {
    var previous_effect = active_effect;
    var previous_reaction = active_reaction;
    var previous_ctx = component_context;
    set_active_effect(__privateGet(this, _effect));
    set_active_reaction(__privateGet(this, _effect));
    set_component_context(__privateGet(this, _effect).ctx);
    try {
      Batch.ensure();
      return fn();
    } catch (e) {
      handle_error(e);
      return null;
    } finally {
      set_active_effect(previous_effect);
      set_active_reaction(previous_reaction);
      set_component_context(previous_ctx);
    }
  };
  /**
   * Updates the pending count associated with the currently visible pending snippet,
   * if any, such that we can replace the snippet with content once work is done
   * @param {1 | -1} d
   * @param {Batch} batch
   */
  update_pending_count_fn = function(d, batch) {
    var _a5;
    if (!this.has_pending_snippet()) {
      if (this.parent) {
        __privateMethod(_a5 = this.parent, _Boundary_instances, update_pending_count_fn).call(_a5, d, batch);
      }
      return;
    }
    __privateSet(this, _pending_count, __privateGet(this, _pending_count) + d);
    if (__privateGet(this, _pending_count) === 0) {
      __privateMethod(this, _Boundary_instances, resolve_fn).call(this, batch);
      if (__privateGet(this, _pending_effect)) {
        pause_effect(__privateGet(this, _pending_effect), () => {
          __privateSet(this, _pending_effect, null);
        });
      }
      if (__privateGet(this, _offscreen_fragment)) {
        __privateGet(this, _anchor).before(__privateGet(this, _offscreen_fragment));
        __privateSet(this, _offscreen_fragment, null);
      }
    }
  };
  /**
   * @param {unknown} error
   */
  handle_error_fn = function(error) {
    if (__privateGet(this, _main_effect)) {
      destroy_effect(__privateGet(this, _main_effect));
      __privateSet(this, _main_effect, null);
    }
    if (__privateGet(this, _pending_effect)) {
      destroy_effect(__privateGet(this, _pending_effect));
      __privateSet(this, _pending_effect, null);
    }
    if (__privateGet(this, _failed_effect)) {
      destroy_effect(__privateGet(this, _failed_effect));
      __privateSet(this, _failed_effect, null);
    }
    if (hydrating) {
      set_hydrate_node(
        /** @type {TemplateNode} */
        __privateGet(this, _hydrate_open)
      );
      next();
      set_hydrate_node(skip_nodes());
    }
    let failed = __privateGet(this, _props).failed;
    const handle_error_result = (transformed_error) => {
      const { reset: reset2, invoke_onerror } = __privateMethod(this, _Boundary_instances, create_reset_fn).call(this, transformed_error);
      invoke_onerror();
      if (failed) {
        __privateSet(this, _failed_effect, __privateMethod(this, _Boundary_instances, run_fn).call(this, () => {
          try {
            return branch(() => {
              var effect2 = (
                /** @type {Effect} */
                active_effect
              );
              effect2.b = this;
              effect2.f |= BOUNDARY_EFFECT;
              failed(
                __privateGet(this, _anchor),
                () => transformed_error,
                () => reset2
              );
            });
          } catch (error2) {
            invoke_error_boundary(
              error2,
              /** @type {Effect} */
              __privateGet(this, _effect).parent
            );
            return null;
          }
        }));
      }
    };
    queue_micro_task(() => {
      var result;
      try {
        result = this.transform_error(error);
      } catch (e) {
        invoke_error_boundary(e, __privateGet(this, _effect) && __privateGet(this, _effect).parent);
        return;
      }
      if (result !== null && typeof result === "object" && typeof /** @type {any} */
      result.then === "function") {
        result.then(
          handle_error_result,
          /** @param {unknown} e */
          (e) => invoke_error_boundary(e, __privateGet(this, _effect) && __privateGet(this, _effect).parent)
        );
      } else {
        handle_error_result(result);
      }
    });
  };

  // node_modules/svelte/src/internal/client/reactivity/async.js
  function flatten(blockers, sync, async2, fn) {
    const d = is_runes() ? derived : derived_safe_equal;
    var pending2 = blockers.filter((b) => !b.settled);
    var deriveds = sync.map(d);
    if (dev_fallback_default) {
      deriveds.forEach((d2, i) => {
        d2.label = sync[i].toString().replace("() => ", "").replaceAll("$.eager(() => ", "$state.eager(").replace(/\$\.get\((.+?)\)/g, (_, id) => id);
      });
    }
    if (async2.length === 0 && pending2.length === 0) {
      fn(deriveds);
      return;
    }
    var parent = (
      /** @type {Effect} */
      active_effect
    );
    var restore = capture();
    var blocker_promise = pending2.length === 1 ? pending2[0].promise : pending2.length > 1 ? Promise.all(pending2.map((b) => b.promise)) : null;
    function finish(async3) {
      if ((parent.f & DESTROYED) !== 0) {
        return;
      }
      restore();
      try {
        fn([...deriveds, ...async3]);
      } catch (error) {
        invoke_error_boundary(error, parent);
      }
      unset_context();
    }
    var decrement_pending = increment_pending();
    if (async2.length === 0) {
      blocker_promise.then(() => finish([])).finally(decrement_pending);
      return;
    }
    function run3() {
      Promise.all(async2.map((expression) => async_derived(expression))).then(finish).catch((error) => invoke_error_boundary(error, parent)).finally(decrement_pending);
    }
    if (blocker_promise) {
      blocker_promise.then(() => {
        restore();
        run3();
        unset_context();
      });
    } else {
      run3();
    }
  }
  function capture() {
    var previous_effect = (
      /** @type {Effect} */
      active_effect
    );
    var previous_reaction = active_reaction;
    var previous_component_context = component_context;
    var previous_batch2 = (
      /** @type {Batch} */
      current_batch
    );
    if (dev_fallback_default) {
      var previous_dev_stack = dev_stack;
    }
    return function restore(activate_batch = true) {
      set_active_effect(previous_effect);
      set_active_reaction(previous_reaction);
      set_component_context(previous_component_context);
      if (activate_batch && (previous_effect.f & DESTROYED) === 0) {
        previous_batch2 == null ? void 0 : previous_batch2.activate();
        previous_batch2 == null ? void 0 : previous_batch2.apply();
      }
      if (dev_fallback_default) {
        set_reactivity_loss_tracker(null);
        set_dev_stack(previous_dev_stack);
      }
    };
  }
  function unset_context(deactivate_batch = true) {
    var _a5;
    set_active_effect(null);
    set_active_reaction(null);
    set_component_context(null);
    if (deactivate_batch) (_a5 = current_batch) == null ? void 0 : _a5.deactivate();
    if (dev_fallback_default) {
      set_reactivity_loss_tracker(null);
      set_dev_stack(null);
    }
  }
  function increment_pending() {
    var effect2 = (
      /** @type {Effect} */
      active_effect
    );
    var boundary2 = effect2.b;
    var batch = (
      /** @type {Batch} */
      current_batch
    );
    var blocking = !!(boundary2 == null ? void 0 : boundary2.is_rendered());
    boundary2 == null ? void 0 : boundary2.update_pending_count(1, batch);
    batch.increment(blocking, effect2);
    return () => {
      boundary2 == null ? void 0 : boundary2.update_pending_count(-1, batch);
      batch.decrement(blocking, effect2);
    };
  }

  // node_modules/svelte/src/internal/client/reactivity/deriveds.js
  var reactivity_loss_tracker = null;
  function set_reactivity_loss_tracker(v) {
    reactivity_loss_tracker = v;
  }
  var recent_async_deriveds = /* @__PURE__ */ new Set();
  // @__NO_SIDE_EFFECTS__
  function derived(fn) {
    var flags2 = DERIVED | DIRTY;
    if (active_effect !== null) {
      active_effect.f |= EFFECT_PRESERVED;
    }
    const signal = {
      ctx: component_context,
      deps: null,
      effects: null,
      equals,
      f: flags2,
      fn,
      reactions: null,
      rv: 0,
      v: (
        /** @type {V} */
        UNINITIALIZED
      ),
      wv: 0,
      parent: active_effect,
      ac: null
    };
    if (dev_fallback_default && tracing_mode_flag) {
      signal.created = get_error("created at");
    }
    return signal;
  }
  var OBSOLETE = /* @__PURE__ */ Symbol("obsolete");
  // @__NO_SIDE_EFFECTS__
  function async_derived(fn, label, location) {
    let parent = (
      /** @type {Effect | null} */
      active_effect
    );
    if (parent === null) {
      async_derived_orphan();
    }
    var promise = (
      /** @type {Promise<V>} */
      /** @type {unknown} */
      void 0
    );
    var signal = source(
      /** @type {V} */
      UNINITIALIZED
    );
    if (dev_fallback_default) signal.label = label != null ? label : fn.toString();
    var should_suspend = !active_reaction;
    var deferreds = /* @__PURE__ */ new Set();
    async_effect(() => {
      var _a5, _b3;
      var effect2 = (
        /** @type {Effect} */
        active_effect
      );
      if (dev_fallback_default) {
        reactivity_loss_tracker = { effect: effect2, effect_deps: /* @__PURE__ */ new Set(), warned: false };
      }
      var d = deferred();
      promise = d.promise;
      try {
        Promise.resolve(fn()).then(d.resolve, (e) => {
          if (e !== STALE_REACTION) d.reject(e);
        }).finally(unset_context);
      } catch (error) {
        d.reject(error);
        unset_context();
      }
      if (dev_fallback_default) {
        if (reactivity_loss_tracker) {
          if (effect2.deps !== null) {
            for (let i = 0; i < skipped_deps; i += 1) {
              reactivity_loss_tracker.effect_deps.add(effect2.deps[i]);
            }
          }
          if (new_deps !== null) {
            for (let i = 0; i < new_deps.length; i += 1) {
              reactivity_loss_tracker.effect_deps.add(new_deps[i]);
            }
          }
        }
        reactivity_loss_tracker = null;
      }
      var batch = (
        /** @type {Batch} */
        current_batch
      );
      if (should_suspend) {
        if ((effect2.f & REACTION_RAN) !== 0) {
          var decrement_pending = increment_pending();
        }
        if (
          // boundary can be null if the async derived is inside an $effect.root not connected to the component render tree
          (_a5 = parent.b) == null ? void 0 : _a5.is_rendered()
        ) {
          (_b3 = batch.async_deriveds.get(effect2)) == null ? void 0 : _b3.reject(OBSOLETE);
        } else {
          for (const d2 of deferreds.values()) {
            d2.reject(OBSOLETE);
          }
        }
        deferreds.add(d);
        batch.async_deriveds.set(effect2, d);
      }
      const handler = (value, error = void 0) => {
        if (dev_fallback_default) {
          reactivity_loss_tracker = null;
        }
        decrement_pending == null ? void 0 : decrement_pending();
        deferreds.delete(d);
        if (error === OBSOLETE) return;
        batch.activate();
        if (error) {
          signal.f |= ERROR_VALUE;
          internal_set(signal, error);
        } else {
          if ((signal.f & ERROR_VALUE) !== 0) {
            signal.f ^= ERROR_VALUE;
          }
          if (dev_fallback_default && location !== void 0 && !signal.equals(value)) {
            recent_async_deriveds.add(signal);
            setTimeout(() => {
              if (recent_async_deriveds.has(signal) && (effect2.f & DESTROYED) === 0) {
                await_waterfall(
                  /** @type {string} */
                  signal.label,
                  location
                );
                recent_async_deriveds.delete(signal);
              }
            });
          }
          internal_set(signal, value);
        }
        batch.deactivate();
      };
      d.promise.then(handler, (e) => handler(null, e || "unknown"));
    });
    teardown(() => {
      for (const d of deferreds) {
        d.reject(OBSOLETE);
      }
    });
    if (dev_fallback_default) {
      signal.f |= ASYNC;
    }
    return new Promise((fulfil) => {
      function next2(p) {
        function go() {
          if (p === promise) {
            fulfil(signal);
          } else {
            next2(promise);
          }
        }
        p.then(go, go);
      }
      next2(promise);
    });
  }
  // @__NO_SIDE_EFFECTS__
  function derived_safe_equal(fn) {
    const signal = /* @__PURE__ */ derived(fn);
    signal.equals = safe_equals;
    return signal;
  }
  function destroy_derived_effects(derived2) {
    var effects = derived2.effects;
    if (effects !== null) {
      derived2.effects = null;
      for (var i = 0; i < effects.length; i += 1) {
        destroy_effect(
          /** @type {Effect} */
          effects[i]
        );
      }
    }
  }
  var stack = [];
  function execute_derived(derived2) {
    var value;
    var prev_active_effect = active_effect;
    var parent = derived2.parent;
    if (!is_destroying_effect && parent !== null && derived2.v !== UNINITIALIZED && // if it was never evaluated before, it's guaranteed to fail downstream, so we try to execute instead
    (parent.f & (DESTROYED | INERT)) !== 0) {
      derived_inert();
      return derived2.v;
    }
    set_active_effect(parent);
    if (dev_fallback_default) {
      let prev_eager_effects = eager_effects;
      set_eager_effects(/* @__PURE__ */ new Set());
      try {
        if (includes.call(stack, derived2)) {
          derived_references_self();
        }
        stack.push(derived2);
        derived2.f &= ~WAS_MARKED;
        destroy_derived_effects(derived2);
        value = update_reaction(derived2);
      } finally {
        set_active_effect(prev_active_effect);
        set_eager_effects(prev_eager_effects);
        stack.pop();
      }
    } else {
      try {
        derived2.f &= ~WAS_MARKED;
        destroy_derived_effects(derived2);
        value = update_reaction(derived2);
      } finally {
        set_active_effect(prev_active_effect);
      }
    }
    return value;
  }
  function update_derived(derived2) {
    var _a5, _b3, _c2;
    var value = execute_derived(derived2);
    if (!derived2.equals(value)) {
      derived2.wv = increment_write_version();
      if (!((_a5 = current_batch) == null ? void 0 : _a5.is_fork) || derived2.deps === null) {
        if (current_batch !== null) {
          current_batch.capture(derived2, value, true);
          (_b3 = previous_batch) == null ? void 0 : _b3.capture(derived2, value, true);
        } else {
          derived2.v = value;
        }
        if (derived2.deps === null) {
          set_signal_status(derived2, CLEAN);
          return;
        }
      }
    }
    if (is_destroying_effect) {
      return;
    }
    if (batch_values !== null) {
      if (effect_tracking() || ((_c2 = current_batch) == null ? void 0 : _c2.is_fork)) {
        batch_values.set(derived2, value);
      }
    } else {
      update_derived_status(derived2);
    }
  }
  function freeze_derived_effects(derived2) {
    var _a5;
    if (derived2.effects === null) return;
    for (const e of derived2.effects) {
      if (e.teardown || e.ac) {
        (_a5 = e.teardown) == null ? void 0 : _a5.call(e);
        if (e.ac !== null) {
          without_reactive_context(() => {
            e.ac.abort(STALE_REACTION);
            e.ac = null;
          });
        }
        if (e.fn !== null) e.teardown = noop;
        remove_reactions(e, 0);
        destroy_effect_children(e);
      }
    }
  }
  function unfreeze_derived_effects(derived2) {
    if (derived2.effects === null) return;
    for (const e of derived2.effects) {
      if (e.teardown && e.fn !== null) {
        update_effect(e);
      }
    }
  }

  // node_modules/svelte/src/internal/client/reactivity/batch.js
  var first_batch = null;
  var last_batch = null;
  var current_batch = null;
  var previous_batch = null;
  var batch_values = null;
  var last_scheduled_effect = null;
  var is_flushing_sync = false;
  var is_processing = false;
  var collected_effects = null;
  var legacy_updates = null;
  var flush_count = 0;
  var source_stacks = /* @__PURE__ */ new Set();
  var uid = 1;
  var _started, _prev, _next, _commit_callbacks, _discard_callbacks, _pending, _blocking_pending, _deferred, _roots, _new_effects, _dirty_effects2, _maybe_dirty_effects2, _skipped_branches, _unskipped_branches, _decrement_queued, _Batch_instances, is_deferred_fn, process_fn, traverse_fn, find_earlier_batch_fn, merge_fn, defer_effects_fn, commit_fn, unlink_fn;
  var _Batch = class _Batch {
    constructor() {
      __privateAdd(this, _Batch_instances);
      __publicField(this, "id", uid++);
      /** True as soon as `#process` was called */
      __privateAdd(this, _started, false);
      __publicField(this, "linked", true);
      /** @type {Batch | null} */
      __privateAdd(this, _prev, null);
      /** @type {Batch | null} */
      __privateAdd(this, _next, null);
      /** @type {Map<Effect, ReturnType<typeof deferred<any>>>} */
      __publicField(this, "async_deriveds", /* @__PURE__ */ new Map());
      /**
       * The current values of any signals that are updated in this batch.
       * Tuple format: [value, is_derived] (note: is_derived is false for deriveds, too, if they were overridden via assignment)
       * They keys of this map are identical to `this.#previous`
       * @type {Map<Value, [any, boolean]>}
       */
      __publicField(this, "current", /* @__PURE__ */ new Map());
      /**
       * The values of any signals (sources and deriveds) that are updated in this batch _before_ those updates took place.
       * They keys of this map are identical to `this.#current`
       * @type {Map<Value, any>}
       */
      __publicField(this, "previous", /* @__PURE__ */ new Map());
      /**
       * When the batch is committed (and the DOM is updated), we need to remove old branches
       * and append new ones by calling the functions added inside (if/each/key/etc) blocks
       * @type {Set<(batch: Batch) => void>}
       */
      __privateAdd(this, _commit_callbacks, /* @__PURE__ */ new Set());
      /**
       * If a fork is discarded, we need to destroy any effects that are no longer needed
       * @type {Set<(batch: Batch) => void>}
       */
      __privateAdd(this, _discard_callbacks, /* @__PURE__ */ new Set());
      /**
       * The number of async effects that are currently in flight
       */
      __privateAdd(this, _pending, 0);
      /**
       * Async effects that are currently in flight, _not_ inside a pending boundary
       * @type {Map<Effect, number>}
       */
      __privateAdd(this, _blocking_pending, /* @__PURE__ */ new Map());
      /**
       * A deferred that resolves when the batch is committed, used with `settled()`
       * TODO replace with Promise.withResolvers once supported widely enough
       * @type {{ promise: Promise<void>, resolve: (value?: any) => void, reject: (reason: unknown) => void } | null}
       */
      __privateAdd(this, _deferred, null);
      /**
       * The root effects that need to be flushed
       * @type {Effect[]}
       */
      __privateAdd(this, _roots, []);
      /**
       * Effects created while this batch was active.
       * @type {Effect[]}
       */
      __privateAdd(this, _new_effects, []);
      /**
       * Deferred effects (which run after async work has completed) that are DIRTY
       * @type {Set<Effect>}
       */
      __privateAdd(this, _dirty_effects2, /* @__PURE__ */ new Set());
      /**
       * Deferred effects that are MAYBE_DIRTY
       * @type {Set<Effect>}
       */
      __privateAdd(this, _maybe_dirty_effects2, /* @__PURE__ */ new Set());
      /**
       * A map of branches that still exist, but will be destroyed when this batch
       * is committed — we skip over these during `process`.
       * The value contains child effects that were dirty/maybe_dirty before being reset,
       * so they can be rescheduled if the branch survives.
       * @type {Map<Effect, { d: Effect[], m: Effect[] }>}
       */
      __privateAdd(this, _skipped_branches, /* @__PURE__ */ new Map());
      /**
       * Inverse of #skipped_branches which we need to tell prior batches to unskip them when committing
       * @type {Set<Effect>}
       */
      __privateAdd(this, _unskipped_branches, /* @__PURE__ */ new Set());
      __publicField(this, "is_fork", false);
      __privateAdd(this, _decrement_queued, false);
      if (last_batch === null) {
        first_batch = last_batch = this;
      } else {
        __privateSet(last_batch, _next, this);
        __privateSet(this, _prev, last_batch);
      }
      last_batch = this;
    }
    /**
     * Add an effect to the #skipped_branches map and reset its children
     * @param {Effect} effect
     */
    skip_effect(effect2) {
      if (!__privateGet(this, _skipped_branches).has(effect2)) {
        __privateGet(this, _skipped_branches).set(effect2, { d: [], m: [] });
      }
      __privateGet(this, _unskipped_branches).delete(effect2);
    }
    /**
     * Remove an effect from the #skipped_branches map and reschedule
     * any tracked dirty/maybe_dirty child effects
     * @param {Effect} effect
     * @param {(e: Effect) => void} callback
     */
    unskip_effect(effect2, callback = (e) => this.schedule(e)) {
      var tracked = __privateGet(this, _skipped_branches).get(effect2);
      if (tracked) {
        __privateGet(this, _skipped_branches).delete(effect2);
        for (var e of tracked.d) {
          set_signal_status(e, DIRTY);
          callback(e);
        }
        for (e of tracked.m) {
          set_signal_status(e, MAYBE_DIRTY);
          callback(e);
        }
      }
      __privateGet(this, _unskipped_branches).add(effect2);
    }
    /**
     * Associate a change to a given source with the current
     * batch, noting its previous and current values
     * @param {Value} source
     * @param {any} value
     * @param {boolean} [is_derived]
     */
    capture(source2, value, is_derived = false) {
      if (source2.v !== UNINITIALIZED && !this.previous.has(source2)) {
        this.previous.set(source2, source2.v);
      }
      if ((source2.f & ERROR_VALUE) === 0) {
        this.current.set(source2, [value, is_derived]);
        batch_values == null ? void 0 : batch_values.set(source2, value);
      }
      if (!this.is_fork) {
        source2.v = value;
      }
    }
    activate() {
      current_batch = this;
    }
    deactivate() {
      current_batch = null;
      batch_values = null;
    }
    flush() {
      try {
        if (dev_fallback_default) {
          source_stacks.clear();
        }
        is_processing = true;
        current_batch = this;
        __privateMethod(this, _Batch_instances, process_fn).call(this);
      } finally {
        flush_count = 0;
        last_scheduled_effect = null;
        collected_effects = null;
        legacy_updates = null;
        is_processing = false;
        current_batch = null;
        batch_values = null;
        old_values.clear();
        if (dev_fallback_default) {
          for (const source2 of source_stacks) {
            source2.updated = null;
          }
        }
      }
    }
    discard() {
      var _a5;
      for (const fn of __privateGet(this, _discard_callbacks)) fn(this);
      __privateGet(this, _discard_callbacks).clear();
      for (const deferred2 of this.async_deriveds.values()) {
        deferred2.reject(OBSOLETE);
      }
      __privateMethod(this, _Batch_instances, unlink_fn).call(this);
      (_a5 = __privateGet(this, _deferred)) == null ? void 0 : _a5.resolve();
    }
    /**
     * @param {Effect} effect
     */
    register_created_effect(effect2) {
      __privateGet(this, _new_effects).push(effect2);
    }
    /**
     * @param {boolean} blocking
     * @param {Effect} effect
     */
    increment(blocking, effect2) {
      var _a5;
      __privateSet(this, _pending, __privateGet(this, _pending) + 1);
      if (blocking) {
        let blocking_pending_count = (_a5 = __privateGet(this, _blocking_pending).get(effect2)) != null ? _a5 : 0;
        __privateGet(this, _blocking_pending).set(effect2, blocking_pending_count + 1);
      }
    }
    /**
     * @param {boolean} blocking
     * @param {Effect} effect
     */
    decrement(blocking, effect2) {
      var _a5;
      __privateSet(this, _pending, __privateGet(this, _pending) - 1);
      if (blocking) {
        let blocking_pending_count = (_a5 = __privateGet(this, _blocking_pending).get(effect2)) != null ? _a5 : 0;
        if (blocking_pending_count === 1) {
          __privateGet(this, _blocking_pending).delete(effect2);
        } else {
          __privateGet(this, _blocking_pending).set(effect2, blocking_pending_count - 1);
        }
      }
      if (__privateGet(this, _decrement_queued)) return;
      __privateSet(this, _decrement_queued, true);
      queue_micro_task(() => {
        __privateSet(this, _decrement_queued, false);
        if (this.linked) {
          this.flush();
        }
      });
    }
    /**
     * @param {Set<Effect>} dirty_effects
     * @param {Set<Effect>} maybe_dirty_effects
     */
    transfer_effects(dirty_effects, maybe_dirty_effects) {
      for (const e of dirty_effects) {
        __privateGet(this, _dirty_effects2).add(e);
      }
      for (const e of maybe_dirty_effects) {
        __privateGet(this, _maybe_dirty_effects2).add(e);
      }
      dirty_effects.clear();
      maybe_dirty_effects.clear();
    }
    /** @param {(batch: Batch) => void} fn */
    oncommit(fn) {
      __privateGet(this, _commit_callbacks).add(fn);
    }
    /** @param {(batch: Batch) => void} fn */
    ondiscard(fn) {
      __privateGet(this, _discard_callbacks).add(fn);
    }
    settled() {
      var _a5;
      return ((_a5 = __privateGet(this, _deferred)) != null ? _a5 : __privateSet(this, _deferred, deferred())).promise;
    }
    static ensure() {
      if (current_batch === null) {
        const batch = current_batch = new _Batch();
        if (!is_processing && !is_flushing_sync) {
          queue_micro_task(() => {
            if (!__privateGet(batch, _started)) {
              batch.flush();
            }
          });
        }
      }
      return current_batch;
    }
    apply() {
      if (!async_mode_flag || !this.is_fork && __privateGet(this, _prev) === null && __privateGet(this, _next) === null) {
        batch_values = null;
        return;
      }
      batch_values = /* @__PURE__ */ new Map();
      for (const [source2, [value]] of this.current) {
        batch_values.set(source2, value);
      }
      for (let batch = first_batch; batch !== null; batch = __privateGet(batch, _next)) {
        if (batch === this || batch.is_fork) continue;
        var intersects = false;
        if (batch.id < this.id) {
          for (const [source2, [, is_derived]] of batch.current) {
            if (is_derived) continue;
            if (this.current.has(source2)) {
              intersects = true;
              break;
            }
          }
        }
        if (!intersects) {
          for (const [source2, previous] of batch.previous) {
            if (!batch_values.has(source2)) {
              batch_values.set(source2, previous);
            }
          }
        }
      }
    }
    /**
     *
     * @param {Effect} effect
     */
    schedule(effect2) {
      var _a5;
      last_scheduled_effect = effect2;
      if (((_a5 = effect2.b) == null ? void 0 : _a5.is_pending) && (effect2.f & (EFFECT | RENDER_EFFECT | MANAGED_EFFECT)) !== 0 && (effect2.f & REACTION_RAN) === 0) {
        effect2.b.defer_effect(effect2);
        return;
      }
      var e = effect2;
      while (e.parent !== null) {
        e = e.parent;
        var flags2 = e.f;
        if (collected_effects !== null && e === active_effect) {
          if (async_mode_flag) return;
          if ((active_reaction === null || (active_reaction.f & DERIVED) === 0) && !legacy_is_updating_store) {
            return;
          }
        }
        if ((flags2 & (ROOT_EFFECT | BRANCH_EFFECT)) !== 0) {
          if ((flags2 & CLEAN) === 0) {
            return;
          }
          e.f ^= CLEAN;
        }
      }
      __privateGet(this, _roots).push(e);
    }
  };
  _started = new WeakMap();
  _prev = new WeakMap();
  _next = new WeakMap();
  _commit_callbacks = new WeakMap();
  _discard_callbacks = new WeakMap();
  _pending = new WeakMap();
  _blocking_pending = new WeakMap();
  _deferred = new WeakMap();
  _roots = new WeakMap();
  _new_effects = new WeakMap();
  _dirty_effects2 = new WeakMap();
  _maybe_dirty_effects2 = new WeakMap();
  _skipped_branches = new WeakMap();
  _unskipped_branches = new WeakMap();
  _decrement_queued = new WeakMap();
  _Batch_instances = new WeakSet();
  is_deferred_fn = function() {
    if (this.is_fork) return true;
    for (const effect2 of __privateGet(this, _blocking_pending).keys()) {
      var e = effect2;
      var skipped = false;
      while (e.parent !== null) {
        if (__privateGet(this, _skipped_branches).has(e)) {
          skipped = true;
          break;
        }
        e = e.parent;
      }
      if (!skipped) {
        return true;
      }
    }
    return false;
  };
  process_fn = function() {
    var _a5, _b3, _c2, _d;
    __privateSet(this, _started, true);
    if (flush_count++ > 1e3) {
      __privateMethod(this, _Batch_instances, unlink_fn).call(this);
      infinite_loop_guard();
    }
    if (dev_fallback_default) {
      for (const value of this.current.keys()) {
        source_stacks.add(value);
      }
    }
    for (const e of __privateGet(this, _dirty_effects2)) {
      __privateGet(this, _maybe_dirty_effects2).delete(e);
      set_signal_status(e, DIRTY);
      this.schedule(e);
    }
    for (const e of __privateGet(this, _maybe_dirty_effects2)) {
      set_signal_status(e, MAYBE_DIRTY);
      this.schedule(e);
    }
    const roots = __privateGet(this, _roots);
    __privateSet(this, _roots, []);
    this.apply();
    var effects = collected_effects = [];
    var render_effects = [];
    var updates = legacy_updates = [];
    for (const root4 of roots) {
      try {
        __privateMethod(this, _Batch_instances, traverse_fn).call(this, root4, effects, render_effects);
      } catch (e) {
        reset_all(root4);
        if (!__privateMethod(this, _Batch_instances, is_deferred_fn).call(this)) this.discard();
        throw e;
      }
    }
    current_batch = null;
    if (updates.length > 0) {
      var batch = _Batch.ensure();
      for (const e of updates) {
        batch.schedule(e);
      }
    }
    collected_effects = null;
    legacy_updates = null;
    if (__privateMethod(this, _Batch_instances, is_deferred_fn).call(this)) {
      __privateMethod(this, _Batch_instances, defer_effects_fn).call(this, render_effects);
      __privateMethod(this, _Batch_instances, defer_effects_fn).call(this, effects);
      for (const [e, t] of __privateGet(this, _skipped_branches)) {
        reset_branch(e, t);
      }
      if (updates.length > 0) {
        /** @type {unknown} */
        __privateMethod(_a5 = current_batch, _Batch_instances, process_fn).call(_a5);
      }
      return;
    }
    const earlier_batch = __privateMethod(this, _Batch_instances, find_earlier_batch_fn).call(this);
    if (earlier_batch) {
      __privateMethod(this, _Batch_instances, defer_effects_fn).call(this, render_effects);
      __privateMethod(this, _Batch_instances, defer_effects_fn).call(this, effects);
      __privateMethod(_b3 = earlier_batch, _Batch_instances, merge_fn).call(_b3, this);
      return;
    }
    __privateGet(this, _dirty_effects2).clear();
    __privateGet(this, _maybe_dirty_effects2).clear();
    for (const fn of __privateGet(this, _commit_callbacks)) fn(this);
    __privateGet(this, _commit_callbacks).clear();
    previous_batch = this;
    flush_queued_effects(render_effects);
    flush_queued_effects(effects);
    previous_batch = null;
    (_c2 = __privateGet(this, _deferred)) == null ? void 0 : _c2.resolve();
    var next_batch = (
      /** @type {Batch | null} */
      /** @type {unknown} */
      current_batch
    );
    if (__privateGet(this, _pending) === 0 && (__privateGet(this, _roots).length === 0 || next_batch !== null)) {
      __privateMethod(this, _Batch_instances, unlink_fn).call(this);
      if (async_mode_flag) {
        __privateMethod(this, _Batch_instances, commit_fn).call(this);
        current_batch = next_batch;
      }
    }
    if (__privateGet(this, _roots).length > 0) {
      if (next_batch !== null) {
        const batch2 = next_batch;
        __privateGet(batch2, _roots).push(...__privateGet(this, _roots).filter((r) => !__privateGet(batch2, _roots).includes(r)));
      } else {
        next_batch = this;
      }
    }
    if (next_batch !== null) {
      __privateMethod(_d = next_batch, _Batch_instances, process_fn).call(_d);
    }
  };
  /**
   * Traverse the effect tree, executing effects or stashing
   * them for later execution as appropriate
   * @param {Effect} root
   * @param {Effect[]} effects
   * @param {Effect[]} render_effects
   */
  traverse_fn = function(root4, effects, render_effects) {
    root4.f ^= CLEAN;
    var effect2 = root4.first;
    while (effect2 !== null) {
      var flags2 = effect2.f;
      var is_branch = (flags2 & (BRANCH_EFFECT | ROOT_EFFECT)) !== 0;
      var is_skippable_branch = is_branch && (flags2 & CLEAN) !== 0;
      var skip = is_skippable_branch || (flags2 & INERT) !== 0 || __privateGet(this, _skipped_branches).has(effect2);
      if (!skip && effect2.fn !== null) {
        if (is_branch) {
          effect2.f ^= CLEAN;
        } else if ((flags2 & EFFECT) !== 0) {
          effects.push(effect2);
        } else if (async_mode_flag && (flags2 & (RENDER_EFFECT | MANAGED_EFFECT)) !== 0) {
          render_effects.push(effect2);
        } else if (is_dirty(effect2)) {
          if ((flags2 & BLOCK_EFFECT) !== 0) __privateGet(this, _maybe_dirty_effects2).add(effect2);
          update_effect(effect2);
        }
        var child2 = effect2.first;
        if (child2 !== null) {
          effect2 = child2;
          continue;
        }
      }
      while (effect2 !== null) {
        var next2 = effect2.next;
        if (next2 !== null) {
          effect2 = next2;
          break;
        }
        effect2 = effect2.parent;
      }
    }
  };
  find_earlier_batch_fn = function() {
    var batch = __privateGet(this, _prev);
    while (batch !== null) {
      if (!batch.is_fork) {
        for (const [value, [, is_derived]] of this.current) {
          if (batch.current.has(value) && !is_derived) {
            return batch;
          }
        }
      }
      batch = __privateGet(batch, _prev);
    }
    return null;
  };
  /**
   * @param {Batch} batch
   */
  merge_fn = function(batch) {
    var _a5;
    for (const [source2, value] of batch.current) {
      if (!this.previous.has(source2) && batch.previous.has(source2)) {
        this.previous.set(source2, batch.previous.get(source2));
      }
      this.current.set(source2, value);
    }
    for (const [effect2, deferred2] of batch.async_deriveds) {
      const d = this.async_deriveds.get(effect2);
      if (d) deferred2.promise.then(d.resolve).catch(d.reject);
    }
    batch.async_deriveds.clear();
    this.transfer_effects(__privateGet(batch, _dirty_effects2), __privateGet(batch, _maybe_dirty_effects2));
    const mark = (value) => {
      var reactions = value.reactions;
      if (reactions === null) return;
      if ((value.f & DERIVED) !== 0 && (value.f & (DIRTY | MAYBE_DIRTY)) === 0) {
        return;
      }
      for (const reaction of reactions) {
        var flags2 = reaction.f;
        if ((flags2 & DERIVED) !== 0) {
          mark(
            /** @type {Derived} */
            reaction
          );
        } else {
          var effect2 = (
            /** @type {Effect} */
            reaction
          );
          if (flags2 & (ASYNC | BLOCK_EFFECT) && !this.async_deriveds.has(effect2)) {
            __privateGet(this, _maybe_dirty_effects2).delete(effect2);
            set_signal_status(effect2, DIRTY);
            this.schedule(effect2);
          }
        }
      }
    };
    for (const source2 of this.current.keys()) {
      mark(source2);
    }
    this.oncommit(() => batch.discard());
    __privateMethod(_a5 = batch, _Batch_instances, unlink_fn).call(_a5);
    current_batch = this;
    __privateMethod(this, _Batch_instances, process_fn).call(this);
  };
  /**
   * @param {Effect[]} effects
   */
  defer_effects_fn = function(effects) {
    for (var i = 0; i < effects.length; i += 1) {
      defer_effect(effects[i], __privateGet(this, _dirty_effects2), __privateGet(this, _maybe_dirty_effects2));
    }
  };
  commit_fn = function() {
    var _a5;
    for (let batch = first_batch; batch !== null; batch = __privateGet(batch, _next)) {
      var is_earlier = batch.id < this.id;
      var sources = [];
      for (const [source3, [value, is_derived]] of this.current) {
        if (batch.current.has(source3)) {
          var batch_value = (
            /** @type {[any, boolean]} */
            batch.current.get(source3)[0]
          );
          if (is_earlier && value !== batch_value) {
            batch.current.set(source3, [value, is_derived]);
          } else {
            continue;
          }
        }
        sources.push(source3);
      }
      if (is_earlier) {
        for (const [effect2, deferred2] of this.async_deriveds) {
          const d = batch.async_deriveds.get(effect2);
          if (d) deferred2.promise.then(d.resolve).catch(d.reject);
        }
      }
      var current = [...batch.current.keys()].filter(
        (source3) => !/** @type {[any, boolean]} */
        batch.current.get(source3)[1]
      );
      if (!__privateGet(batch, _started) || current.length === 0) continue;
      var others = current.filter((source3) => !this.current.has(source3));
      if (others.length === 0) {
        if (is_earlier) {
          batch.discard();
        }
      } else if (sources.length > 0) {
        if (dev_fallback_default && !__privateGet(batch, _decrement_queued)) {
          invariant(__privateGet(batch, _roots).length === 0, "Batch has scheduled roots");
        }
        if (is_earlier) {
          for (const unskipped of __privateGet(this, _unskipped_branches)) {
            batch.unskip_effect(unskipped, (e) => {
              var _a6;
              if ((e.f & (BLOCK_EFFECT | ASYNC)) !== 0) {
                batch.schedule(e);
              } else {
                __privateMethod(_a6 = batch, _Batch_instances, defer_effects_fn).call(_a6, [e]);
              }
            });
          }
        }
        batch.activate();
        var marked = /* @__PURE__ */ new Set();
        var checked = /* @__PURE__ */ new Map();
        for (var source2 of sources) {
          mark_effects(source2, others, marked, checked);
        }
        checked = /* @__PURE__ */ new Map();
        var current_unequal = [...batch.current].filter(([c, v1]) => {
          const v2 = this.current.get(c);
          if (!v2) return true;
          return v2[0] !== v1[0] || v2[1] !== v1[1];
        }).map(([c]) => c);
        if (current_unequal.length > 0) {
          for (const effect2 of __privateGet(this, _new_effects)) {
            if ((effect2.f & (DESTROYED | INERT | EAGER_EFFECT)) === 0 && depends_on(effect2, current_unequal, checked)) {
              if ((effect2.f & (ASYNC | BLOCK_EFFECT)) !== 0) {
                set_signal_status(effect2, DIRTY);
                batch.schedule(effect2);
              } else {
                __privateGet(batch, _dirty_effects2).add(effect2);
              }
            }
          }
        }
        if (__privateGet(batch, _roots).length > 0 && !__privateGet(batch, _decrement_queued)) {
          batch.apply();
          for (var root4 of __privateGet(batch, _roots)) {
            __privateMethod(_a5 = batch, _Batch_instances, traverse_fn).call(_a5, root4, [], []);
          }
          __privateSet(batch, _roots, []);
        }
        batch.deactivate();
      }
    }
  };
  unlink_fn = function() {
    if (!this.linked) return;
    var prev = __privateGet(this, _prev);
    var next2 = __privateGet(this, _next);
    if (prev === null) {
      first_batch = next2;
    } else {
      __privateSet(prev, _next, next2);
    }
    if (next2 === null) {
      last_batch = prev;
    } else {
      __privateSet(next2, _prev, prev);
    }
    this.linked = false;
  };
  var Batch = _Batch;
  function flushSync(fn) {
    var was_flushing_sync = is_flushing_sync;
    is_flushing_sync = true;
    try {
      var result;
      if (fn) {
        if (current_batch !== null && !current_batch.is_fork) {
          current_batch.flush();
        }
        result = fn();
      }
      while (true) {
        flush_tasks();
        if (current_batch === null) {
          return (
            /** @type {T} */
            result
          );
        }
        current_batch.flush();
      }
    } finally {
      is_flushing_sync = was_flushing_sync;
    }
  }
  function infinite_loop_guard() {
    var _a5;
    if (dev_fallback_default) {
      var updates = /* @__PURE__ */ new Map();
      for (
        const source2 of
        /** @type {Batch} */
        current_batch.current.keys()
      ) {
        for (const [stack2, update2] of (_a5 = source2.updated) != null ? _a5 : []) {
          var entry = updates.get(stack2);
          if (!entry) {
            entry = { error: update2.error, count: 0 };
            updates.set(stack2, entry);
          }
          entry.count += update2.count;
        }
      }
      for (const update2 of updates.values()) {
        if (update2.error) {
          console.error(update2.error);
        }
      }
    }
    try {
      effect_update_depth_exceeded();
    } catch (error) {
      if (dev_fallback_default) {
        define_property(error, "stack", { value: "" });
      }
      invoke_error_boundary(error, last_scheduled_effect);
    }
  }
  var eager_block_effects = null;
  function flush_queued_effects(effects) {
    var length = effects.length;
    if (length === 0) return;
    var i = 0;
    while (i < length) {
      var effect2 = effects[i++];
      if ((effect2.f & (DESTROYED | INERT)) === 0 && is_dirty(effect2)) {
        eager_block_effects = /* @__PURE__ */ new Set();
        update_effect(effect2);
        if (effect2.deps === null && effect2.first === null && effect2.nodes === null && effect2.teardown === null && effect2.ac === null) {
          unlink_effect(effect2);
        }
        if ((eager_block_effects == null ? void 0 : eager_block_effects.size) > 0) {
          old_values.clear();
          for (const e of eager_block_effects) {
            if ((e.f & (DESTROYED | INERT)) !== 0) continue;
            const ordered_effects = [e];
            let ancestor = e.parent;
            while (ancestor !== null) {
              if (eager_block_effects.has(ancestor)) {
                eager_block_effects.delete(ancestor);
                ordered_effects.push(ancestor);
              }
              ancestor = ancestor.parent;
            }
            for (let j = ordered_effects.length - 1; j >= 0; j--) {
              const e2 = ordered_effects[j];
              if ((e2.f & (DESTROYED | INERT)) !== 0) continue;
              update_effect(e2);
            }
          }
          eager_block_effects.clear();
        }
      }
    }
    eager_block_effects = null;
  }
  function mark_effects(value, sources, marked, checked) {
    if (marked.has(value)) return;
    marked.add(value);
    if (value.reactions !== null) {
      for (const reaction of value.reactions) {
        const flags2 = reaction.f;
        if ((flags2 & DERIVED) !== 0) {
          mark_effects(
            /** @type {Derived} */
            reaction,
            sources,
            marked,
            checked
          );
        } else if ((flags2 & (ASYNC | BLOCK_EFFECT)) !== 0 && (flags2 & DIRTY) === 0 && depends_on(reaction, sources, checked)) {
          set_signal_status(reaction, DIRTY);
          schedule_effect(
            /** @type {Effect} */
            reaction
          );
        }
      }
    }
  }
  function depends_on(reaction, sources, checked) {
    const depends = checked.get(reaction);
    if (depends !== void 0) return depends;
    if (reaction.deps !== null) {
      for (const dep of reaction.deps) {
        if (includes.call(sources, dep)) {
          return true;
        }
        if ((dep.f & DERIVED) !== 0 && depends_on(
          /** @type {Derived} */
          dep,
          sources,
          checked
        )) {
          checked.set(
            /** @type {Derived} */
            dep,
            true
          );
          return true;
        }
      }
    }
    checked.set(reaction, false);
    return false;
  }
  function schedule_effect(effect2) {
    current_batch.schedule(effect2);
  }
  function reset_branch(effect2, tracked) {
    if ((effect2.f & BRANCH_EFFECT) !== 0 && (effect2.f & CLEAN) !== 0) {
      return;
    }
    if ((effect2.f & DIRTY) !== 0) {
      tracked.d.push(effect2);
    } else if ((effect2.f & MAYBE_DIRTY) !== 0) {
      tracked.m.push(effect2);
    }
    set_signal_status(effect2, CLEAN);
    var e = effect2.first;
    while (e !== null) {
      reset_branch(e, tracked);
      e = e.next;
    }
  }
  function reset_all(effect2) {
    set_signal_status(effect2, CLEAN);
    var e = effect2.first;
    while (e !== null) {
      reset_all(e);
      e = e.next;
    }
  }

  // node_modules/svelte/src/internal/client/reactivity/sources.js
  var eager_effects = /* @__PURE__ */ new Set();
  var old_values = /* @__PURE__ */ new Map();
  function set_eager_effects(v) {
    eager_effects = v;
  }
  var eager_effects_deferred = false;
  function set_eager_effects_deferred() {
    eager_effects_deferred = true;
  }
  function source(v, stack2) {
    var signal = {
      f: 0,
      // TODO ideally we could skip this altogether, but it causes type errors
      v,
      reactions: null,
      equals,
      rv: 0,
      wv: 0
    };
    if (dev_fallback_default && tracing_mode_flag) {
      signal.created = stack2 != null ? stack2 : get_error("created at");
      signal.updated = null;
      signal.set_during_effect = false;
      signal.trace = null;
    }
    return signal;
  }
  // @__NO_SIDE_EFFECTS__
  function state(v, stack2) {
    const s = source(v, stack2);
    push_reaction_value(s);
    return s;
  }
  // @__NO_SIDE_EFFECTS__
  function mutable_source(initial_value, immutable = false, trackable = true) {
    var _a5, _b3;
    const s = source(initial_value);
    if (!immutable) {
      s.equals = safe_equals;
    }
    if (legacy_mode_flag && trackable && component_context !== null && component_context.l !== null) {
      ((_b3 = (_a5 = component_context.l).s) != null ? _b3 : _a5.s = []).push(s);
    }
    return s;
  }
  function set(source2, value, should_proxy = false) {
    if (active_reaction !== null && // since we are untracking the function inside `$inspect.with` we need to add this check
    // to ensure we error if state is set inside an inspect effect
    (!untracking || (active_reaction.f & EAGER_EFFECT) !== 0) && is_runes() && (active_reaction.f & (DERIVED | BLOCK_EFFECT | ASYNC | EAGER_EFFECT)) !== 0 && (current_sources === null || !current_sources.has(source2))) {
      state_unsafe_mutation();
    }
    let new_value = should_proxy ? proxy(value) : value;
    if (dev_fallback_default) {
      tag_proxy(
        new_value,
        /** @type {string} */
        source2.label
      );
    }
    return internal_set(source2, new_value, legacy_updates);
  }
  function internal_set(source2, value, updated_during_traversal = null) {
    var _a5, _b3, _c2;
    if (!source2.equals(value)) {
      old_values.set(source2, is_destroying_effect ? value : source2.v);
      var batch = Batch.ensure();
      batch.capture(source2, value);
      if (dev_fallback_default) {
        if (tracing_mode_flag || active_effect !== null) {
          (_a5 = source2.updated) != null ? _a5 : source2.updated = /* @__PURE__ */ new Map();
          const count = ((_c2 = (_b3 = source2.updated.get("")) == null ? void 0 : _b3.count) != null ? _c2 : 0) + 1;
          source2.updated.set("", { error: (
            /** @type {any} */
            null
          ), count });
          if (tracing_mode_flag || count > 5) {
            const error = get_error("updated at");
            if (error !== null) {
              let entry = source2.updated.get(error.stack);
              if (!entry) {
                entry = { error, count: 0 };
                source2.updated.set(error.stack, entry);
              }
              entry.count++;
            }
          }
        }
        if (active_effect !== null) {
          source2.set_during_effect = true;
        }
      }
      if ((source2.f & DERIVED) !== 0) {
        const derived2 = (
          /** @type {Derived} */
          source2
        );
        if ((source2.f & DIRTY) !== 0) {
          execute_derived(derived2);
        }
        if (batch_values === null) {
          update_derived_status(derived2);
        }
      }
      source2.wv = increment_write_version();
      mark_reactions(source2, DIRTY, updated_during_traversal);
      if (is_runes() && active_effect !== null && (active_effect.f & CLEAN) !== 0 && (active_effect.f & (BRANCH_EFFECT | ROOT_EFFECT)) === 0) {
        if (untracked_writes === null) {
          set_untracked_writes([source2]);
        } else {
          untracked_writes.push(source2);
        }
      }
      if (!batch.is_fork && eager_effects.size > 0 && !eager_effects_deferred) {
        flush_eager_effects();
      }
    }
    return value;
  }
  function flush_eager_effects() {
    eager_effects_deferred = false;
    for (const effect2 of eager_effects) {
      if ((effect2.f & CLEAN) !== 0) {
        set_signal_status(effect2, MAYBE_DIRTY);
      }
      let dirty;
      try {
        dirty = is_dirty(effect2);
      } catch {
        dirty = true;
      }
      if (dirty) {
        update_effect(effect2);
      }
    }
    eager_effects.clear();
  }
  function increment(source2) {
    set(source2, source2.v + 1);
  }
  function mark_reactions(signal, status, updated_during_traversal) {
    var _a5;
    var reactions = signal.reactions;
    if (reactions === null) return;
    var runes = is_runes();
    var length = reactions.length;
    for (var i = 0; i < length; i++) {
      var reaction = reactions[i];
      var flags2 = reaction.f;
      if (!runes && reaction === active_effect) continue;
      var not_dirty = (flags2 & DIRTY) === 0;
      if (not_dirty) {
        set_signal_status(reaction, status);
      }
      if ((flags2 & EAGER_EFFECT) !== 0) {
        eager_effects.add(
          /** @type {Effect} */
          reaction
        );
      } else if ((flags2 & DERIVED) !== 0) {
        var derived2 = (
          /** @type {Derived} */
          reaction
        );
        (_a5 = batch_values) == null ? void 0 : _a5.delete(derived2);
        if ((flags2 & WAS_MARKED) === 0) {
          if (flags2 & CONNECTED && (active_effect === null || (active_effect.f & REACTION_IS_UPDATING) === 0)) {
            reaction.f |= WAS_MARKED;
          }
          mark_reactions(derived2, MAYBE_DIRTY, updated_during_traversal);
        }
      } else if (not_dirty) {
        var effect2 = (
          /** @type {Effect} */
          reaction
        );
        if ((flags2 & BLOCK_EFFECT) !== 0 && eager_block_effects !== null) {
          eager_block_effects.add(effect2);
        }
        if (updated_during_traversal !== null) {
          updated_during_traversal.push(effect2);
        } else {
          schedule_effect(effect2);
        }
      }
    }
  }

  // node_modules/svelte/src/internal/client/proxy.js
  var regex_is_valid_identifier = /^[a-zA-Z_$][a-zA-Z_$0-9]*$/;
  function proxy(value) {
    if (typeof value !== "object" || value === null || STATE_SYMBOL in value) {
      return value;
    }
    const prototype = get_prototype_of(value);
    if (prototype !== object_prototype && prototype !== array_prototype) {
      return value;
    }
    var sources = /* @__PURE__ */ new Map();
    var is_proxied_array = is_array(value);
    var version = state(0);
    var stack2 = dev_fallback_default && tracing_mode_flag ? get_error("created at") : null;
    var parent_version = update_version;
    var with_parent = (fn) => {
      if (update_version === parent_version) {
        return fn();
      }
      var reaction = active_reaction;
      var version2 = update_version;
      set_active_reaction(null);
      set_update_version(parent_version);
      var result = fn();
      set_active_reaction(reaction);
      set_update_version(version2);
      return result;
    };
    if (is_proxied_array) {
      sources.set("length", state(
        /** @type {any[]} */
        value.length,
        stack2
      ));
      if (dev_fallback_default) {
        value = /** @type {any} */
        inspectable_array(
          /** @type {any[]} */
          value
        );
      }
    }
    var path = "";
    let updating = false;
    function update_path(new_path) {
      if (updating) return;
      updating = true;
      path = new_path;
      tag(version, `${path} version`);
      for (const [prop2, source2] of sources) {
        tag(source2, get_label(path, prop2));
      }
      updating = false;
    }
    return new Proxy(
      /** @type {any} */
      value,
      {
        defineProperty(_, prop2, descriptor) {
          if (!("value" in descriptor) || descriptor.configurable === false || descriptor.enumerable === false || descriptor.writable === false) {
            state_descriptors_fixed();
          }
          var s = sources.get(prop2);
          if (s === void 0) {
            with_parent(() => {
              var s2 = state(descriptor.value, stack2);
              sources.set(prop2, s2);
              if (dev_fallback_default && typeof prop2 === "string") {
                tag(s2, get_label(path, prop2));
              }
              return s2;
            });
          } else {
            set(s, descriptor.value, true);
          }
          return true;
        },
        deleteProperty(target, prop2) {
          var s = sources.get(prop2);
          if (s === void 0) {
            if (prop2 in target) {
              const s2 = with_parent(() => state(UNINITIALIZED, stack2));
              sources.set(prop2, s2);
              increment(version);
              if (dev_fallback_default) {
                tag(s2, get_label(path, prop2));
              }
            }
          } else {
            set(s, UNINITIALIZED);
            increment(version);
          }
          return true;
        },
        get(target, prop2, receiver) {
          var _a5;
          if (prop2 === STATE_SYMBOL) {
            return value;
          }
          if (dev_fallback_default && prop2 === PROXY_PATH_SYMBOL) {
            return update_path;
          }
          var s = sources.get(prop2);
          var exists = prop2 in target;
          if (s === void 0 && (!exists || ((_a5 = get_descriptor(target, prop2)) == null ? void 0 : _a5.writable))) {
            s = with_parent(() => {
              var p = proxy(exists ? target[prop2] : UNINITIALIZED);
              var s2 = state(p, stack2);
              if (dev_fallback_default) {
                tag(s2, get_label(path, prop2));
              }
              return s2;
            });
            sources.set(prop2, s);
          }
          if (s !== void 0) {
            var v = get2(s);
            return v === UNINITIALIZED ? void 0 : v;
          }
          return Reflect.get(target, prop2, receiver);
        },
        getOwnPropertyDescriptor(target, prop2) {
          var descriptor = Reflect.getOwnPropertyDescriptor(target, prop2);
          if (descriptor && "value" in descriptor) {
            var s = sources.get(prop2);
            if (s) descriptor.value = get2(s);
          } else if (descriptor === void 0) {
            var source2 = sources.get(prop2);
            var value2 = source2 == null ? void 0 : source2.v;
            if (source2 !== void 0 && value2 !== UNINITIALIZED) {
              return {
                enumerable: true,
                configurable: true,
                value: value2,
                writable: true
              };
            }
          }
          return descriptor;
        },
        has(target, prop2) {
          var _a5;
          if (prop2 === STATE_SYMBOL) {
            return true;
          }
          var s = sources.get(prop2);
          var has = s !== void 0 && s.v !== UNINITIALIZED || Reflect.has(target, prop2);
          if (s !== void 0 || active_effect !== null && (!has || ((_a5 = get_descriptor(target, prop2)) == null ? void 0 : _a5.writable))) {
            if (s === void 0) {
              s = with_parent(() => {
                var p = has ? proxy(target[prop2]) : UNINITIALIZED;
                var s2 = state(p, stack2);
                if (dev_fallback_default) {
                  tag(s2, get_label(path, prop2));
                }
                return s2;
              });
              sources.set(prop2, s);
            }
            var value2 = get2(s);
            if (value2 === UNINITIALIZED) {
              return false;
            }
          }
          return has;
        },
        set(target, prop2, value2, receiver) {
          var _a5;
          var s = sources.get(prop2);
          var has = prop2 in target;
          if (is_proxied_array && prop2 === "length") {
            for (var i = value2; i < /** @type {Source<number>} */
            s.v; i += 1) {
              var other_s = sources.get(i + "");
              if (other_s !== void 0) {
                set(other_s, UNINITIALIZED);
              } else if (i in target) {
                other_s = with_parent(() => state(UNINITIALIZED, stack2));
                sources.set(i + "", other_s);
                if (dev_fallback_default) {
                  tag(other_s, get_label(path, i));
                }
              }
            }
          }
          if (s === void 0) {
            if (!has || ((_a5 = get_descriptor(target, prop2)) == null ? void 0 : _a5.writable)) {
              s = with_parent(() => state(void 0, stack2));
              if (dev_fallback_default) {
                tag(s, get_label(path, prop2));
              }
              set(s, proxy(value2));
              sources.set(prop2, s);
            }
          } else {
            has = s.v !== UNINITIALIZED;
            var p = with_parent(() => proxy(value2));
            set(s, p);
          }
          var descriptor = Reflect.getOwnPropertyDescriptor(target, prop2);
          if (descriptor == null ? void 0 : descriptor.set) {
            descriptor.set.call(receiver, value2);
          }
          if (!has) {
            if (is_proxied_array && typeof prop2 === "string") {
              var ls = (
                /** @type {Source<number>} */
                sources.get("length")
              );
              var n = Number(prop2);
              if (Number.isInteger(n) && n >= ls.v) {
                set(ls, n + 1);
              }
            }
            increment(version);
          }
          return true;
        },
        ownKeys(target) {
          get2(version);
          var own_keys = Reflect.ownKeys(target).filter((key3) => {
            var source3 = sources.get(key3);
            return source3 === void 0 || source3.v !== UNINITIALIZED;
          });
          for (var [key2, source2] of sources) {
            if (source2.v !== UNINITIALIZED && !(key2 in target)) {
              own_keys.push(key2);
            }
          }
          return own_keys;
        },
        setPrototypeOf() {
          state_prototype_fixed();
        }
      }
    );
  }
  function get_label(path, prop2) {
    var _a5;
    if (typeof prop2 === "symbol") return `${path}[Symbol(${(_a5 = prop2.description) != null ? _a5 : ""})]`;
    if (regex_is_valid_identifier.test(prop2)) return `${path}.${prop2}`;
    return /^\d+$/.test(prop2) ? `${path}[${prop2}]` : `${path}['${prop2}']`;
  }
  function get_proxied_value(value) {
    try {
      if (value !== null && typeof value === "object" && STATE_SYMBOL in value) {
        return value[STATE_SYMBOL];
      }
    } catch {
    }
    return value;
  }
  var ARRAY_MUTATING_METHODS = /* @__PURE__ */ new Set([
    "copyWithin",
    "fill",
    "pop",
    "push",
    "reverse",
    "shift",
    "sort",
    "splice",
    "unshift"
  ]);
  function inspectable_array(array) {
    return new Proxy(array, {
      get(target, prop2, receiver) {
        var value = Reflect.get(target, prop2, receiver);
        if (!ARRAY_MUTATING_METHODS.has(
          /** @type {string} */
          prop2
        )) {
          return value;
        }
        return function(...args) {
          set_eager_effects_deferred();
          var result = value.apply(this, args);
          flush_eager_effects();
          return result;
        };
      }
    });
  }

  // node_modules/svelte/src/internal/client/dev/equality.js
  function init_array_prototype_warnings() {
    const array_prototype2 = Array.prototype;
    const cleanup = Array.__svelte_cleanup;
    if (cleanup) {
      cleanup();
    }
    const { indexOf, lastIndexOf, includes: includes2 } = array_prototype2;
    array_prototype2.indexOf = function(item, from_index) {
      const index2 = indexOf.call(this, item, from_index);
      if (index2 === -1) {
        for (let i = from_index != null ? from_index : 0; i < this.length; i += 1) {
          if (get_proxied_value(this[i]) === item) {
            state_proxy_equality_mismatch("array.indexOf(...)");
            break;
          }
        }
      }
      return index2;
    };
    array_prototype2.lastIndexOf = function(item, from_index) {
      const index2 = lastIndexOf.call(this, item, from_index != null ? from_index : this.length - 1);
      if (index2 === -1) {
        for (let i = 0; i <= (from_index != null ? from_index : this.length - 1); i += 1) {
          if (get_proxied_value(this[i]) === item) {
            state_proxy_equality_mismatch("array.lastIndexOf(...)");
            break;
          }
        }
      }
      return index2;
    };
    array_prototype2.includes = function(item, from_index) {
      const has = includes2.call(this, item, from_index);
      if (!has) {
        for (let i = 0; i < this.length; i += 1) {
          if (get_proxied_value(this[i]) === item) {
            state_proxy_equality_mismatch("array.includes(...)");
            break;
          }
        }
      }
      return has;
    };
    Array.__svelte_cleanup = () => {
      array_prototype2.indexOf = indexOf;
      array_prototype2.lastIndexOf = lastIndexOf;
      array_prototype2.includes = includes2;
    };
  }

  // node_modules/svelte/src/internal/client/dom/operations.js
  var $window;
  var $document;
  var is_firefox;
  var first_child_getter;
  var next_sibling_getter;
  function init_operations() {
    if ($window !== void 0) {
      return;
    }
    $window = window;
    $document = document;
    is_firefox = /Firefox/.test(navigator.userAgent);
    var element_prototype = Element.prototype;
    var node_prototype = Node.prototype;
    var text_prototype = Text.prototype;
    first_child_getter = get_descriptor(node_prototype, "firstChild").get;
    next_sibling_getter = get_descriptor(node_prototype, "nextSibling").get;
    if (is_extensible(element_prototype)) {
      element_prototype[CLASS_CACHE] = void 0;
      element_prototype[ATTRIBUTES_CACHE] = null;
      element_prototype[STYLE_CACHE] = void 0;
      element_prototype.__e = void 0;
    }
    if (is_extensible(text_prototype)) {
      text_prototype[TEXT_CACHE] = void 0;
    }
    if (dev_fallback_default) {
      element_prototype.__svelte_meta = null;
      init_array_prototype_warnings();
    }
  }
  function create_text(value = "") {
    return document.createTextNode(value);
  }
  // @__NO_SIDE_EFFECTS__
  function get_first_child(node) {
    return (
      /** @type {TemplateNode | null} */
      first_child_getter.call(node)
    );
  }
  // @__NO_SIDE_EFFECTS__
  function get_next_sibling(node) {
    return (
      /** @type {TemplateNode | null} */
      next_sibling_getter.call(node)
    );
  }
  function child(node, is_text) {
    if (!hydrating) {
      return /* @__PURE__ */ get_first_child(node);
    }
    var child2 = /* @__PURE__ */ get_first_child(hydrate_node);
    if (child2 === null) {
      child2 = hydrate_node.appendChild(create_text());
    } else if (is_text && child2.nodeType !== TEXT_NODE) {
      var text2 = create_text();
      child2 == null ? void 0 : child2.before(text2);
      set_hydrate_node(text2);
      return text2;
    }
    if (is_text) {
      merge_text_nodes(
        /** @type {Text} */
        child2
      );
    }
    set_hydrate_node(child2);
    return child2;
  }
  function first_child(node, is_text = false) {
    var _a5, _b3;
    if (!hydrating) {
      var first = /* @__PURE__ */ get_first_child(node);
      if (first instanceof Comment && first.data === "") return /* @__PURE__ */ get_next_sibling(first);
      return first;
    }
    if (is_text) {
      if (((_a5 = hydrate_node) == null ? void 0 : _a5.nodeType) !== TEXT_NODE) {
        var text2 = create_text();
        (_b3 = hydrate_node) == null ? void 0 : _b3.before(text2);
        set_hydrate_node(text2);
        return text2;
      }
      merge_text_nodes(
        /** @type {Text} */
        hydrate_node
      );
    }
    return hydrate_node;
  }
  function sibling(node, count = 1, is_text = false) {
    let next_sibling = hydrating ? hydrate_node : node;
    var last_sibling;
    while (count--) {
      last_sibling = next_sibling;
      next_sibling = /** @type {TemplateNode} */
      /* @__PURE__ */ get_next_sibling(next_sibling);
    }
    if (!hydrating) {
      return next_sibling;
    }
    if (is_text) {
      if ((next_sibling == null ? void 0 : next_sibling.nodeType) !== TEXT_NODE) {
        var text2 = create_text();
        if (next_sibling === null) {
          last_sibling == null ? void 0 : last_sibling.after(text2);
        } else {
          next_sibling.before(text2);
        }
        set_hydrate_node(text2);
        return text2;
      }
      merge_text_nodes(
        /** @type {Text} */
        next_sibling
      );
    }
    set_hydrate_node(next_sibling);
    return next_sibling;
  }
  function clear_text_content(node) {
    node.textContent = "";
  }
  function should_defer_append() {
    if (!async_mode_flag) return false;
    if (eager_block_effects !== null) return false;
    var flags2 = (
      /** @type {Effect} */
      active_effect.f
    );
    return (flags2 & REACTION_RAN) !== 0;
  }
  function create_element(tag2, namespace, is2) {
    if (namespace == null || namespace === NAMESPACE_HTML) {
      return (
        /** @type {T extends keyof HTMLElementTagNameMap ? HTMLElementTagNameMap[T] : Element} */
        is2 ? document.createElement(tag2, { is: is2 }) : document.createElement(tag2)
      );
    }
    return (
      /** @type {T extends keyof HTMLElementTagNameMap ? HTMLElementTagNameMap[T] : Element} */
      is2 ? document.createElementNS(namespace, tag2, { is: is2 }) : document.createElementNS(namespace, tag2)
    );
  }
  function merge_text_nodes(text2) {
    if (
      /** @type {string} */
      text2.nodeValue.length < 65536
    ) {
      return;
    }
    let next2 = text2.nextSibling;
    while (next2 !== null && next2.nodeType === TEXT_NODE) {
      next2.remove();
      text2.nodeValue += /** @type {string} */
      next2.nodeValue;
      next2 = text2.nextSibling;
    }
  }

  // node_modules/svelte/src/internal/client/reactivity/effects.js
  function validate_effect(rune) {
    if (active_effect === null) {
      if (active_reaction === null) {
        effect_orphan(rune);
      }
      effect_in_unowned_derived();
    }
    if (is_destroying_effect) {
      effect_in_teardown(rune);
    }
  }
  function push_effect(effect2, parent_effect) {
    var parent_last = parent_effect.last;
    if (parent_last === null) {
      parent_effect.last = parent_effect.first = effect2;
    } else {
      parent_last.next = effect2;
      effect2.prev = parent_last;
      parent_effect.last = effect2;
    }
  }
  function create_effect(type, fn) {
    var _a5, _b3;
    var parent = active_effect;
    if (dev_fallback_default) {
      while (parent !== null && (parent.f & EAGER_EFFECT) !== 0) {
        parent = parent.parent;
      }
    }
    if (parent !== null && (parent.f & INERT) !== 0) {
      type |= INERT;
    }
    var effect2 = {
      ctx: component_context,
      deps: null,
      nodes: null,
      f: type | DIRTY | CONNECTED,
      first: null,
      fn,
      last: null,
      next: null,
      parent,
      b: parent && parent.b,
      prev: null,
      teardown: null,
      wv: 0,
      ac: null
    };
    if (dev_fallback_default) {
      effect2.component_function = dev_current_component_function;
    }
    (_a5 = current_batch) == null ? void 0 : _a5.register_created_effect(effect2);
    var e = effect2;
    if ((type & EFFECT) !== 0) {
      if (collected_effects !== null) {
        collected_effects.push(effect2);
      } else {
        Batch.ensure().schedule(effect2);
      }
    } else if (fn !== null) {
      try {
        update_effect(effect2);
      } catch (e2) {
        destroy_effect(effect2);
        throw e2;
      }
      if (e.deps === null && e.teardown === null && e.nodes === null && e.first === e.last && // either `null`, or a singular child
      (e.f & EFFECT_PRESERVED) === 0) {
        e = e.first;
        if ((type & BLOCK_EFFECT) !== 0 && (type & EFFECT_TRANSPARENT) !== 0 && e !== null) {
          e.f |= EFFECT_TRANSPARENT;
        }
      }
    }
    if (e !== null) {
      e.parent = parent;
      if (parent !== null) {
        push_effect(e, parent);
      }
      if (active_reaction !== null && (active_reaction.f & DERIVED) !== 0 && (type & ROOT_EFFECT) === 0) {
        var derived2 = (
          /** @type {Derived} */
          active_reaction
        );
        ((_b3 = derived2.effects) != null ? _b3 : derived2.effects = []).push(e);
      }
    }
    return effect2;
  }
  function effect_tracking() {
    return active_reaction !== null && !untracking;
  }
  function teardown(fn) {
    const effect2 = create_effect(RENDER_EFFECT, null);
    set_signal_status(effect2, CLEAN);
    effect2.teardown = fn;
    return effect2;
  }
  function user_effect(fn) {
    var _a5;
    validate_effect("$effect");
    if (dev_fallback_default) {
      define_property(fn, "name", {
        value: "$effect"
      });
    }
    var flags2 = (
      /** @type {Effect} */
      active_effect.f
    );
    var defer = !active_reaction && (flags2 & BRANCH_EFFECT) !== 0 && component_context !== null && !component_context.i;
    if (defer) {
      var context = (
        /** @type {ComponentContext} */
        component_context
      );
      ((_a5 = context.e) != null ? _a5 : context.e = []).push(fn);
    } else {
      return create_user_effect(fn);
    }
  }
  function create_user_effect(fn) {
    return create_effect(EFFECT | USER_EFFECT, fn);
  }
  function user_pre_effect(fn) {
    validate_effect("$effect.pre");
    if (dev_fallback_default) {
      define_property(fn, "name", {
        value: "$effect.pre"
      });
    }
    return create_effect(RENDER_EFFECT | USER_EFFECT, fn);
  }
  function effect_root(fn) {
    Batch.ensure();
    const effect2 = create_effect(ROOT_EFFECT | EFFECT_PRESERVED, fn);
    return () => {
      destroy_effect(effect2);
    };
  }
  function component_root(fn) {
    Batch.ensure();
    const effect2 = create_effect(ROOT_EFFECT | EFFECT_PRESERVED, fn);
    return (options = {}) => {
      return new Promise((fulfil) => {
        if (options.outro) {
          pause_effect(effect2, () => {
            destroy_effect(effect2);
            fulfil(void 0);
          });
        } else {
          destroy_effect(effect2);
          fulfil(void 0);
        }
      });
    };
  }
  function legacy_pre_effect(deps, fn) {
    var context = (
      /** @type {ComponentContextLegacy} */
      component_context
    );
    var token = { effect: null, ran: false, deps };
    context.l.$.push(token);
    token.effect = render_effect(() => {
      deps();
      if (token.ran) return;
      token.ran = true;
      var effect2 = (
        /** @type {Effect} */
        active_effect
      );
      try {
        set_active_effect(effect2.parent);
        untrack(fn);
      } finally {
        set_active_effect(effect2);
      }
    });
  }
  function legacy_pre_effect_reset() {
    var context = (
      /** @type {ComponentContextLegacy} */
      component_context
    );
    render_effect(() => {
      for (var token of context.l.$) {
        token.deps();
        var effect2 = token.effect;
        if ((effect2.f & CLEAN) !== 0 && effect2.deps !== null) {
          set_signal_status(effect2, MAYBE_DIRTY);
        }
        if (is_dirty(effect2)) {
          update_effect(effect2);
        }
        token.ran = false;
      }
    });
  }
  function async_effect(fn) {
    return create_effect(ASYNC | EFFECT_PRESERVED, fn);
  }
  function render_effect(fn, flags2 = 0) {
    return create_effect(RENDER_EFFECT | flags2, fn);
  }
  function template_effect(fn, sync = [], async2 = [], blockers = []) {
    flatten(blockers, sync, async2, (values2) => {
      create_effect(RENDER_EFFECT, () => {
        fn(...values2.map(get2));
      });
    });
  }
  function block(fn, flags2 = 0) {
    var effect2 = create_effect(BLOCK_EFFECT | flags2, fn);
    if (dev_fallback_default) {
      effect2.dev_stack = dev_stack;
    }
    return effect2;
  }
  function branch(fn) {
    return create_effect(BRANCH_EFFECT | EFFECT_PRESERVED, fn);
  }
  function execute_effect_teardown(effect2) {
    var teardown2 = effect2.teardown;
    if (teardown2 !== null) {
      const previously_destroying_effect = is_destroying_effect;
      const previous_reaction = active_reaction;
      set_is_destroying_effect(true);
      set_active_reaction(null);
      try {
        teardown2.call(null);
      } finally {
        set_is_destroying_effect(previously_destroying_effect);
        set_active_reaction(previous_reaction);
      }
    }
  }
  function destroy_effect_children(signal, remove_dom = false) {
    var effect2 = signal.first;
    signal.first = signal.last = null;
    while (effect2 !== null) {
      const controller = effect2.ac;
      if (controller !== null) {
        without_reactive_context(() => {
          controller.abort(STALE_REACTION);
        });
      }
      var next2 = effect2.next;
      if ((effect2.f & ROOT_EFFECT) !== 0) {
        effect2.parent = null;
      } else {
        destroy_effect(effect2, remove_dom);
      }
      effect2 = next2;
    }
  }
  function destroy_block_effect_children(signal) {
    var effect2 = signal.first;
    while (effect2 !== null) {
      var next2 = effect2.next;
      if ((effect2.f & BRANCH_EFFECT) === 0) {
        destroy_effect(effect2);
      }
      effect2 = next2;
    }
  }
  function destroy_effect(effect2, remove_dom = true) {
    var removed = false;
    if ((remove_dom || (effect2.f & HEAD_EFFECT) !== 0) && effect2.nodes !== null && effect2.nodes.end !== null) {
      remove_effect_dom(
        effect2.nodes.start,
        /** @type {TemplateNode} */
        effect2.nodes.end
      );
      removed = true;
    }
    effect2.f |= DESTROYING;
    destroy_effect_children(effect2, remove_dom && !removed);
    remove_reactions(effect2, 0);
    var transitions = effect2.nodes && effect2.nodes.t;
    if (transitions !== null) {
      for (const transition2 of transitions) {
        transition2.stop();
      }
    }
    execute_effect_teardown(effect2);
    effect2.f ^= DESTROYING;
    effect2.f |= DESTROYED;
    var parent = effect2.parent;
    if (parent !== null && parent.first !== null) {
      unlink_effect(effect2);
    }
    if (dev_fallback_default) {
      effect2.component_function = null;
    }
    effect2.next = effect2.prev = effect2.teardown = effect2.ctx = effect2.deps = effect2.fn = effect2.nodes = effect2.ac = effect2.b = null;
  }
  function remove_effect_dom(node, end) {
    while (node !== null) {
      var next2 = node === end ? null : get_next_sibling(node);
      node.remove();
      node = next2;
    }
  }
  function unlink_effect(effect2) {
    var parent = effect2.parent;
    var prev = effect2.prev;
    var next2 = effect2.next;
    if (prev !== null) prev.next = next2;
    if (next2 !== null) next2.prev = prev;
    if (parent !== null) {
      if (parent.first === effect2) parent.first = next2;
      if (parent.last === effect2) parent.last = prev;
    }
  }
  function pause_effect(effect2, callback, destroy = true) {
    var transitions = [];
    pause_children(effect2, transitions, true);
    var fn = () => {
      if (destroy) destroy_effect(effect2);
      if (callback) callback();
    };
    var remaining = transitions.length;
    if (remaining > 0) {
      var check = () => --remaining || fn();
      for (var transition2 of transitions) {
        transition2.out(check);
      }
    } else {
      fn();
    }
  }
  function pause_children(effect2, transitions, local) {
    if ((effect2.f & INERT) !== 0) return;
    effect2.f ^= INERT;
    var t = effect2.nodes && effect2.nodes.t;
    if (t !== null) {
      for (const transition2 of t) {
        if (transition2.is_global || local) {
          transitions.push(transition2);
        }
      }
    }
    var child2 = effect2.first;
    while (child2 !== null) {
      var sibling2 = child2.next;
      if ((child2.f & ROOT_EFFECT) === 0) {
        var transparent = (child2.f & EFFECT_TRANSPARENT) !== 0 || // If this is a branch effect without a block effect parent,
        // it means the parent block effect was pruned. In that case,
        // transparency information was transferred to the branch effect.
        (child2.f & BRANCH_EFFECT) !== 0 && (effect2.f & BLOCK_EFFECT) !== 0;
        pause_children(child2, transitions, transparent ? local : false);
      }
      child2 = sibling2;
    }
  }
  function resume_effect(effect2) {
    resume_children(effect2, true);
  }
  function resume_children(effect2, local) {
    if ((effect2.f & INERT) === 0) return;
    effect2.f ^= INERT;
    if ((effect2.f & CLEAN) === 0) {
      set_signal_status(effect2, DIRTY);
      Batch.ensure().schedule(effect2);
    }
    var child2 = effect2.first;
    while (child2 !== null) {
      var sibling2 = child2.next;
      var transparent = (child2.f & EFFECT_TRANSPARENT) !== 0 || (child2.f & BRANCH_EFFECT) !== 0;
      resume_children(child2, transparent ? local : false);
      child2 = sibling2;
    }
    var t = effect2.nodes && effect2.nodes.t;
    if (t !== null) {
      for (const transition2 of t) {
        if (transition2.is_global || local) {
          transition2.in();
        }
      }
    }
  }
  function move_effect(effect2, fragment) {
    if (!effect2.nodes) return;
    var node = effect2.nodes.start;
    var end = effect2.nodes.end;
    while (node !== null) {
      var next2 = node === end ? null : get_next_sibling(node);
      fragment.append(node);
      node = next2;
    }
  }

  // node_modules/svelte/src/internal/client/legacy.js
  var captured_signals = null;

  // node_modules/svelte/src/internal/client/runtime.js
  var is_updating_effect = false;
  var is_destroying_effect = false;
  function set_is_destroying_effect(value) {
    is_destroying_effect = value;
  }
  var active_reaction = null;
  var untracking = false;
  function set_active_reaction(reaction) {
    active_reaction = reaction;
  }
  var active_effect = null;
  function set_active_effect(effect2) {
    active_effect = effect2;
  }
  var current_sources = null;
  function push_reaction_value(value) {
    if (active_reaction !== null && (!async_mode_flag || (active_reaction.f & DERIVED) !== 0)) {
      (current_sources != null ? current_sources : current_sources = /* @__PURE__ */ new Set()).add(value);
    }
  }
  var new_deps = null;
  var skipped_deps = 0;
  var untracked_writes = null;
  function set_untracked_writes(value) {
    untracked_writes = value;
  }
  var write_version = 1;
  var read_version = 0;
  var update_version = read_version;
  function set_update_version(value) {
    update_version = value;
  }
  function increment_write_version() {
    return ++write_version;
  }
  function is_dirty(reaction) {
    var flags2 = reaction.f;
    if ((flags2 & DIRTY) !== 0) {
      return true;
    }
    if (flags2 & DERIVED) {
      reaction.f &= ~WAS_MARKED;
    }
    if ((flags2 & MAYBE_DIRTY) !== 0) {
      var dependencies = (
        /** @type {Value[]} */
        reaction.deps
      );
      var length = dependencies.length;
      for (var i = 0; i < length; i++) {
        var dependency = dependencies[i];
        if (is_dirty(
          /** @type {Derived} */
          dependency
        )) {
          update_derived(
            /** @type {Derived} */
            dependency
          );
        }
        if (dependency.wv > reaction.wv) {
          return true;
        }
      }
      if ((flags2 & CONNECTED) !== 0 && // During time traveling we don't want to reset the status so that
      // traversal of the graph in the other batches still happens
      batch_values === null) {
        set_signal_status(reaction, CLEAN);
      }
    }
    return false;
  }
  function schedule_possible_effect_self_invalidation(signal, effect2, root4 = true) {
    var reactions = signal.reactions;
    if (reactions === null) return;
    if (!async_mode_flag && current_sources !== null && current_sources.has(signal)) {
      return;
    }
    for (var i = 0; i < reactions.length; i++) {
      var reaction = reactions[i];
      if ((reaction.f & DERIVED) !== 0) {
        schedule_possible_effect_self_invalidation(
          /** @type {Derived} */
          reaction,
          effect2,
          false
        );
      } else if (effect2 === reaction) {
        if (root4) {
          set_signal_status(reaction, DIRTY);
        } else if ((reaction.f & CLEAN) !== 0) {
          set_signal_status(reaction, MAYBE_DIRTY);
        }
        schedule_effect(
          /** @type {Effect} */
          reaction
        );
      }
    }
  }
  function update_reaction(reaction) {
    var _a5, _b3, _c2;
    var previous_deps = new_deps;
    var previous_skipped_deps = skipped_deps;
    var previous_untracked_writes = untracked_writes;
    var previous_reaction = active_reaction;
    var previous_sources = current_sources;
    var previous_component_context = component_context;
    var previous_untracking = untracking;
    var previous_update_version = update_version;
    var flags2 = reaction.f;
    new_deps = /** @type {null | Value[]} */
    null;
    skipped_deps = 0;
    untracked_writes = null;
    active_reaction = (flags2 & (BRANCH_EFFECT | ROOT_EFFECT)) === 0 ? reaction : null;
    current_sources = null;
    set_component_context(reaction.ctx);
    untracking = false;
    update_version = ++read_version;
    if (reaction.ac !== null) {
      without_reactive_context(() => {
        reaction.ac.abort(STALE_REACTION);
      });
      reaction.ac = null;
    }
    try {
      reaction.f |= REACTION_IS_UPDATING;
      var fn = (
        /** @type {Function} */
        reaction.fn
      );
      var result = fn();
      reaction.f |= REACTION_RAN;
      var deps = reaction.deps;
      var is_fork = (_a5 = current_batch) == null ? void 0 : _a5.is_fork;
      if (new_deps !== null) {
        var i;
        if (!is_fork) {
          remove_reactions(reaction, skipped_deps);
        }
        if (deps !== null && skipped_deps > 0) {
          deps.length = skipped_deps + new_deps.length;
          for (i = 0; i < new_deps.length; i++) {
            deps[skipped_deps + i] = new_deps[i];
          }
        } else {
          reaction.deps = deps = new_deps;
        }
        if (effect_tracking() && (reaction.f & CONNECTED) !== 0) {
          for (i = skipped_deps; i < deps.length; i++) {
            ((_c2 = (_b3 = deps[i]).reactions) != null ? _c2 : _b3.reactions = []).push(reaction);
          }
        }
      } else if (!is_fork && deps !== null && skipped_deps < deps.length) {
        remove_reactions(reaction, skipped_deps);
        deps.length = skipped_deps;
      }
      if (is_runes() && untracked_writes !== null && !untracking && deps !== null && (reaction.f & (DERIVED | MAYBE_DIRTY | DIRTY)) === 0) {
        for (i = 0; i < /** @type {Source[]} */
        untracked_writes.length; i++) {
          schedule_possible_effect_self_invalidation(
            untracked_writes[i],
            /** @type {Effect} */
            reaction
          );
        }
      }
      if (previous_reaction !== null && previous_reaction !== reaction) {
        read_version++;
        if (previous_reaction.deps !== null) {
          for (let i2 = 0; i2 < previous_skipped_deps; i2 += 1) {
            previous_reaction.deps[i2].rv = read_version;
          }
        }
        if (previous_deps !== null) {
          for (const dep of previous_deps) {
            dep.rv = read_version;
          }
        }
        if (untracked_writes !== null) {
          if (previous_untracked_writes === null) {
            previous_untracked_writes = untracked_writes;
          } else {
            previous_untracked_writes.push(.../** @type {Source[]} */
            untracked_writes);
          }
        }
      }
      if ((reaction.f & ERROR_VALUE) !== 0) {
        reaction.f ^= ERROR_VALUE;
      }
      return result;
    } catch (error) {
      return handle_error(error);
    } finally {
      reaction.f ^= REACTION_IS_UPDATING;
      new_deps = previous_deps;
      skipped_deps = previous_skipped_deps;
      untracked_writes = previous_untracked_writes;
      active_reaction = previous_reaction;
      current_sources = previous_sources;
      set_component_context(previous_component_context);
      untracking = previous_untracking;
      update_version = previous_update_version;
    }
  }
  function remove_reaction(signal, dependency) {
    let reactions = dependency.reactions;
    if (reactions !== null) {
      var index2 = index_of.call(reactions, signal);
      if (index2 !== -1) {
        var new_length = reactions.length - 1;
        if (new_length === 0) {
          reactions = dependency.reactions = null;
        } else {
          reactions[index2] = reactions[new_length];
          reactions.pop();
        }
      }
    }
    if (reactions === null && (dependency.f & DERIVED) !== 0 && // Destroying a child effect while updating a parent effect can cause a dependency to appear
    // to be unused, when in fact it is used by the currently-updating parent. Checking `new_deps`
    // allows us to skip the expensive work of disconnecting and immediately reconnecting it
    (new_deps === null || !includes.call(new_deps, dependency))) {
      var derived2 = (
        /** @type {Derived} */
        dependency
      );
      if ((derived2.f & CONNECTED) !== 0) {
        derived2.f ^= CONNECTED;
        derived2.f &= ~WAS_MARKED;
      }
      if (derived2.v !== UNINITIALIZED) {
        update_derived_status(derived2);
      }
      if (derived2.ac !== null) {
        without_reactive_context(() => {
          derived2.ac.abort(STALE_REACTION);
          derived2.ac = null;
          set_signal_status(derived2, DIRTY);
        });
      }
      freeze_derived_effects(derived2);
      remove_reactions(derived2, 0);
    }
  }
  function remove_reactions(signal, start_index) {
    var dependencies = signal.deps;
    if (dependencies === null) return;
    for (var i = start_index; i < dependencies.length; i++) {
      remove_reaction(signal, dependencies[i]);
    }
  }
  function update_effect(effect2) {
    var _a5;
    var flags2 = effect2.f;
    if ((flags2 & DESTROYED) !== 0) {
      return;
    }
    set_signal_status(effect2, CLEAN);
    var previous_effect = active_effect;
    var was_updating_effect = is_updating_effect;
    active_effect = effect2;
    is_updating_effect = (flags2 & (BRANCH_EFFECT | ROOT_EFFECT)) === 0;
    if (dev_fallback_default) {
      var previous_component_fn = dev_current_component_function;
      set_dev_current_component_function(effect2.component_function);
      var previous_stack = (
        /** @type {any} */
        dev_stack
      );
      set_dev_stack((_a5 = effect2.dev_stack) != null ? _a5 : dev_stack);
    }
    try {
      if ((flags2 & (BLOCK_EFFECT | MANAGED_EFFECT)) !== 0) {
        destroy_block_effect_children(effect2);
      } else {
        destroy_effect_children(effect2);
      }
      execute_effect_teardown(effect2);
      var teardown2 = update_reaction(effect2);
      effect2.teardown = typeof teardown2 === "function" ? teardown2 : null;
      effect2.wv = write_version;
      if (dev_fallback_default && tracing_mode_flag && (effect2.f & DIRTY) !== 0 && effect2.deps !== null) {
        for (var dep of effect2.deps) {
          if (dep.set_during_effect) {
            dep.wv = increment_write_version();
            dep.set_during_effect = false;
          }
        }
      }
    } finally {
      is_updating_effect = was_updating_effect;
      active_effect = previous_effect;
      if (dev_fallback_default) {
        set_dev_current_component_function(previous_component_fn);
        set_dev_stack(previous_stack);
      }
    }
  }
  function get2(signal) {
    var _a5, _b3, _c2;
    var flags2 = signal.f;
    var is_derived = (flags2 & DERIVED) !== 0;
    (_a5 = captured_signals) == null ? void 0 : _a5.add(signal);
    if (active_reaction !== null && !untracking) {
      var destroyed = active_effect !== null && (active_effect.f & DESTROYED) !== 0;
      if (!destroyed && (current_sources === null || !current_sources.has(signal))) {
        var deps = active_reaction.deps;
        if ((active_reaction.f & REACTION_IS_UPDATING) !== 0) {
          if (signal.rv < read_version) {
            signal.rv = read_version;
            if (new_deps === null && deps !== null && deps[skipped_deps] === signal) {
              skipped_deps++;
            } else if (new_deps === null) {
              new_deps = [signal];
            } else {
              new_deps.push(signal);
            }
          }
        } else {
          (_b3 = active_reaction.deps) != null ? _b3 : active_reaction.deps = [];
          if (!includes.call(active_reaction.deps, signal)) {
            active_reaction.deps.push(signal);
          }
          var reactions = signal.reactions;
          if (reactions === null) {
            signal.reactions = [active_reaction];
          } else if (!includes.call(reactions, active_reaction)) {
            reactions.push(active_reaction);
          }
        }
      }
    }
    if (dev_fallback_default) {
      if (!untracking && reactivity_loss_tracker && // By checking that current/previous batch are null we filter out false positives.
      // reactivity_loss_tracker is only reset after a microtask, so if a flush happens
      // before that, we get warnings for things we shouldn't warn on.
      current_batch === null && previous_batch === null && !reactivity_loss_tracker.warned && (reactivity_loss_tracker.effect.f & REACTION_IS_UPDATING) === 0 && !reactivity_loss_tracker.effect_deps.has(signal)) {
        reactivity_loss_tracker.warned = true;
        await_reactivity_loss(
          /** @type {string} */
          signal.label
        );
        var trace2 = get_error("traced at");
        if (trace2) console.warn(trace2);
      }
      recent_async_deriveds.delete(signal);
      if (tracing_mode_flag && !untracking && tracing_expressions !== null && active_reaction !== null && tracing_expressions.reaction === active_reaction) {
        if (signal.trace) {
          signal.trace();
        } else {
          trace2 = get_error("traced at");
          if (trace2) {
            var entry = tracing_expressions.entries.get(signal);
            if (entry === void 0) {
              entry = { traces: [] };
              tracing_expressions.entries.set(signal, entry);
            }
            var last = entry.traces[entry.traces.length - 1];
            if (trace2.stack !== (last == null ? void 0 : last.stack)) {
              entry.traces.push(trace2);
            }
          }
        }
      }
    }
    if (is_destroying_effect && old_values.has(signal)) {
      return old_values.get(signal);
    }
    if (is_derived) {
      var derived2 = (
        /** @type {Derived} */
        signal
      );
      if (is_destroying_effect) {
        var value = derived2.v;
        if ((derived2.f & CLEAN) === 0 && derived2.reactions !== null || depends_on_old_values(derived2)) {
          value = execute_derived(derived2);
        }
        old_values.set(derived2, value);
        return value;
      }
      var should_connect = (derived2.f & CONNECTED) === 0 && !untracking && active_reaction !== null && (is_updating_effect || (active_reaction.f & CONNECTED) !== 0);
      var is_new = (derived2.f & REACTION_RAN) === 0;
      if (is_dirty(derived2)) {
        if (should_connect) {
          derived2.f |= CONNECTED;
        }
        update_derived(derived2);
      }
      if (should_connect && !is_new) {
        unfreeze_derived_effects(derived2);
        reconnect(derived2);
      }
    }
    if ((_c2 = batch_values) == null ? void 0 : _c2.has(signal)) {
      return batch_values.get(signal);
    }
    if ((signal.f & ERROR_VALUE) !== 0) {
      throw signal.v;
    }
    return signal.v;
  }
  function reconnect(derived2) {
    var _a5;
    derived2.f |= CONNECTED;
    if (derived2.deps === null) return;
    for (const dep of derived2.deps) {
      ((_a5 = dep.reactions) != null ? _a5 : dep.reactions = []).push(derived2);
      if ((dep.f & DERIVED) !== 0 && (dep.f & CONNECTED) === 0) {
        unfreeze_derived_effects(
          /** @type {Derived} */
          dep
        );
        reconnect(
          /** @type {Derived} */
          dep
        );
      }
    }
  }
  function depends_on_old_values(derived2) {
    if (derived2.v === UNINITIALIZED) return true;
    if (derived2.deps === null) return false;
    for (const dep of derived2.deps) {
      if (old_values.has(dep)) {
        return true;
      }
      if ((dep.f & DERIVED) !== 0 && depends_on_old_values(
        /** @type {Derived} */
        dep
      )) {
        return true;
      }
    }
    return false;
  }
  function untrack(fn) {
    var previous_untracking = untracking;
    try {
      untracking = true;
      return fn();
    } finally {
      untracking = previous_untracking;
    }
  }
  function deep_read_state(value) {
    if (typeof value !== "object" || !value || value instanceof EventTarget) {
      return;
    }
    if (STATE_SYMBOL in value) {
      deep_read(value);
    } else if (!Array.isArray(value)) {
      for (let key2 in value) {
        const prop2 = value[key2];
        if (typeof prop2 === "object" && prop2 && STATE_SYMBOL in prop2) {
          deep_read(prop2);
        }
      }
    }
  }
  function deep_read(value, visited = /* @__PURE__ */ new Set()) {
    if (typeof value === "object" && value !== null && // We don't want to traverse DOM elements
    !(value instanceof EventTarget) && !visited.has(value)) {
      visited.add(value);
      if (value instanceof Date) {
        value.getTime();
      }
      for (let key2 in value) {
        try {
          deep_read(value[key2], visited);
        } catch (e) {
        }
      }
      const proto = get_prototype_of(value);
      if (proto !== Object.prototype && proto !== Array.prototype && proto !== Map.prototype && proto !== Set.prototype && proto !== Date.prototype) {
        const descriptors = get_descriptors(proto);
        for (let key2 in descriptors) {
          const get3 = descriptors[key2].get;
          if (get3) {
            try {
              get3.call(value);
            } catch (e) {
            }
          }
        }
      }
    }
  }

  // node_modules/svelte/src/utils.js
  var regex_return_characters = /\r/g;
  function hash(str) {
    str = str.replace(regex_return_characters, "");
    let hash2 = 5381;
    let i = str.length;
    while (i--) hash2 = (hash2 << 5) - hash2 ^ str.charCodeAt(i);
    return (hash2 >>> 0).toString(36);
  }
  var DOM_BOOLEAN_ATTRIBUTES = [
    "allowfullscreen",
    "async",
    "autofocus",
    "autoplay",
    "checked",
    "controls",
    "default",
    "disabled",
    "formnovalidate",
    "indeterminate",
    "inert",
    "ismap",
    "loop",
    "multiple",
    "muted",
    "nomodule",
    "novalidate",
    "open",
    "playsinline",
    "readonly",
    "required",
    "reversed",
    "seamless",
    "selected",
    "webkitdirectory",
    "defer",
    "disablepictureinpicture",
    "disableremoteplayback"
  ];
  var DOM_PROPERTIES = [
    ...DOM_BOOLEAN_ATTRIBUTES,
    "formNoValidate",
    "isMap",
    "noModule",
    "playsInline",
    "readOnly",
    "value",
    "volume",
    "defaultValue",
    "defaultChecked",
    "srcObject",
    "noValidate",
    "allowFullscreen",
    "disablePictureInPicture",
    "disableRemotePlayback"
  ];
  var PASSIVE_EVENTS = ["touchstart", "touchmove"];
  function is_passive_event(name) {
    return PASSIVE_EVENTS.includes(name);
  }
  var STATE_CREATION_RUNES = (
    /** @type {const} */
    [
      "$state",
      "$state.raw",
      "$derived",
      "$derived.by"
    ]
  );
  var RUNES = (
    /** @type {const} */
    [
      ...STATE_CREATION_RUNES,
      "$state.eager",
      "$state.snapshot",
      "$props",
      "$props.id",
      "$bindable",
      "$effect",
      "$effect.pre",
      "$effect.tracking",
      "$effect.root",
      "$effect.pending",
      "$inspect",
      "$inspect().with",
      "$inspect.trace",
      "$host"
    ]
  );
  function sanitize_location(location) {
    return (
      /** @type {T} */
      location == null ? void 0 : location.replace(/\//g, "/\u200B")
    );
  }

  // node_modules/svelte/src/internal/client/dom/elements/events.js
  var event_symbol = /* @__PURE__ */ Symbol("events");
  var all_registered_events = /* @__PURE__ */ new Set();
  var root_event_handles = /* @__PURE__ */ new Set();
  var last_propagated_event = null;
  function handle_event_propagation(event2) {
    var _a5, _b3;
    var handler_element = this;
    var owner_document = (
      /** @type {Node} */
      handler_element.ownerDocument
    );
    var event_name = event2.type;
    var path = ((_a5 = event2.composedPath) == null ? void 0 : _a5.call(event2)) || [];
    var current_target = (
      /** @type {null | Element} */
      path[0] || event2.target
    );
    last_propagated_event = event2;
    var path_idx = 0;
    var handled_at = last_propagated_event === event2 && event2[event_symbol];
    if (handled_at) {
      var at_idx = path.indexOf(handled_at);
      if (at_idx !== -1 && (handler_element === document || handler_element === /** @type {any} */
      window)) {
        event2[event_symbol] = handler_element;
        return;
      }
      var handler_idx = path.indexOf(handler_element);
      if (handler_idx === -1) {
        return;
      }
      if (at_idx <= handler_idx) {
        path_idx = at_idx;
      }
    }
    current_target = /** @type {Element} */
    path[path_idx] || event2.target;
    if (current_target === handler_element) return;
    define_property(event2, "currentTarget", {
      configurable: true,
      get() {
        return current_target || owner_document;
      }
    });
    var previous_reaction = active_reaction;
    var previous_effect = active_effect;
    set_active_reaction(null);
    set_active_effect(null);
    try {
      var throw_error;
      var other_errors = [];
      while (current_target !== null) {
        if (current_target === handler_element) break;
        try {
          var delegated2 = (_b3 = current_target[event_symbol]) == null ? void 0 : _b3[event_name];
          if (delegated2 != null && (!/** @type {any} */
          current_target.disabled || // DOM could've been updated already by the time this is reached, so we check this as well
          // -> the target could not have been disabled because it emits the event in the first place
          event2.target === current_target)) {
            delegated2.call(current_target, event2);
          }
        } catch (error) {
          if (throw_error) {
            other_errors.push(error);
          } else {
            throw_error = error;
          }
        }
        if (event2.cancelBubble) break;
        path_idx++;
        current_target = path_idx < path.length ? (
          /** @type {Element} */
          path[path_idx]
        ) : null;
      }
      if (throw_error) {
        for (let error of other_errors) {
          queueMicrotask(() => {
            throw error;
          });
        }
        throw throw_error;
      }
    } finally {
      event2[event_symbol] = handler_element;
      delete event2.currentTarget;
      set_active_reaction(previous_reaction);
      set_active_effect(previous_effect);
    }
  }

  // node_modules/svelte/src/internal/client/dom/reconciler.js
  var _a3;
  var policy = (
    // We gotta write it like this because after downleveling the pure comment may end up in the wrong location
    ((_a3 = globalThis == null ? void 0 : globalThis.window) == null ? void 0 : _a3.trustedTypes) && /* @__PURE__ */ globalThis.window.trustedTypes.createPolicy("svelte-trusted-html", {
      /** @param {string} html */
      createHTML: (html2) => {
        return html2;
      }
    })
  );
  function create_trusted_html(html2) {
    var _a5;
    return (
      /** @type {string} */
      (_a5 = policy == null ? void 0 : policy.createHTML(html2)) != null ? _a5 : html2
    );
  }
  function create_fragment_from_html(html2) {
    var elem = create_element("template");
    elem.innerHTML = create_trusted_html(html2.replaceAll("<!>", "<!---->"));
    return elem.content;
  }

  // node_modules/svelte/src/internal/client/dom/template.js
  function assign_nodes(start, end) {
    var effect2 = (
      /** @type {Effect} */
      active_effect
    );
    if (effect2.nodes === null) {
      effect2.nodes = { start, end, a: null, t: null };
    }
  }
  // @__NO_SIDE_EFFECTS__
  function from_html(content, flags2) {
    var is_fragment = (flags2 & TEMPLATE_FRAGMENT) !== 0;
    var use_import_node = (flags2 & TEMPLATE_USE_IMPORT_NODE) !== 0;
    var node;
    var has_start = !content.startsWith("<!>");
    return () => {
      if (hydrating) {
        assign_nodes(hydrate_node, null);
        return hydrate_node;
      }
      if (node === void 0) {
        node = create_fragment_from_html(has_start ? content : "<!>" + content);
        if (!is_fragment) node = /** @type {TemplateNode} */
        get_first_child(node);
      }
      var clone = (
        /** @type {TemplateNode} */
        use_import_node || is_firefox ? document.importNode(node, true) : node.cloneNode(true)
      );
      if (is_fragment) {
        var start = (
          /** @type {TemplateNode} */
          get_first_child(clone)
        );
        var end = (
          /** @type {TemplateNode} */
          clone.lastChild
        );
        assign_nodes(start, end);
      } else {
        assign_nodes(clone, clone);
      }
      return clone;
    };
  }
  function append(anchor, dom) {
    if (hydrating) {
      var effect2 = (
        /** @type {Effect & { nodes: EffectNodes }} */
        active_effect
      );
      if ((effect2.f & REACTION_RAN) === 0 || effect2.nodes.end === null) {
        effect2.nodes.end = hydrate_node;
      }
      hydrate_next();
      return;
    }
    if (anchor === null) {
      return;
    }
    anchor.before(
      /** @type {Node} */
      dom
    );
  }

  // node_modules/svelte/src/internal/client/render.js
  var should_intro = true;
  function set_text(text2, value) {
    var _a5, _b3;
    var str = value == null ? "" : typeof value === "object" ? `${value}` : value;
    if (str !== /** @type {any} */
    ((_b3 = text2[_a5 = TEXT_CACHE]) != null ? _b3 : text2[_a5] = text2.nodeValue)) {
      text2[TEXT_CACHE] = str;
      text2.nodeValue = `${str}`;
    }
  }
  function mount(component2, options) {
    return _mount(component2, options);
  }
  function hydrate(component2, options) {
    var _a5;
    init_operations();
    options.intro = (_a5 = options.intro) != null ? _a5 : false;
    const target = options.target;
    const was_hydrating = hydrating;
    const previous_hydrate_node = hydrate_node;
    try {
      var anchor = get_first_child(target);
      while (anchor && (anchor.nodeType !== COMMENT_NODE || /** @type {Comment} */
      anchor.data !== HYDRATION_START)) {
        anchor = get_next_sibling(anchor);
      }
      if (!anchor) {
        throw HYDRATION_ERROR;
      }
      set_hydrating(true);
      set_hydrate_node(
        /** @type {Comment} */
        anchor
      );
      const instance = _mount(component2, { ...options, anchor });
      set_hydrating(false);
      return (
        /**  @type {Exports} */
        instance
      );
    } catch (error) {
      if (error instanceof Error && error.message.split("\n").some((line) => line.startsWith("https://svelte.dev/e/"))) {
        throw error;
      }
      if (error !== HYDRATION_ERROR) {
        console.warn("Failed to hydrate: ", error);
      }
      if (options.recover === false) {
        hydration_failed();
      }
      init_operations();
      clear_text_content(target);
      set_hydrating(false);
      return mount(component2, options);
    } finally {
      set_hydrating(was_hydrating);
      set_hydrate_node(previous_hydrate_node);
    }
  }
  var listeners = /* @__PURE__ */ new Map();
  function _mount(Component, { target, anchor, props = {}, events, context, intro = true, transformError }) {
    init_operations();
    var component2 = void 0;
    var unmount2 = component_root(() => {
      var anchor_node = anchor != null ? anchor : target.appendChild(create_text());
      boundary(
        /** @type {TemplateNode} */
        anchor_node,
        {
          pending: () => {
          }
        },
        (anchor_node2) => {
          push({});
          var ctx = (
            /** @type {ComponentContext} */
            component_context
          );
          if (context) ctx.c = context;
          if (events) {
            props.$$events = events;
          }
          if (hydrating) {
            assign_nodes(
              /** @type {TemplateNode} */
              anchor_node2,
              null
            );
          }
          should_intro = intro;
          component2 = Component(anchor_node2, props) || {};
          should_intro = true;
          if (hydrating) {
            active_effect.nodes.end = hydrate_node;
            if (hydrate_node === null || hydrate_node.nodeType !== COMMENT_NODE || /** @type {Comment} */
            hydrate_node.data !== HYDRATION_END) {
              hydration_mismatch();
              throw HYDRATION_ERROR;
            }
          }
          pop();
        },
        transformError
      );
      var registered_events = /* @__PURE__ */ new Set();
      var event_handle = (events2) => {
        for (var i = 0; i < events2.length; i++) {
          var event_name = events2[i];
          if (registered_events.has(event_name)) continue;
          registered_events.add(event_name);
          var passive2 = is_passive_event(event_name);
          for (const node of [target, document]) {
            var counts = listeners.get(node);
            if (counts === void 0) {
              counts = /* @__PURE__ */ new Map();
              listeners.set(node, counts);
            }
            var count = counts.get(event_name);
            if (count === void 0) {
              node.addEventListener(event_name, handle_event_propagation, { passive: passive2 });
              counts.set(event_name, 1);
            } else {
              counts.set(event_name, count + 1);
            }
          }
        }
      };
      event_handle(array_from(all_registered_events));
      root_event_handles.add(event_handle);
      return () => {
        var _a5;
        for (var event_name of registered_events) {
          for (const node of [target, document]) {
            var counts = (
              /** @type {Map<string, number>} */
              listeners.get(node)
            );
            var count = (
              /** @type {number} */
              counts.get(event_name)
            );
            if (--count == 0) {
              node.removeEventListener(event_name, handle_event_propagation);
              counts.delete(event_name);
              if (counts.size === 0) {
                listeners.delete(node);
              }
            } else {
              counts.set(event_name, count);
            }
          }
        }
        root_event_handles.delete(event_handle);
        if (anchor_node !== anchor) {
          (_a5 = anchor_node.parentNode) == null ? void 0 : _a5.removeChild(anchor_node);
        }
      };
    });
    mounted_components.set(component2, unmount2);
    return component2;
  }
  var mounted_components = /* @__PURE__ */ new WeakMap();
  function unmount(component2, options) {
    const fn = mounted_components.get(component2);
    if (fn) {
      mounted_components.delete(component2);
      return fn(options);
    }
    if (dev_fallback_default) {
      if (STATE_SYMBOL in component2) {
        state_proxy_unmount();
      } else {
        lifecycle_double_unmount();
      }
    }
    return Promise.resolve();
  }

  // node_modules/svelte/src/internal/client/dom/blocks/branches.js
  var _batches, _onscreen, _offscreen, _outroing, _transition, _commit, _discard;
  var BranchManager = class {
    /**
     * @param {TemplateNode} anchor
     * @param {boolean} transition
     */
    constructor(anchor, transition2 = true) {
      /** @type {TemplateNode} */
      __publicField(this, "anchor");
      /** @type {Map<Batch, Key>} */
      __privateAdd(this, _batches, /* @__PURE__ */ new Map());
      /**
       * Map of keys to effects that are currently rendered in the DOM.
       * These effects are visible and actively part of the document tree.
       * Example:
       * ```
       * {#if condition}
       * 	foo
       * {:else}
       * 	bar
       * {/if}
       * ```
       * Can result in the entries `true->Effect` and `false->Effect`
       * @type {Map<Key, Effect>}
       */
      __privateAdd(this, _onscreen, /* @__PURE__ */ new Map());
      /**
       * Similar to #onscreen with respect to the keys, but contains branches that are not yet
       * in the DOM, because their insertion is deferred.
       * @type {Map<Key, Branch>}
       */
      __privateAdd(this, _offscreen, /* @__PURE__ */ new Map());
      /**
       * Keys of effects that are currently outroing
       * @type {Set<Key>}
       */
      __privateAdd(this, _outroing, /* @__PURE__ */ new Set());
      /**
       * Whether to pause (i.e. outro) on change, or destroy immediately.
       * This is necessary for `<svelte:element>`
       */
      __privateAdd(this, _transition, true);
      /**
       * @param {Batch} batch
       */
      __privateAdd(this, _commit, (batch) => {
        if (!__privateGet(this, _batches).has(batch)) return;
        var key2 = (
          /** @type {Key} */
          __privateGet(this, _batches).get(batch)
        );
        var onscreen = __privateGet(this, _onscreen).get(key2);
        if (onscreen) {
          resume_effect(onscreen);
          __privateGet(this, _outroing).delete(key2);
        } else {
          var offscreen = __privateGet(this, _offscreen).get(key2);
          if (offscreen) {
            resume_effect(offscreen.effect);
            __privateGet(this, _onscreen).set(key2, offscreen.effect);
            __privateGet(this, _offscreen).delete(key2);
            if (dev_fallback_default) {
              offscreen.fragment.lastChild[HMR_ANCHOR] = this.anchor;
            }
            offscreen.fragment.lastChild.remove();
            this.anchor.before(offscreen.fragment);
            onscreen = offscreen.effect;
          }
        }
        for (const [b, k] of __privateGet(this, _batches)) {
          __privateGet(this, _batches).delete(b);
          if (b === batch) {
            break;
          }
          const offscreen2 = __privateGet(this, _offscreen).get(k);
          if (offscreen2) {
            destroy_effect(offscreen2.effect);
            __privateGet(this, _offscreen).delete(k);
          }
        }
        for (const [k, effect2] of __privateGet(this, _onscreen)) {
          if (k === key2 || __privateGet(this, _outroing).has(k)) continue;
          const on_destroy = () => {
            const keys = Array.from(__privateGet(this, _batches).values());
            if (keys.includes(k)) {
              var fragment = document.createDocumentFragment();
              move_effect(effect2, fragment);
              fragment.append(create_text());
              __privateGet(this, _offscreen).set(k, { effect: effect2, fragment });
            } else {
              destroy_effect(effect2);
            }
            __privateGet(this, _outroing).delete(k);
            __privateGet(this, _onscreen).delete(k);
          };
          if (__privateGet(this, _transition) || !onscreen) {
            __privateGet(this, _outroing).add(k);
            pause_effect(effect2, on_destroy, false);
          } else {
            on_destroy();
          }
        }
      });
      /**
       * @param {Batch} batch
       */
      __privateAdd(this, _discard, (batch) => {
        __privateGet(this, _batches).delete(batch);
        const keys = Array.from(__privateGet(this, _batches).values());
        for (const [k, branch2] of __privateGet(this, _offscreen)) {
          if (!keys.includes(k)) {
            destroy_effect(branch2.effect);
            __privateGet(this, _offscreen).delete(k);
          }
        }
      });
      this.anchor = anchor;
      __privateSet(this, _transition, transition2);
    }
    /**
     *
     * @param {any} key
     * @param {null | ((target: TemplateNode) => void)} fn
     */
    ensure(key2, fn) {
      var batch = (
        /** @type {Batch} */
        current_batch
      );
      var defer = should_defer_append();
      if (fn && !__privateGet(this, _onscreen).has(key2) && !__privateGet(this, _offscreen).has(key2)) {
        if (defer) {
          var fragment = document.createDocumentFragment();
          var target = create_text();
          fragment.append(target);
          __privateGet(this, _offscreen).set(key2, {
            effect: branch(() => fn(target)),
            fragment
          });
        } else {
          __privateGet(this, _onscreen).set(
            key2,
            branch(() => fn(this.anchor))
          );
        }
      }
      __privateGet(this, _batches).set(batch, key2);
      if (defer) {
        for (const [k, effect2] of __privateGet(this, _onscreen)) {
          if (k === key2) {
            batch.unskip_effect(effect2);
          } else {
            batch.skip_effect(effect2);
          }
        }
        for (const [k, branch2] of __privateGet(this, _offscreen)) {
          if (k === key2) {
            batch.unskip_effect(branch2.effect);
          } else {
            batch.skip_effect(branch2.effect);
          }
        }
        batch.oncommit(__privateGet(this, _commit));
        batch.ondiscard(__privateGet(this, _discard));
      } else {
        if (hydrating) {
          this.anchor = hydrate_node;
        }
        __privateGet(this, _commit).call(this, batch);
      }
    }
  };
  _batches = new WeakMap();
  _onscreen = new WeakMap();
  _offscreen = new WeakMap();
  _outroing = new WeakMap();
  _transition = new WeakMap();
  _commit = new WeakMap();
  _discard = new WeakMap();

  // node_modules/svelte/src/internal/client/dom/blocks/if.js
  function if_block(node, fn, elseif = false) {
    var marker;
    if (hydrating) {
      marker = hydrate_node;
      hydrate_next();
    }
    var branches = new BranchManager(node);
    var flags2 = elseif ? EFFECT_TRANSPARENT : 0;
    function update_branch(key2, fn2) {
      if (hydrating) {
        var data = read_hydration_instruction(
          /** @type {TemplateNode} */
          marker
        );
        if (key2 !== parseInt(data.substring(1))) {
          var anchor = skip_nodes();
          set_hydrate_node(anchor);
          branches.anchor = anchor;
          set_hydrating(false);
          branches.ensure(key2, fn2);
          set_hydrating(true);
          return;
        }
      }
      branches.ensure(key2, fn2);
    }
    block(() => {
      var has_branch = false;
      fn((fn2, key2 = 0) => {
        has_branch = true;
        update_branch(key2, fn2);
      });
      if (!has_branch) {
        update_branch(-1, null);
      }
    }, flags2);
  }

  // node_modules/svelte/src/internal/client/dom/blocks/css-props.js
  function css_props(element2, get_styles) {
    if (hydrating) {
      set_hydrate_node(get_first_child(element2));
    }
    render_effect(() => {
      var styles = get_styles();
      for (var key2 in styles) {
        var value = styles[key2];
        if (value) {
          element2.style.setProperty(key2, value);
        } else {
          element2.style.removeProperty(key2);
        }
      }
    });
  }

  // node_modules/svelte/src/internal/client/dom/blocks/html.js
  function check_hash(element2, server_hash, value) {
    var _a5, _b3;
    if (!server_hash || server_hash === hash(String(value != null ? value : ""))) return;
    let location;
    const loc = (_a5 = element2.__svelte_meta) == null ? void 0 : _a5.loc;
    if (loc) {
      location = `near ${loc.file}:${loc.line}:${loc.column}`;
    } else if ((_b3 = dev_current_component_function) == null ? void 0 : _b3[FILENAME]) {
      location = `in ${dev_current_component_function[FILENAME]}`;
    }
    hydration_html_changed(sanitize_location(location));
  }
  function html(node, get_value, is_controlled = false, svg = false, mathml = false, skip_warning = false) {
    var anchor = node;
    var value = "";
    if (is_controlled) {
      var parent_node = (
        /** @type {Element} */
        node
      );
      if (hydrating) {
        anchor = set_hydrate_node(get_first_child(parent_node));
      }
    }
    template_effect(() => {
      var _a5;
      var effect2 = (
        /** @type {Effect} */
        active_effect
      );
      if (value === (value = (_a5 = get_value()) != null ? _a5 : "")) {
        if (hydrating) hydrate_next();
        return;
      }
      if (is_controlled && !hydrating) {
        effect2.nodes = null;
        parent_node.innerHTML = /** @type {string} */
        value;
        if (value !== "") {
          assign_nodes(
            /** @type {TemplateNode} */
            get_first_child(parent_node),
            /** @type {TemplateNode} */
            parent_node.lastChild
          );
        }
        return;
      }
      if (effect2.nodes !== null) {
        remove_effect_dom(
          effect2.nodes.start,
          /** @type {TemplateNode} */
          effect2.nodes.end
        );
        effect2.nodes = null;
      }
      if (value === "") return;
      if (hydrating) {
        var hash2 = (
          /** @type {Comment} */
          hydrate_node.data
        );
        var next2 = hydrate_next();
        var last = next2;
        while (next2 !== null && (next2.nodeType !== COMMENT_NODE || /** @type {Comment} */
        next2.data !== "")) {
          last = next2;
          next2 = get_next_sibling(next2);
        }
        if (next2 === null) {
          hydration_mismatch();
          throw HYDRATION_ERROR;
        }
        if (dev_fallback_default && !skip_warning) {
          check_hash(
            /** @type {Element} */
            next2.parentNode,
            hash2,
            value
          );
        }
        assign_nodes(hydrate_node, last);
        anchor = set_hydrate_node(next2);
        return;
      }
      var ns = svg ? NAMESPACE_SVG : mathml ? NAMESPACE_MATHML : void 0;
      var wrapper = (
        /** @type {HTMLTemplateElement | SVGElement | MathMLElement} */
        create_element(svg ? "svg" : mathml ? "math" : "template", ns)
      );
      wrapper.innerHTML = /** @type {any} */
      value;
      var node2 = svg || mathml ? wrapper : (
        /** @type {HTMLTemplateElement} */
        wrapper.content
      );
      assign_nodes(
        /** @type {TemplateNode} */
        get_first_child(node2),
        /** @type {TemplateNode} */
        node2.lastChild
      );
      if (svg || mathml) {
        while (get_first_child(node2)) {
          anchor.before(
            /** @type {TemplateNode} */
            get_first_child(node2)
          );
        }
      } else {
        anchor.before(node2);
      }
    });
  }

  // node_modules/svelte/src/internal/client/dom/blocks/slot.js
  function slot(anchor, $$props, name, slot_props, fallback_fn) {
    var _a5;
    if (hydrating) {
      hydrate_next();
    }
    var slot_fn = (_a5 = $$props.$$slots) == null ? void 0 : _a5[name];
    var is_interop = false;
    if (slot_fn === true) {
      slot_fn = $$props[name === "default" ? "children" : name];
      is_interop = true;
    }
    if (slot_fn === void 0) {
      if (fallback_fn !== null) {
        fallback_fn(anchor);
      }
    } else {
      slot_fn(anchor, is_interop ? () => slot_props : slot_props);
    }
  }

  // node_modules/svelte/src/internal/shared/attributes.js
  var whitespace = [..." 	\n\r\f\xA0\v\uFEFF"];
  function to_class(value, hash2, directives) {
    var classname = value == null ? "" : "" + value;
    if (hash2) {
      classname = classname ? classname + " " + hash2 : hash2;
    }
    if (directives) {
      for (var key2 of Object.keys(directives)) {
        if (directives[key2]) {
          classname = classname ? classname + " " + key2 : key2;
        } else if (classname.length) {
          var len = key2.length;
          var a = 0;
          while ((a = classname.indexOf(key2, a)) >= 0) {
            var b = a + len;
            if ((a === 0 || whitespace.includes(classname[a - 1])) && (b === classname.length || whitespace.includes(classname[b]))) {
              classname = (a === 0 ? "" : classname.substring(0, a)) + classname.substring(b + 1);
            } else {
              a = b;
            }
          }
        }
      }
    }
    return classname === "" ? null : classname;
  }

  // node_modules/svelte/src/internal/client/dom/elements/class.js
  function set_class(dom, is_html, value, hash2, prev_classes, next_classes) {
    var prev = (
      /** @type {any} */
      dom[CLASS_CACHE]
    );
    if (hydrating || prev !== value || prev === void 0) {
      var next_class_name = to_class(value, hash2, next_classes);
      if (!hydrating || next_class_name !== dom.getAttribute("class")) {
        if (next_class_name == null) {
          dom.removeAttribute("class");
        } else if (is_html) {
          dom.className = next_class_name;
        } else {
          dom.setAttribute("class", next_class_name);
        }
      }
      dom[CLASS_CACHE] = value;
    } else if (next_classes && prev_classes !== next_classes) {
      for (var key2 in next_classes) {
        var is_present = !!next_classes[key2];
        if (prev_classes == null || is_present !== !!prev_classes[key2]) {
          dom.classList.toggle(key2, is_present);
        }
      }
    }
    return next_classes;
  }

  // node_modules/svelte/src/internal/client/dom/elements/attributes.js
  var IS_CUSTOM_ELEMENT = /* @__PURE__ */ Symbol("is custom element");
  var IS_HTML = /* @__PURE__ */ Symbol("is html");
  var LINK_TAG = IS_XHTML ? "link" : "LINK";
  function set_attribute2(element2, attribute, value, skip_warning) {
    var attributes = get_attributes(element2);
    if (hydrating) {
      attributes[attribute] = element2.getAttribute(attribute);
      if (attribute === "src" || attribute === "srcset" || attribute === "href" && element2.nodeName === LINK_TAG) {
        if (!skip_warning) {
          check_src_in_dev_hydration(element2, attribute, value != null ? value : "");
        }
        return;
      }
    }
    if (attributes[attribute] === (attributes[attribute] = value)) return;
    if (attribute === "loading") {
      element2[LOADING_ATTR_SYMBOL] = value;
    }
    if (value == null) {
      element2.removeAttribute(attribute);
    } else if (typeof value !== "string" && get_setters(element2).includes(attribute)) {
      element2[attribute] = value;
    } else {
      element2.setAttribute(attribute, value);
    }
  }
  function get_attributes(element2) {
    var _a5, _b3;
    return (
      /** @type {Record<string | symbol, unknown>} **/
      /** @type {any} */
      (_b3 = element2[_a5 = ATTRIBUTES_CACHE]) != null ? _b3 : element2[_a5] = {
        [IS_CUSTOM_ELEMENT]: element2.nodeName.includes("-"),
        [IS_HTML]: element2.namespaceURI === NAMESPACE_HTML
      }
    );
  }
  var setters_cache = /* @__PURE__ */ new Map();
  function get_setters(element2) {
    var cache_key = element2.getAttribute("is") || element2.nodeName;
    var setters = setters_cache.get(cache_key);
    if (setters) return setters;
    setters_cache.set(cache_key, setters = []);
    var descriptors;
    var proto = element2;
    var element_proto = Element.prototype;
    while (element_proto !== proto) {
      descriptors = get_descriptors(proto);
      for (var key2 in descriptors) {
        if (descriptors[key2].set && // better safe than sorry, we don't want spread attributes to mess with HTML content
        key2 !== "innerHTML" && key2 !== "textContent" && key2 !== "innerText") {
          setters.push(key2);
        }
      }
      proto = get_prototype_of(proto);
    }
    return setters;
  }
  function check_src_in_dev_hydration(element2, attribute, value) {
    var _a5;
    if (!dev_fallback_default) return;
    if (attribute === "srcset" && srcset_url_equal(element2, value)) return;
    if (src_url_equal((_a5 = element2.getAttribute(attribute)) != null ? _a5 : "", value)) return;
    hydration_attribute_changed(
      attribute,
      element2.outerHTML.replace(element2.innerHTML, element2.innerHTML && "..."),
      String(value)
    );
  }
  function src_url_equal(element_src, url) {
    if (element_src === url) return true;
    return new URL(element_src, document.baseURI).href === new URL(url, document.baseURI).href;
  }
  function split_srcset(srcset) {
    return srcset.split(",").map((src) => src.trim().split(" ").filter(Boolean));
  }
  function srcset_url_equal(element2, srcset) {
    var element_urls = split_srcset(element2.srcset);
    var urls = split_srcset(srcset);
    return urls.length === element_urls.length && urls.every(
      ([url, width], i) => width === element_urls[i][1] && // We need to test both ways because Vite will create an a full URL with
      // `new URL(asset, import.meta.url).href` for the client when `base: './'`, and the
      // relative URLs inside srcset are not automatically resolved to absolute URLs by
      // browsers (in contrast to img.src). This means both SSR and DOM code could
      // contain relative or absolute URLs.
      (src_url_equal(element_urls[i][0], url) || src_url_equal(url, element_urls[i][0]))
    );
  }

  // node_modules/svelte/src/internal/client/dom/legacy/lifecycle.js
  function init(immutable = false) {
    const context = (
      /** @type {ComponentContextLegacy} */
      component_context
    );
    const callbacks = context.l.u;
    if (!callbacks) return;
    let props = () => deep_read_state(context.s);
    if (immutable) {
      let version = 0;
      let prev = (
        /** @type {Record<string, any>} */
        {}
      );
      const d = derived(() => {
        let changed = false;
        const props2 = context.s;
        for (const key2 in props2) {
          if (props2[key2] !== prev[key2]) {
            prev[key2] = props2[key2];
            changed = true;
          }
        }
        if (changed) version++;
        return version;
      });
      props = () => get2(d);
    }
    if (callbacks.b.length) {
      user_pre_effect(() => {
        observe_all(context, props);
        run_all(callbacks.b);
      });
    }
    user_effect(() => {
      const fns = untrack(() => callbacks.m.map(run));
      return () => {
        for (const fn of fns) {
          if (typeof fn === "function") {
            fn();
          }
        }
      };
    });
    if (callbacks.a.length) {
      user_effect(() => {
        observe_all(context, props);
        run_all(callbacks.a);
      });
    }
  }
  function observe_all(context, props) {
    if (context.l.s) {
      for (const signal of context.l.s) get2(signal);
    }
    props();
  }

  // node_modules/svelte/src/internal/client/reactivity/props.js
  function prop(props, key2, flags2, fallback3) {
    var _a5, _b3;
    var runes = !legacy_mode_flag || (flags2 & PROPS_IS_RUNES) !== 0;
    var bindable = (flags2 & PROPS_IS_BINDABLE) !== 0;
    var lazy = (flags2 & PROPS_IS_LAZY_INITIAL) !== 0;
    var fallback_value = (
      /** @type {V} */
      fallback3
    );
    var fallback_dirty = true;
    var fallback_signal = (
      /** @type {Derived<V> | undefined} */
      void 0
    );
    var get_fallback = () => {
      if (lazy && runes) {
        fallback_signal != null ? fallback_signal : fallback_signal = derived(
          /** @type {() => V} */
          fallback3
        );
        return get2(fallback_signal);
      }
      if (fallback_dirty) {
        fallback_dirty = false;
        fallback_value = lazy ? untrack(
          /** @type {() => V} */
          fallback3
        ) : (
          /** @type {V} */
          fallback3
        );
      }
      return fallback_value;
    };
    let setter;
    if (bindable) {
      var is_entry_props = STATE_SYMBOL in props || LEGACY_PROPS in props;
      setter = (_b3 = (_a5 = get_descriptor(props, key2)) == null ? void 0 : _a5.set) != null ? _b3 : is_entry_props && key2 in props ? (v) => props[key2] = v : void 0;
    }
    var initial_value;
    var is_store_sub = false;
    if (bindable) {
      [initial_value, is_store_sub] = capture_store_binding(() => (
        /** @type {V} */
        props[key2]
      ));
    } else {
      initial_value = /** @type {V} */
      props[key2];
    }
    if (initial_value === void 0 && fallback3 !== void 0) {
      initial_value = get_fallback();
      if (setter) {
        if (runes) props_invalid_value(key2);
        setter(initial_value);
      }
    }
    var getter;
    if (runes) {
      getter = () => {
        var value = (
          /** @type {V} */
          props[key2]
        );
        if (value === void 0) return get_fallback();
        fallback_dirty = true;
        return value;
      };
    } else {
      getter = () => {
        var value = (
          /** @type {V} */
          props[key2]
        );
        if (value !== void 0) {
          fallback_value = /** @type {V} */
          void 0;
        }
        return value === void 0 ? fallback_value : value;
      };
    }
    if (runes && (flags2 & PROPS_IS_UPDATED) === 0) {
      return getter;
    }
    if (setter) {
      var legacy_parent = props.$$legacy;
      return (
        /** @type {() => V} */
        (function(value, mutation) {
          if (arguments.length > 0) {
            if (!runes || !mutation || legacy_parent || is_store_sub) {
              setter(mutation ? getter() : value);
            }
            return value;
          }
          return getter();
        })
      );
    }
    var overridden = false;
    var d = ((flags2 & PROPS_IS_IMMUTABLE) !== 0 ? derived : derived_safe_equal)(() => {
      overridden = false;
      return getter();
    });
    if (dev_fallback_default) {
      d.label = key2;
    }
    if (bindable) get2(d);
    var parent_effect = (
      /** @type {Effect} */
      active_effect
    );
    return (
      /** @type {() => V} */
      (function(value, mutation) {
        if (arguments.length > 0) {
          const new_value = mutation ? get2(d) : runes && bindable ? proxy(value) : value;
          set(d, new_value);
          overridden = true;
          if (fallback_value !== void 0) {
            fallback_value = new_value;
          }
          return value;
        }
        if (is_destroying_effect && overridden || (parent_effect.f & DESTROYED) !== 0) {
          return d.v;
        }
        return get2(d);
      })
    );
  }

  // node_modules/svelte/src/legacy/legacy-client.js
  function createClassComponent(options) {
    return new Svelte4Component(options);
  }
  var _events, _instance;
  var Svelte4Component = class {
    /**
     * @param {ComponentConstructorOptions & {
     *  component: any;
     * }} options
     */
    constructor(options) {
      /** @type {any} */
      __privateAdd(this, _events);
      /** @type {Record<string, any>} */
      __privateAdd(this, _instance);
      var _a5, _b3;
      var sources = /* @__PURE__ */ new Map();
      var add_source = (key2, value) => {
        var s = mutable_source(value, false, false);
        sources.set(key2, s);
        return s;
      };
      const props = new Proxy(
        { ...options.props || {}, $$events: {} },
        {
          get(target, prop2) {
            var _a6;
            return get2((_a6 = sources.get(prop2)) != null ? _a6 : add_source(prop2, Reflect.get(target, prop2)));
          },
          has(target, prop2) {
            var _a6;
            if (prop2 === LEGACY_PROPS) return true;
            get2((_a6 = sources.get(prop2)) != null ? _a6 : add_source(prop2, Reflect.get(target, prop2)));
            return Reflect.has(target, prop2);
          },
          set(target, prop2, value) {
            var _a6;
            set((_a6 = sources.get(prop2)) != null ? _a6 : add_source(prop2, value), value);
            return Reflect.set(target, prop2, value);
          }
        }
      );
      __privateSet(this, _instance, (options.hydrate ? hydrate : mount)(options.component, {
        target: options.target,
        anchor: options.anchor,
        props,
        context: options.context,
        intro: (_a5 = options.intro) != null ? _a5 : false,
        recover: options.recover,
        transformError: options.transformError
      }));
      if (!async_mode_flag && (!((_b3 = options == null ? void 0 : options.props) == null ? void 0 : _b3.$$host) || options.sync === false)) {
        flushSync();
      }
      __privateSet(this, _events, props.$$events);
      for (const key2 of Object.keys(__privateGet(this, _instance))) {
        if (key2 === "$set" || key2 === "$destroy" || key2 === "$on") continue;
        define_property(this, key2, {
          get() {
            return __privateGet(this, _instance)[key2];
          },
          /** @param {any} value */
          set(value) {
            __privateGet(this, _instance)[key2] = value;
          },
          enumerable: true
        });
      }
      __privateGet(this, _instance).$set = /** @param {Record<string, any>} next */
      (next2) => {
        Object.assign(props, next2);
      };
      __privateGet(this, _instance).$destroy = () => {
        unmount(__privateGet(this, _instance));
      };
    }
    /** @param {Record<string, any>} props */
    $set(props) {
      __privateGet(this, _instance).$set(props);
    }
    /**
     * @param {string} event
     * @param {(...args: any[]) => any} callback
     * @returns {any}
     */
    $on(event2, callback) {
      __privateGet(this, _events)[event2] = __privateGet(this, _events)[event2] || [];
      const cb = (...args) => callback.call(this, ...args);
      __privateGet(this, _events)[event2].push(cb);
      return () => {
        __privateGet(this, _events)[event2] = __privateGet(this, _events)[event2].filter(
          /** @param {any} fn */
          (fn) => fn !== cb
        );
      };
    }
    $destroy() {
      __privateGet(this, _instance).$destroy();
    }
  };
  _events = new WeakMap();
  _instance = new WeakMap();

  // node_modules/svelte/src/internal/client/dom/elements/custom-element.js
  var SvelteElement;
  if (typeof HTMLElement === "function") {
    SvelteElement = class extends HTMLElement {
      /**
       * @param {*} $$componentCtor
       * @param {*} $$slots
       * @param {ShadowRootInit | undefined} shadow_root_init
       */
      constructor($$componentCtor, $$slots, shadow_root_init) {
        super();
        /** The Svelte component constructor */
        __publicField(this, "$$ctor");
        /** Slots */
        __publicField(this, "$$s");
        /** @type {any} The Svelte component instance */
        __publicField(this, "$$c");
        /** Whether or not the custom element is connected */
        __publicField(this, "$$cn", false);
        /** @type {Record<string, any>} Component props data */
        __publicField(this, "$$d", {});
        /** `true` if currently in the process of reflecting component props back to attributes */
        __publicField(this, "$$r", false);
        /** @type {Record<string, CustomElementPropDefinition>} Props definition (name, reflected, type etc) */
        __publicField(this, "$$p_d", {});
        /** @type {Record<string, EventListenerOrEventListenerObject[]>} Event listeners */
        __publicField(this, "$$l", {});
        /** @type {Map<EventListenerOrEventListenerObject, Function>} Event listener unsubscribe functions */
        __publicField(this, "$$l_u", /* @__PURE__ */ new Map());
        /** @type {any} The managed render effect for reflecting attributes */
        __publicField(this, "$$me");
        /** @type {ShadowRoot | null} The ShadowRoot of the custom element */
        __publicField(this, "$$shadowRoot", null);
        this.$$ctor = $$componentCtor;
        this.$$s = $$slots;
        if (shadow_root_init) {
          this.$$shadowRoot = this.attachShadow(shadow_root_init);
        }
      }
      /**
       * @param {string} type
       * @param {EventListenerOrEventListenerObject} listener
       * @param {boolean | AddEventListenerOptions} [options]
       */
      addEventListener(type, listener, options) {
        this.$$l[type] = this.$$l[type] || [];
        this.$$l[type].push(listener);
        if (this.$$c) {
          const unsub = this.$$c.$on(type, listener);
          this.$$l_u.set(listener, unsub);
        }
        super.addEventListener(type, listener, options);
      }
      /**
       * @param {string} type
       * @param {EventListenerOrEventListenerObject} listener
       * @param {boolean | AddEventListenerOptions} [options]
       */
      removeEventListener(type, listener, options) {
        super.removeEventListener(type, listener, options);
        if (this.$$c) {
          const unsub = this.$$l_u.get(listener);
          if (unsub) {
            unsub();
            this.$$l_u.delete(listener);
          }
        }
      }
      async connectedCallback() {
        this.$$cn = true;
        if (!this.$$c) {
          let create_slot = function(name) {
            return (anchor) => {
              const slot2 = create_element("slot");
              if (name !== "default") slot2.name = name;
              append(anchor, slot2);
            };
          };
          await Promise.resolve();
          if (!this.$$cn || this.$$c) {
            return;
          }
          const $$slots = {};
          const existing_slots = get_custom_elements_slots(this);
          for (const name of this.$$s) {
            if (name in existing_slots) {
              if (name === "default" && !this.$$d.children) {
                this.$$d.children = create_slot(name);
                $$slots.default = true;
              } else {
                $$slots[name] = create_slot(name);
              }
            }
          }
          for (const attribute of this.attributes) {
            const name = this.$$g_p(attribute.name);
            if (!(name in this.$$d)) {
              this.$$d[name] = get_custom_element_value(name, attribute.value, this.$$p_d, "toProp");
            }
          }
          for (const key2 in this.$$p_d) {
            if (!(key2 in this.$$d) && this[key2] !== void 0) {
              this.$$d[key2] = this[key2];
              delete this[key2];
            }
          }
          this.$$c = createClassComponent({
            component: this.$$ctor,
            target: this.$$shadowRoot || this,
            props: {
              ...this.$$d,
              $$slots,
              $$host: this
            }
          });
          this.$$me = effect_root(() => {
            render_effect(() => {
              var _a5;
              this.$$r = true;
              for (const key2 of object_keys(this.$$c)) {
                if (!((_a5 = this.$$p_d[key2]) == null ? void 0 : _a5.reflect)) continue;
                this.$$d[key2] = this.$$c[key2];
                const attribute_value = get_custom_element_value(
                  key2,
                  this.$$d[key2],
                  this.$$p_d,
                  "toAttribute"
                );
                if (attribute_value == null) {
                  this.removeAttribute(this.$$p_d[key2].attribute || key2);
                } else {
                  this.setAttribute(this.$$p_d[key2].attribute || key2, attribute_value);
                }
              }
              this.$$r = false;
            });
          });
          for (const type in this.$$l) {
            for (const listener of this.$$l[type]) {
              const unsub = this.$$c.$on(type, listener);
              this.$$l_u.set(listener, unsub);
            }
          }
          this.$$l = {};
        }
      }
      // We don't need this when working within Svelte code, but for compatibility of people using this outside of Svelte
      // and setting attributes through setAttribute etc, this is helpful
      /**
       * @param {string} attr
       * @param {string} _oldValue
       * @param {string} newValue
       */
      attributeChangedCallback(attr2, _oldValue, newValue) {
        var _a5;
        if (this.$$r) return;
        attr2 = this.$$g_p(attr2);
        this.$$d[attr2] = get_custom_element_value(attr2, newValue, this.$$p_d, "toProp");
        (_a5 = this.$$c) == null ? void 0 : _a5.$set({ [attr2]: this.$$d[attr2] });
      }
      disconnectedCallback() {
        this.$$cn = false;
        Promise.resolve().then(() => {
          if (!this.$$cn && this.$$c) {
            this.$$c.$destroy();
            this.$$me();
            this.$$c = void 0;
          }
        });
      }
      /**
       * @param {string} attribute_name
       */
      $$g_p(attribute_name) {
        return object_keys(this.$$p_d).find(
          (key2) => this.$$p_d[key2].attribute === attribute_name || !this.$$p_d[key2].attribute && key2.toLowerCase() === attribute_name
        ) || attribute_name;
      }
    };
  }
  function get_custom_element_value(prop2, value, props_definition, transform) {
    var _a5;
    const type = (_a5 = props_definition[prop2]) == null ? void 0 : _a5.type;
    value = type === "Boolean" && typeof value !== "boolean" ? value != null : value;
    if (!transform || !props_definition[prop2]) {
      return value;
    } else if (transform === "toAttribute") {
      switch (type) {
        case "Object":
        case "Array":
          return value == null ? null : JSON.stringify(value);
        case "Boolean":
          return value ? "" : null;
        case "Number":
          return value == null ? null : value;
        default:
          return value;
      }
    } else {
      switch (type) {
        case "Object":
        case "Array":
          return value && JSON.parse(value);
        case "Boolean":
          return value;
        // conversion already handled above
        case "Number":
          return value != null ? +value : value;
        default:
          return value;
      }
    }
  }
  function get_custom_elements_slots(element2) {
    const result = {};
    element2.childNodes.forEach((node) => {
      result[
        /** @type {Element} node */
        node.slot || "default"
      ] = true;
    });
    return result;
  }

  // node_modules/svelte/src/index-client.js
  if (dev_fallback_default) {
    let throw_rune_error = function(rune) {
      if (!(rune in globalThis)) {
        let value;
        Object.defineProperty(globalThis, rune, {
          configurable: true,
          // eslint-disable-next-line getter-return
          get: () => {
            if (value !== void 0) {
              return value;
            }
            rune_outside_svelte(rune);
          },
          set: (v) => {
            value = v;
          }
        });
      }
    };
    throw_rune_error("$state");
    throw_rune_error("$effect");
    throw_rune_error("$derived");
    throw_rune_error("$inspect");
    throw_rune_error("$props");
    throw_rune_error("$bindable");
  }
  function onMount(fn) {
    if (component_context === null) {
      lifecycle_outside_component("onMount");
    }
    if (legacy_mode_flag && component_context.l !== null) {
      init_update_callbacks(component_context).m.push(fn);
    } else {
      user_effect(() => {
        const cleanup = untrack(fn);
        if (typeof cleanup === "function") return (
          /** @type {() => void} */
          cleanup
        );
      });
    }
  }
  function init_update_callbacks(context) {
    var _a5;
    var l = (
      /** @type {ComponentContextLegacy} */
      context.l
    );
    return (_a5 = l.u) != null ? _a5 : l.u = { a: [], b: [], m: [] };
  }

  // node_modules/svelte/src/version.js
  var PUBLIC_VERSION = "5";

  // node_modules/svelte/src/internal/disclose-version.js
  var _a4, _b2, _c;
  if (typeof window !== "undefined") {
    ((_c = (_b2 = (_a4 = window.__svelte) != null ? _a4 : window.__svelte = {}).v) != null ? _c : _b2.v = /* @__PURE__ */ new Set()).add(PUBLIC_VERSION);
  }

  // node_modules/svelte/src/internal/flags/legacy.js
  enable_legacy_mode_flag();

  // ts/lib/tslib/runtime-require.ts
  var runtimePackages = {};
  var prohibit = () => false;
  function registerPackageRaw(name, entries) {
    runtimePackages[name] = entries;
  }
  function registerPackage(name, entries, deprecation) {
    const pack = deprecation ? new Proxy(entries, {
      set: prohibit,
      defineProperty: prohibit,
      deleteProperty: prohibit,
      get: (target, name2) => {
        if (name2 in deprecation) {
          console.log(`anki: ${name2} is deprecated: ${deprecation[name2]}`);
        }
        return target[name2];
      }
    }) : entries;
    registerPackageRaw(name, pack);
  }
  function require2(name) {
    if (!(name in runtimePackages)) {
      throw new Error(`Cannot require "${name}" at runtime.`);
    } else {
      return runtimePackages[name];
    }
  }
  function listPackages() {
    return Object.keys(runtimePackages);
  }
  function hasPackages(...names) {
    for (const name of names) {
      if (!(name in runtimePackages)) {
        return false;
      }
    }
    return true;
  }
  Object.assign(globalThis, { require: require2 });
  registerPackage("anki/packages", {
    // We also register require here, so add-ons can have a type-save variant of require (TODO, see AnkiPackages above)
    require: require2,
    listPackages,
    hasPackages
  });

  // ts/lib/tslib/bridgecommand.ts
  function bridgeLink(command, label) {
    return `<a href="javascript:bridgeCommand('${command}')">${label}</a>`;
  }
  function bridgeCommand(command, callback) {
    window.bridgeCommand(command, callback);
  }
  registerPackage("anki/bridgecommand", {
    bridgeCommand
  });

  // ts/lib/components/Col.svelte
  var root = from_html(`<div><!></div>`);
  function Col($$anchor, $$props) {
    let className = prop($$props, "class", 8, "");
    let breakpoint = prop($$props, "breakpoint", 8, "xs");
    var div = root();
    let classes;
    var node = child(div);
    slot(node, $$props, "default", {}, null);
    reset(div);
    template_effect(() => {
      var _a5;
      return classes = set_class(div, 1, `col ${(_a5 = className()) != null ? _a5 : ""}`, "svelte-1m4lp25", classes, {
        "col-xs": breakpoint() === "xs",
        "col-sm": breakpoint() === "sm",
        "col-md": breakpoint() === "md",
        "col-lg": breakpoint() === "lg",
        "col-xl": breakpoint() === "xl",
        "col-xxl": breakpoint() === "xxl"
      });
    });
    append($$anchor, div);
  }

  // ts/lib/components/Container.svelte
  var root2 = from_html(`<div><!></div>`);
  function Container($$anchor, $$props) {
    let id = prop($$props, "id", 24, () => void 0);
    let className = prop($$props, "class", 8, "");
    let breakpoint = prop($$props, "breakpoint", 8, "fluid");
    var div = root2();
    let classes;
    var node = child(div);
    slot(node, $$props, "default", {}, null);
    reset(div);
    template_effect(() => {
      var _a5;
      set_attribute2(div, "id", id());
      classes = set_class(div, 1, `container ${(_a5 = className()) != null ? _a5 : ""}`, "svelte-1p9nw4m", classes, {
        "container-xs": breakpoint() === "xs",
        "container-sm": breakpoint() === "sm",
        "container-md": breakpoint() === "md",
        "container-lg": breakpoint() === "lg",
        "container-xl": breakpoint() === "xl",
        "container-xxl": breakpoint() === "xxl",
        "container-fluid": breakpoint() === "fluid"
      });
    });
    append($$anchor, div);
  }

  // ts/lib/tslib/time.ts
  var SECOND = 1;
  var MINUTE = 60 * SECOND;
  var HOUR = 60 * MINUTE;
  var DAY = 24 * HOUR;
  var YEAR = 365 * DAY;
  var MONTH = YEAR / 12;
  function unitName(unit) {
    switch (unit) {
      case 0 /* Seconds */:
        return "seconds";
      case 1 /* Minutes */:
        return "minutes";
      case 2 /* Hours */:
        return "hours";
      case 3 /* Days */:
        return "days";
      case 4 /* Months */:
        return "months";
      case 5 /* Years */:
        return "years";
    }
  }
  function naturalUnit(secs) {
    secs = Math.abs(secs);
    if (secs < MINUTE) {
      return 0 /* Seconds */;
    } else if (secs < HOUR) {
      return 1 /* Minutes */;
    } else if (secs < DAY) {
      return 2 /* Hours */;
    } else if (secs < MONTH) {
      return 3 /* Days */;
    } else if (secs < YEAR) {
      return 4 /* Months */;
    } else {
      return 5 /* Years */;
    }
  }
  function unitSeconds(unit) {
    switch (unit) {
      case 0 /* Seconds */:
        return SECOND;
      case 1 /* Minutes */:
        return MINUTE;
      case 2 /* Hours */:
        return HOUR;
      case 3 /* Days */:
        return DAY;
      case 4 /* Months */:
        return MONTH;
      case 5 /* Years */:
        return YEAR;
    }
  }
  function unitAmount(unit, secs) {
    return secs / unitSeconds(unit);
  }

  // ts/routes/congrats/lib.ts
  function buildNextLearnMsg(info) {
    const secsUntil = info.secsUntilNextLearn;
    if (secsUntil >= 86400) {
      return "";
    }
    const unit = naturalUnit(secsUntil);
    const amount = Math.round(unitAmount(unit, secsUntil));
    const unitStr = unitName(unit);
    const nextLearnDue = schedulingNextLearnDue({
      amount,
      unit: unitStr
    });
    const remaining = schedulingLearnRemaining({
      remaining: info.learnRemaining
    });
    return `${nextLearnDue} ${remaining}`;
  }

  // ts/routes/congrats/CongratsPage.svelte
  var root3 = from_html(`<p> </p>`);
  var root_1 = from_html(`<p></p>`);
  var root_2 = from_html(`<!> <!>`, 1);
  var root_3 = from_html(`<div class="description svelte-17f7yg5"></div>`);
  var root_4 = from_html(`<div class="congrats svelte-17f7yg5"><h1> </h1> <p> </p> <!> <!> <!> <!></div>`);
  var root_5 = from_html(`<svelte-css-wrapper style="display: contents"><!></svelte-css-wrapper>`, 1);
  function CongratsPage($$anchor, $$props) {
    push($$props, false);
    let info = prop($$props, "info", 12);
    let refreshPeriodically = prop($$props, "refreshPeriodically", 8, true);
    const congrats = schedulingCongratulationsFinished();
    let nextLearnMsg = mutable_source();
    const today_reviews = schedulingTodayReviewLimitReached();
    const today_new = schedulingTodayNewLimitReached();
    const unburyThem = bridgeLink("unbury", schedulingUnburyThem());
    const buriedMsg = schedulingBuriedCardsFound({ unburyThem });
    const customStudy = bridgeLink("customStudy", schedulingCustomStudy());
    const customStudyMsg = schedulingHowToCustomStudy({ customStudy });
    onMount(() => {
      if (refreshPeriodically()) {
        setInterval(
          async () => {
            try {
              info(await congratsInfo({}, { alertOnError: false }));
            } catch {
              console.log("congrats fetch failed");
            }
          },
          6e4
        );
      }
    });
    legacy_pre_effect(() => (buildNextLearnMsg, deep_read_state(info())), () => {
      set(nextLearnMsg, buildNextLearnMsg(info()));
    });
    legacy_pre_effect_reset();
    init();
    var fragment = root_5();
    var node = first_child(fragment);
    {
      css_props(node, () => ({ "--gutter-block": "1rem", "--gutter-inline": "2px" }));
      Container(node.lastChild, {
        breakpoint: "sm",
        children: ($$anchor2, $$slotProps) => {
          var fragment_1 = root_5();
          var node_1 = first_child(fragment_1);
          {
            css_props(node_1, () => ({ "--col-justify": "center" }));
            Col(node_1.lastChild, {
              children: ($$anchor3, $$slotProps2) => {
                var div = root_4();
                var h1 = child(div);
                var text2 = child(h1, true);
                reset(h1);
                var p = sibling(h1, 2);
                var text_1 = child(p, true);
                reset(p);
                var node_2 = sibling(p, 2);
                {
                  var consequent = ($$anchor4) => {
                    var p_1 = root3();
                    var text_2 = child(p_1, true);
                    reset(p_1);
                    template_effect(() => set_text(text_2, today_reviews));
                    append($$anchor4, p_1);
                  };
                  if_block(node_2, ($$render) => {
                    if (deep_read_state(info()), untrack(() => info().reviewRemaining)) $$render(consequent);
                  });
                }
                var node_3 = sibling(node_2, 2);
                {
                  var consequent_1 = ($$anchor4) => {
                    var p_2 = root3();
                    var text_3 = child(p_2, true);
                    reset(p_2);
                    template_effect(() => set_text(text_3, today_new));
                    append($$anchor4, p_2);
                  };
                  if_block(node_3, ($$render) => {
                    if (deep_read_state(info()), untrack(() => info().newRemaining)) $$render(consequent_1);
                  });
                }
                var node_4 = sibling(node_3, 2);
                {
                  var consequent_4 = ($$anchor4) => {
                    var fragment_2 = root_2();
                    var node_5 = first_child(fragment_2);
                    {
                      var consequent_2 = ($$anchor5) => {
                        var p_3 = root_1();
                        html(p_3, () => buriedMsg, true);
                        reset(p_3);
                        append($$anchor5, p_3);
                      };
                      if_block(node_5, ($$render) => {
                        if (deep_read_state(info()), untrack(() => info().haveSchedBuried || info().haveUserBuried)) $$render(consequent_2);
                      });
                    }
                    var node_6 = sibling(node_5, 2);
                    {
                      var consequent_3 = ($$anchor5) => {
                        var p_4 = root_1();
                        html(p_4, () => customStudyMsg, true);
                        reset(p_4);
                        append($$anchor5, p_4);
                      };
                      if_block(node_6, ($$render) => {
                        if (deep_read_state(info()), untrack(() => !info().isFilteredDeck)) $$render(consequent_3);
                      });
                    }
                    append($$anchor4, fragment_2);
                  };
                  if_block(node_4, ($$render) => {
                    if (deep_read_state(info()), untrack(() => info().bridgeCommandsSupported)) $$render(consequent_4);
                  });
                }
                var node_7 = sibling(node_4, 2);
                {
                  var consequent_5 = ($$anchor4) => {
                    var div_1 = root_3();
                    html(
                      div_1,
                      () => (deep_read_state(info()), untrack(() => info().deckDescription)),
                      true
                    );
                    reset(div_1);
                    append($$anchor4, div_1);
                  };
                  if_block(node_7, ($$render) => {
                    if (deep_read_state(info()), untrack(() => info().deckDescription)) $$render(consequent_5);
                  });
                }
                reset(div);
                template_effect(() => {
                  set_text(text2, congrats);
                  set_text(text_1, get2(nextLearnMsg));
                });
                append($$anchor3, div);
              },
              $$slots: { default: true }
            });
            reset(node_1);
          }
          append($$anchor2, fragment_1);
        },
        $$slots: { default: true }
      });
      reset(node);
    }
    append($$anchor, fragment);
    pop();
  }

  // ts/routes/congrats/index.ts
  var i18n = setupI18n({ modules: ["scheduling" /* SCHEDULING */] });
  async function setupCongrats() {
    checkNightMode();
    await i18n;
    const customMountPoint = document.getElementById("congrats");
    const info = await congratsInfo({});
    const props = { info, refreshPeriodically: false };
    mount(
      CongratsPage,
      // use #congrats if it exists, otherwise entire body
      { target: customMountPoint != null ? customMountPoint : document.body, props }
    );
    return;
  }
  setupCongrats();
  return __toCommonJS(index_exports);
})();
