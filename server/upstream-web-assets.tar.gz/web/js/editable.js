"use strict";
var anki = (() => {
})();
